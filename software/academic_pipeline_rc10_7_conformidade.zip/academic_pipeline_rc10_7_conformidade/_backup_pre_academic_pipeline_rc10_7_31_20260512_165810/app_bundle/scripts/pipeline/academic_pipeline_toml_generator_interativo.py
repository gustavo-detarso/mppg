#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Gerador interativo completo de TOML para academic_pipeline rc10.7.27.

O objetivo é reduzir erro operacional: o usuário escolhe um preset explicável,
responde apenas os campos necessários e o script gera um TOML completo com as
camadas atuais do pipeline: instituição, corpus local, pesquisa, documento,
bibliografia, LaTeX, DOCX, prompts, mapa mental, relatório PRISMA,
conformidade e qualidade.

Pode ser usado para:
- atividade local;
- paper local;
- paper com relatório PRISMA;
- dissertação local;
- dissertação com relatório PRISMA;
- relatório PRISMA autônomo;
- somente renderização a partir de document.json;
- modo avançado por componentes.
"""
from __future__ import annotations

import argparse
import os
import re
import shutil
import sys
import textwrap
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Any

try:
    import readline  # noqa: F401
except Exception:  # pragma: no cover
    readline = None  # type: ignore


# -----------------------------------------------------------------------------
# Localização do app_bundle
# -----------------------------------------------------------------------------


def find_app_bundle(start: Path | None = None) -> Path:
    current = (start or Path.cwd()).resolve()
    for candidate in [current, *current.parents]:
        if candidate.name == "app_bundle":
            return candidate
        if (candidate / "app_bundle").is_dir():
            return (candidate / "app_bundle").resolve()
    here = Path(__file__).resolve()
    for candidate in [here.parent, *here.parents]:
        if candidate.name == "app_bundle":
            return candidate
    raise RuntimeError("Não consegui localizar app_bundle. Execute a partir da raiz do academic_pipeline ou de app_bundle.")


APP = find_app_bundle()
ROOT = APP.parent


# -----------------------------------------------------------------------------
# Utilitários básicos
# -----------------------------------------------------------------------------


def slugify(value: str) -> str:
    value = (value or "").strip().lower()
    repl = {
        "á": "a", "à": "a", "ã": "a", "â": "a", "ä": "a",
        "é": "e", "ê": "e", "è": "e", "ë": "e",
        "í": "i", "ì": "i", "î": "i", "ï": "i",
        "ó": "o", "ò": "o", "õ": "o", "ô": "o", "ö": "o",
        "ú": "u", "ù": "u", "û": "u", "ü": "u",
        "ç": "c", "ñ": "n",
    }
    for a, b in repl.items():
        value = value.replace(a, b)
    value = re.sub(r"[^a-z0-9]+", "_", value)
    value = re.sub(r"_+", "_", value).strip("_")
    return value or "projeto"


def toml_escape(value: Any) -> str:
    s = str(value if value is not None else "")
    return (
        s.replace("\\", "\\\\")
        .replace("\r", "\\r")
        .replace("\n", "\\n")
        .replace("\t", "\\t")
        .replace('"', '\\"')
    )

def tstr(value: Any) -> str:
    return f'"{toml_escape(value)}"'


def tbool(value: bool) -> str:
    return "true" if bool(value) else "false"


def tlist(items: list[str], indent: str = "") -> str:
    if not items:
        return "[]"
    body = ",\n".join(f'{indent}  {tstr(i)}' for i in items)
    return "[\n" + body + f"\n{indent}]"


def rel_for_toml(path: Path | str, config_dir: Path) -> str:
    raw = str(path or "").strip()
    if not raw:
        return ""
    if raw.startswith("profile://"):
        return raw
    p = Path(raw).expanduser()
    if not p.is_absolute():
        # Mantém relativo se o usuário já informou relativo; normaliza separadores.
        return raw.replace("\\", "/")
    try:
        return os.path.relpath(p.resolve(), config_dir.resolve()).replace("\\", "/")
    except Exception:
        return str(p).replace("\\", "/")


def ensure_project_dir(project_slug: str) -> Path:
    p = APP / "projetos" / project_slug
    p.mkdir(parents=True, exist_ok=True)
    return p


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.rstrip() + "\n", encoding="utf-8")


def maybe_copy_to_project(src: str, dst: Path) -> str:
    src = (src or "").strip()
    if not src:
        return str(dst)
    p = Path(src).expanduser()
    if p.exists() and p.resolve() != dst.resolve():
        dst.parent.mkdir(parents=True, exist_ok=True)
        if p.is_file():
            shutil.copy2(p, dst)
            return str(dst)
    return src


def install_path_completion() -> None:
    if readline is None:
        return
    try:
        import glob

        def complete(text: str, state: int) -> str | None:
            expanded = os.path.expanduser(text)
            matches = glob.glob(expanded + "*")
            results: list[str] = []
            for m in matches:
                suffix = "/" if os.path.isdir(m) else ""
                item = m + suffix
                if text.startswith("~"):
                    item = item.replace(os.path.expanduser("~"), "~", 1)
                results.append(item)
            try:
                return results[state]
            except IndexError:
                return None

        readline.set_completer_delims(" \t\n")
        readline.set_completer(complete)
        readline.parse_and_bind("tab: complete")
    except Exception:
        return


# -----------------------------------------------------------------------------
# Entrada interativa
# -----------------------------------------------------------------------------


def ask(prompt: str, default: str = "") -> str:
    suffix = f" [{default}]" if default else ""
    value = input(f"{prompt}{suffix}: ").strip()
    return value if value else default


def ask_required(prompt: str, default: str = "") -> str:
    while True:
        value = ask(prompt, default)
        if value.strip():
            return value.strip()
        print("Campo obrigatório.")


def ask_bool(prompt: str, default: bool = True) -> bool:
    d = "s" if default else "n"
    while True:
        value = input(f"{prompt} (s/n) [{d}]: ").strip().lower()
        if not value:
            return default
        if value in {"s", "sim", "y", "yes"}:
            return True
        if value in {"n", "nao", "não", "no"}:
            return False
        print("Responda s ou n.")


def ask_choice(prompt: str, choices: list[str], default: str) -> str:
    choices_norm = {c.lower(): c for c in choices}
    while True:
        value = ask(prompt + " (" + "/".join(choices) + ")", default).lower()
        if value in choices_norm:
            return choices_norm[value]
        print("Escolha inválida.")


def ask_list(prompt: str, default: list[str] | None = None) -> list[str]:
    default = default or []
    raw_default = "; ".join(default)
    raw = ask(prompt + " (separe por ;)", raw_default)
    return [x.strip() for x in raw.split(";") if x.strip()]


def list_institutions() -> list[str]:
    base = APP / "institutions"
    if not base.exists():
        return ["fgv"]
    items = sorted(p.name for p in base.iterdir() if p.is_dir())
    return items or ["fgv"]


# -----------------------------------------------------------------------------
# Perfis
# -----------------------------------------------------------------------------


@dataclass(frozen=True)
class Preset:
    key: str
    label: str
    description: str
    document_type: str
    local_corpus: bool
    prisma_report: bool
    executar_documento: bool
    executar_pesquisa: bool
    render_only: bool = False
    default_toml: str = "config.toml"


PRESETS: list[Preset] = [
    Preset(
        key="atividade_local_fgv",
        label="Atividade local FGV",
        description="Gera atividade acadêmica com Ficha Técnica FGV a partir de corpus local. Não faz busca externa nem relatório PRISMA.",
        document_type="atividade",
        local_corpus=True,
        prisma_report=False,
        executar_documento=True,
        executar_pesquisa=False,
        default_toml="atividade_config.toml",
    ),
    Preset(
        key="resumo_artigos_local_fgv",
        label="Resumo analítico de artigos locais FGV",
        description="Gera documento FGV com Ficha Técnica, introdução, resumos individuais, comparação, síntese analítica, considerações finais, referências e mapa mental opcional a partir de corpus local. Não faz busca externa nem relatório PRISMA.",
        # Mantém tipo_documento=atividade para preservar a Ficha Técnica FGV no ORG/PDF/DOCX.
        # A especialização semântica fica no preset, no papertype, no prompt e na seção [resumo_artigos].
        document_type="atividade",
        local_corpus=True,
        prisma_report=False,
        executar_documento=True,
        executar_pesquisa=False,
        default_toml="resumo_artigos_config.toml",
    ),
    Preset(
        key="paper_local_fgv",
        label="Paper local FGV",
        description="Gera paper acadêmico FGV a partir de PDFs/DOCX/TXT locais, com ORG/PDF/DOCX, conformidade e qualidade.",
        document_type="paper",
        local_corpus=True,
        prisma_report=False,
        executar_documento=True,
        executar_pesquisa=False,
        default_toml="paper_config.toml",
    ),
    Preset(
        key="paper_prisma_fgv",
        label="Paper + relatório PRISMA FGV",
        description="Gera paper e saída própria de relatório PRISMA. O relatório usa corpus local, prisma_report.json ou diretório de pesquisa/triagem existente.",
        document_type="paper",
        local_corpus=True,
        prisma_report=True,
        executar_documento=True,
        executar_pesquisa=True,
        default_toml="paper_prisma_config.toml",
    ),
    Preset(
        key="dissertacao_local_fgv",
        label="Dissertação local FGV",
        description="Gera dissertação FGV a partir de corpus local, com campos de orientador, área, linha e pré-textuais básicos.",
        document_type="dissertacao",
        local_corpus=True,
        prisma_report=False,
        executar_documento=True,
        executar_pesquisa=False,
        default_toml="dissertacao_config.toml",
    ),
    Preset(
        key="dissertacao_prisma_fgv",
        label="Dissertação + relatório PRISMA FGV",
        description="Gera dissertação e relatório PRISMA auditável a partir de corpus local ou dados de pesquisa existentes.",
        document_type="dissertacao",
        local_corpus=True,
        prisma_report=True,
        executar_documento=True,
        executar_pesquisa=True,
        default_toml="dissertacao_prisma_config.toml",
    ),
    Preset(
        key="relatorio_prisma_fgv",
        label="Relatório PRISMA autônomo FGV",
        description="Gera apenas o relatório de pesquisa/PRISMA. Observação: a versão atual ainda exige corpus local, prisma_report.json ou diretório de pesquisa existente como insumo.",
        document_type="relatorio_prisma",
        local_corpus=True,
        prisma_report=True,
        executar_documento=False,
        executar_pesquisa=True,
        default_toml="relatorio_prisma_config.toml",
    ),
    Preset(
        key="somente_renderizar_fgv",
        label="Somente renderizar document.json FGV",
        description="Cria TOML para renderizar um document.json existente em ORG/PDF/DOCX, sem recriar conteúdo pela IA.",
        document_type="paper",
        local_corpus=False,
        prisma_report=False,
        executar_documento=True,
        executar_pesquisa=False,
        render_only=True,
        default_toml="render_config.toml",
    ),
]


def choose_preset() -> Preset:
    print("\nGerador interativo de TOML — academic_pipeline rc10.7.27")
    print("\nPerfis disponíveis:\n")
    for i, p in enumerate(PRESETS, start=1):
        print(f"{i}. {p.label}")
        print(textwrap.fill("   " + p.description, width=92, subsequent_indent="   "))
    print(f"{len(PRESETS) + 1}. Modo avançado por componentes")
    print("   Monta um perfil customizado escolhendo documento, corpus, relatório PRISMA e saídas.")
    while True:
        choice = ask("\nEscolha o perfil", "1")
        if choice.isdigit():
            n = int(choice)
            if 1 <= n <= len(PRESETS):
                return PRESETS[n - 1]
            if n == len(PRESETS) + 1:
                return choose_advanced_preset()
        by_key = {p.key: p for p in PRESETS}
        if choice in by_key:
            return by_key[choice]
        print("Escolha inválida.")


def choose_advanced_preset() -> Preset:
    print("\nModo avançado por componentes")
    document_type = ask_choice("Tipo de documento", ["atividade", "paper", "dissertacao", "relatorio_prisma"], "paper")
    local_corpus = ask_bool("Usar corpus local?", True)
    prisma_report = ask_bool("Gerar relatório PRISMA como saída própria?", document_type == "relatorio_prisma")
    executar_documento = document_type != "relatorio_prisma" and ask_bool("Gerar documento acadêmico final?", True)
    executar_pesquisa = prisma_report or ask_bool("Marcar executar_pesquisa=true?", False)
    default_toml = f"{document_type}_config.toml" if document_type != "relatorio_prisma" else "relatorio_prisma_config.toml"
    return Preset(
        key="custom_avancado",
        label="Custom avançado",
        description="Perfil customizado montado por componentes.",
        document_type=document_type,
        local_corpus=local_corpus,
        prisma_report=prisma_report,
        executar_documento=executar_documento,
        executar_pesquisa=executar_pesquisa,
        default_toml=default_toml,
    )


# -----------------------------------------------------------------------------
# Coleta de dados
# -----------------------------------------------------------------------------


def collect_common(preset: Preset) -> dict[str, Any]:
    institutions = list_institutions()
    default_institution = "fgv" if "fgv" in institutions else institutions[0]
    print(f"\nPerfil selecionado: {preset.label}")
    print(textwrap.fill(preset.description, width=92))

    if preset.key == "resumo_artigos_local_fgv":
        default_project_name = "resumo_artigos_encontro_X"
    elif preset.document_type == "atividade":
        default_project_name = "atividade_aula_2"
    else:
        default_project_name = f"{preset.document_type}_meu_tema"
    project_name = ask_required("Nome do projeto", default_project_name)
    project_slug = slugify(project_name)
    project_dir = ensure_project_dir(project_slug)
    institution = ask_choice("Perfil institucional", institutions, default_institution)
    toml_name = ask("Nome do arquivo TOML (vazio para usar o padrão interno)", "").strip() or preset.default_toml
    config_path = project_dir / toml_name

    data: dict[str, Any] = {
        "preset": preset,
        "project_name": project_name,
        "project_slug": project_slug,
        "project_dir": project_dir,
        "institution": institution,
        "config_path": config_path,
        "config_dir": project_dir,
    }
    return data


def collect_metadata(data: dict[str, Any]) -> None:
    preset: Preset = data["preset"]
    print("\nMetadados acadêmicos")
    year = str(date.today().year)
    if preset.key == "resumo_artigos_local_fgv":
        default_title = "Resumo analítico dos textos"
    else:
        default_title = {
            "atividade": "Atividade acadêmica",
            "paper": "Título do paper",
            "dissertacao": "Título da dissertação: subtítulo se houver",
            "relatorio_prisma": "Relatório de Pesquisa PRISMA",
        }.get(preset.document_type, "Documento acadêmico")
    data["titulo"] = ask("Título do trabalho", default_title)
    data["autor"] = ask("Autor/aluno", "Gustavo M. Mendes de Tarso")
    data["curso"] = ask("Curso", "Mestrado Acadêmico em Políticas Públicas e Governo")
    data["turma"] = ask("Turma", "2026.1")
    data["polo"] = ask("Pólo/cidade", "Brasília")
    data["disciplina"] = ask("Disciplina", "")
    data["professor"] = ask("Professor", "")
    data["data"] = ask("Data/ano", year)

    if preset.document_type == "dissertacao":
        print("\nCampos específicos de dissertação")
        data["area_de_concentracao"] = ask("Área de concentração", "Políticas Públicas e Governo")
        data["linha_pesquisa"] = ask("Linha de pesquisa", "")
        data["orientador"] = ask("Orientador", data.get("professor", ""))
        data["coorientador"] = ask("Coorientador", "")
        data["data_aprovacao"] = ask("Data de aprovação", "")
        data["natureza_trabalho"] = ask(
            "Natureza do trabalho",
            f"Dissertação apresentada à Fundação Getulio Vargas, como requisito para obtenção do título de Mestre em {data['area_de_concentracao']}.",
        )
    else:
        data["area_de_concentracao"] = ""
        data["linha_pesquisa"] = ""
        data["orientador"] = ""
        data["coorientador"] = ""
        data["data_aprovacao"] = ""
        data["natureza_trabalho"] = ""


DEFAULT_RESUMO_ARTIGOS_TEMA = (
    "Corpus local de textos acadêmicos. Produzir leitura analítica aprofundada de cada texto, "
    "reconstruindo problema, objetivo, argumento central, estrutura conceitual, método/evidências, "
    "contribuições, limites e diálogo com o restante do corpus, sem forçar unidade temática artificial."
)

DEFAULT_RESUMO_ARTIGOS_RECORTE = (
    "Comparar os textos apenas em aspectos transversais realmente presentes no corpus: problema abordado, "
    "argumento central, conceitos utilizados, tipo de abordagem, método/evidências, contribuição para a disciplina "
    "e limites analíticos. Não forçar convergências ou unidade temática artificial."
)

DEFAULT_RESUMO_ARTIGOS_OBJETIVO = (
    "Elaborar análise acadêmica aprofundada de cada texto do corpus local, comparando conexões reais entre "
    "eles e produzindo uma síntese interpretativa útil para a disciplina, com fidelidade ao material fornecido "
    "e sem transformar o resultado em resumo meramente sinóptico."
)

DEFAULT_RESUMO_ARTIGOS_PALAVRAS = [
    "resumo analítico",
    "textos acadêmicos",
    "análise comparativa",
    "políticas públicas",
    "administração pública",
]


def _print_default_block(title: str, value: str) -> None:
    print(f"\n{title} padrão:")
    print(textwrap.fill(value, width=92, initial_indent="  ", subsequent_indent="  "))


def collect_research(data: dict[str, Any]) -> None:
    preset: Preset = data["preset"]

    if preset.key == "resumo_artigos_local_fgv":
        print("\nDados do resumo analítico de artigos")
        _print_default_block("Tema/foco de leitura", DEFAULT_RESUMO_ARTIGOS_TEMA)
        _print_default_block("Recorte/foco comparativo", DEFAULT_RESUMO_ARTIGOS_RECORTE)
        _print_default_block("Objetivo do resumo analítico", DEFAULT_RESUMO_ARTIGOS_OBJETIVO)
        usar_padrao = ask_bool("Usar essas orientações padrão de tema, recorte e objetivo?", True)
        if usar_padrao:
            data["tema"] = DEFAULT_RESUMO_ARTIGOS_TEMA
            data["recorte"] = DEFAULT_RESUMO_ARTIGOS_RECORTE
            data["objetivo"] = DEFAULT_RESUMO_ARTIGOS_OBJETIVO
        else:
            print("\nEdite apenas o que desejar. Pressione Enter para manter o padrão mostrado.")
            data["tema"] = ask("Tema/foco de leitura", DEFAULT_RESUMO_ARTIGOS_TEMA)
            data["recorte"] = ask("Recorte/foco comparativo", DEFAULT_RESUMO_ARTIGOS_RECORTE)
            data["objetivo"] = ask("Objetivo do resumo analítico", DEFAULT_RESUMO_ARTIGOS_OBJETIVO)
        data["pergunta_pesquisa"] = ""
        data["hipotese"] = ""
        data["orientacao_professor"] = ask("Orientação adicional do professor/usuário, se houver", "")
        if ask_bool("Informar palavras-chave manualmente?", False):
            data["palavras_chave"] = ask_list("Palavras-chave", DEFAULT_RESUMO_ARTIGOS_PALAVRAS)
        else:
            data["palavras_chave"] = []
        data["idiomas"] = ask_list("Idiomas", ["português"])
        data["tipo_estudo"] = "resumo analítico de artigos"
        data["resumo_nivel_detalhamento"] = ask_choice("Profundidade analítica", ["medio", "médio", "alto", "profundo", "exaustivo"], "profundo")
        prof = str(data["resumo_nivel_detalhamento"]).strip().lower()
        if prof == "exaustivo":
            defaults = {"palavras": "1500", "paragrafos": "11", "comparacao": "1300", "sintese": "1100", "chars_doc": "18000", "chars_total": "120000"}
        elif prof in {"profundo", "alto"}:
            defaults = {"palavras": "1200", "paragrafos": "9", "comparacao": "1100", "sintese": "900", "chars_doc": "14000", "chars_total": "95000"}
        else:
            defaults = {"palavras": "850", "paragrafos": "6", "comparacao": "800", "sintese": "700", "chars_doc": "10000", "chars_total": "70000"}
        usar_parametros = ask_bool("Usar parâmetros padrão de profundidade para esse modo?", True)
        if usar_parametros:
            data["resumo_min_palavras_por_artigo"] = defaults["palavras"]
            data["resumo_min_paragrafos_por_artigo"] = defaults["paragrafos"]
            data["resumo_min_palavras_comparacao"] = defaults["comparacao"]
            data["resumo_min_palavras_sintese"] = defaults["sintese"]
            data["resumo_max_chars_por_documento"] = defaults["chars_doc"]
            data["resumo_max_chars_total_corpus"] = defaults["chars_total"]
        else:
            data["resumo_min_palavras_por_artigo"] = ask("Mínimo aproximado de palavras por artigo", defaults["palavras"])
            data["resumo_min_paragrafos_por_artigo"] = ask("Mínimo de parágrafos por artigo", defaults["paragrafos"])
            data["resumo_min_palavras_comparacao"] = ask("Mínimo aproximado de palavras na comparação", defaults["comparacao"])
            data["resumo_min_palavras_sintese"] = ask("Mínimo aproximado de palavras na síntese analítica", defaults["sintese"])
            data["resumo_max_chars_por_documento"] = ask("Máximo de caracteres do texto-base enviados por documento", defaults["chars_doc"])
            data["resumo_max_chars_total_corpus"] = ask("Máximo total de caracteres do corpus enviados à IA", defaults["chars_total"])
        data["resumo_comparar_textos"] = ask_bool("Comparar convergências e divergências entre os textos?", True)
        data["resumo_sintese_analitica"] = ask_bool("Incluir síntese analítica final?", True)
        data["resumo_apontar_limites"] = ask_bool("Apontar limites/tensões dos textos quando pertinente?", True)
        data["resumo_matriz_analitica"] = ask_bool("Exigir matriz/eixos analíticos em cada texto?", True)
        data["resumo_tabela_comparativa"] = ask_bool("Incluir tabela comparativa sintética antes da comparação?", True)
        data["resumo_dialogo_entre_textos"] = ask_bool("Exigir diálogo explícito entre os textos?", True)
        return

    if preset.document_type == "atividade":
        print("\nDados da atividade")
        data["tema"] = ask("Tema da atividade", "")
        data["recorte"] = ask("Recorte/foco da resposta", "")
        data["objetivo"] = ask("Objetivo da atividade", "")
        data["pergunta_pesquisa"] = ask("Pergunta orientadora da atividade", "")
        data["hipotese"] = ask("Tese central da resposta, opcional", "")
        data["orientacao_professor"] = ask("Enunciado/orientação do professor, se houver", "")
        data["palavras_chave"] = ask_list("Palavras-chave", [])
        data["idiomas"] = ask_list("Idiomas", ["português"])
        data["tipo_estudo"] = ask("Tipo de entrega", "atividade acadêmica")
        return

    print("\nTema, recorte e objetivo da pesquisa")
    data["tema"] = ask("Tema", "")
    data["recorte"] = ask("Recorte", "")
    data["objetivo"] = ask("Objetivo", "")
    data["pergunta_pesquisa"] = ask("Pergunta de pesquisa", "")
    data["hipotese"] = ask("Hipótese/tese orientadora", "")
    data["palavras_chave"] = ask_list("Palavras-chave", [])
    data["idiomas"] = ask_list("Idiomas", ["português"])
    if preset.document_type == "dissertacao":
        default_tipo = "dissertação"
    elif preset.document_type == "relatorio_prisma":
        default_tipo = "relatório PRISMA"
    else:
        default_tipo = "paper acadêmico"
    data["tipo_estudo"] = ask("Tipo de estudo", default_tipo)

def collect_sources(data: dict[str, Any]) -> None:
    preset: Preset = data["preset"]
    project_dir: Path = data["project_dir"]
    config_dir: Path = data["config_dir"]
    if preset.render_only:
        print("\nSomente renderização")
        data["document_json"] = ask_required("Caminho do document.json existente", "")
        data["documentos_input_zip"] = ""
        data["documentos_input_dir"] = ""
        data["orientacoes_paths"] = []
        data["doi_manifest_path"] = ""
        data["prompt_extra_paths"] = []
        return

    print("\nEntradas do corpus e orientações")
    if preset.local_corpus:
        raw_mode = ask("Entrada do corpus: digite zip, dir ou cole diretamente o caminho", "zip").strip()
        # UX rc10.7.13: se o usuário colar um caminho .zip aqui, interpretar automaticamente como ZIP.
        candidate = Path(raw_mode).expanduser() if raw_mode else Path("")
        if raw_mode.lower() in {"zip", "dir"}:
            input_mode = raw_mode.lower()
            initial_path = ""
        elif raw_mode.lower().endswith(".zip"):
            input_mode = "zip"
            initial_path = raw_mode
        elif raw_mode and candidate.exists() and candidate.is_dir():
            input_mode = "dir"
            initial_path = raw_mode
        else:
            print("Entrada não reconhecida como caminho; assumindo modo ZIP.")
            input_mode = "zip"
            initial_path = ""

        if input_mode == "zip":
            default_zip = project_dir / "documentos-base.zip"
            src = initial_path or ask_required("Caminho do documentos-base.zip", "")
            if src and ask_bool("Copiar esse arquivo para a pasta do projeto como documentos-base.zip, se existir?", False):
                src = maybe_copy_to_project(src, default_zip)
            data["documentos_input_zip"] = rel_for_toml(src, config_dir)
            data["documentos_input_dir"] = ""
        else:
            src_dir = initial_path or ask_required("Caminho da pasta de documentos", "")
            data["documentos_input_zip"] = ""
            data["documentos_input_dir"] = rel_for_toml(src_dir, config_dir)
    else:
        data["documentos_input_zip"] = ""
        data["documentos_input_dir"] = ""

    # Orientações como ZIP/path são lidas por collect_orientation_docs.
    default_orient = project_dir / "orientacoes.zip"
    orient = ask("Caminho de orientacoes.zip/pasta/arquivo (vazio se não houver)", "")
    orient_paths: list[str] = []
    if orient.strip():
        if ask_bool("Copiar orientações para a pasta do projeto como orientacoes.zip, se for arquivo existente?", False):
            orient = maybe_copy_to_project(orient, default_orient)
        orient_paths.append(rel_for_toml(orient, config_dir))
    data["orientacoes_paths"] = orient_paths

    # DOI manifest: opcional. A partir da rc10.7.22, nenhum caminho de arquivo é sugerido por padrão.
    default_doi = project_dir / "doi_manifest.csv"
    doi = ask("Caminho do doi_manifest.csv (vazio se não houver)", "")
    if doi.strip():
        doi_path = Path(doi).expanduser()
        if not doi_path.exists() and ask_bool("Criar doi_manifest.csv vazio nesse caminho?", False):
            target = doi_path if doi_path.is_absolute() else (config_dir / doi_path)
            write_text(target, "arquivo,doi")
            doi = str(target)
        data["doi_manifest_path"] = rel_for_toml(doi, config_dir)
    else:
        data["doi_manifest_path"] = ""

    # Prompt específico adicional: opcional. Se o usuário deixar vazio, nada é gravado no TOML.
    extra_prompts: list[str] = []
    default_add_prompt = False
    if ask_bool("Adicionar prompt específico do projeto/documento?", default_add_prompt):
        if preset.key == "resumo_artigos_local_fgv":
            default_prompt = project_dir / "prompt_base_resumo_artigos.txt"
        else:
            default_prompt = project_dir / ("prompt_base_atividade.txt" if preset.document_type == "atividade" else "prompt_extra.txt")
        prompt_path = ask("Caminho do prompt específico (vazio para não adicionar)", "")
        if prompt_path.strip():
            if Path(prompt_path).expanduser().exists() and ask_bool("Copiar prompt para a pasta do projeto?", False):
                prompt_path = maybe_copy_to_project(prompt_path, default_prompt)
            extra_prompts.append(rel_for_toml(prompt_path, config_dir))
    data["prompt_extra_paths"] = extra_prompts


def collect_outputs_and_options(data: dict[str, Any]) -> None:
    preset: Preset = data["preset"]
    print("\nSaídas e opções")
    data["exportar_org"] = ask_bool("Gerar ORG?", True)
    data["exportar_pdf"] = ask_bool("Gerar PDF?", True)
    data["exportar_docx"] = ask_bool("Gerar DOCX?", True)
    data["gerar_mapa_mental"] = ask_bool("Gerar mapa mental após referências?", preset.key == "resumo_artigos_local_fgv")
    data["plantuml_jar_path"] = ""
    if data["gerar_mapa_mental"]:
        data["plantuml_jar_path"] = ask("Caminho do plantuml.jar (vazio para PLANTUML_JAR/env)", "")

    style = ask_choice("Estilo bibliográfico", ["abnt", "apa", "outro"], "abnt")
    if style == "outro":
        style = ask("Nome do estilo biblatex instalado", "authoryear-chicago")
    data["estilo"] = style
    if style == "abnt":
        data["latex_style"] = "abnt"
        data["latex_options"] = "backend=biber,style=abnt,sorting=nty,giveninits=true"
        data["docx_csl"] = "../../templates/csl/associacao-brasileira-de-normas-tecnicas.csl"
    elif style == "apa":
        data["latex_style"] = "apa"
        data["latex_options"] = "backend=biber,style=apa,sorting=nyt"
        data["docx_csl"] = "../../templates/csl/apa.csl"
    else:
        data["latex_style"] = style
        data["latex_options"] = f"backend=biber,style={style}"
        data["docx_csl"] = ""

    data["enriquecer_metadados"] = ask_bool("Buscar/enriquecer metadados por DOI/buscadores?", preset.document_type not in {"atividade"})
    if data["enriquecer_metadados"]:
        data["fontes_metadados"] = ask_list("Fontes de metadados", ["crossref", "openalex", "semantic_scholar", "scopus"])
    else:
        data["fontes_metadados"] = ["crossref", "openalex"]
    data["extrair_doi_dos_pdfs"] = ask_bool("Tentar extrair DOI dos PDFs?", True)
    data["buscar_metadados_por_doi"] = data["enriquecer_metadados"] and ask_bool("Buscar metadados quando DOI estiver disponível?", True)

    data["usar_pandoc_docx"] = False
    if data["exportar_docx"]:
        data["usar_pandoc_docx"] = ask_bool("Usar Pandoc/CSL para DOCX, se disponível?", False)
    data["pdf_engine"] = ask_choice("Engine PDF", ["lualatex", "xelatex", "pdflatex"], "lualatex")

    if preset.prisma_report:
        print("\nRelatório PRISMA")
        data["relatorio_prisma_titulo"] = ask("Título do relatório PRISMA", "Relatório de Pesquisa PRISMA")
        data["prisma_json_path"] = ask("prisma_report.json existente (vazio se não houver)", "")
        data["pesquisa_dir_existente"] = ask("Diretório de pesquisa/triagem existente (vazio se não houver)", "")
        data["rel_exportar_pdf"] = ask_bool("Exportar PDF do relatório PRISMA?", True)
        data["rel_exportar_docx"] = ask_bool("Exportar DOCX do relatório PRISMA?", True)
        data["rel_exportar_xlsx"] = ask_bool("Exportar XLSX do relatório PRISMA?", True)
        data["rel_exportar_fluxograma"] = ask_bool("Exportar fluxograma PRISMA?", True)
    else:
        data["relatorio_prisma_titulo"] = ""
        data["prisma_json_path"] = ""
        data["pesquisa_dir_existente"] = ""
        data["rel_exportar_pdf"] = False
        data["rel_exportar_docx"] = False
        data["rel_exportar_xlsx"] = False
        data["rel_exportar_fluxograma"] = False

    data["conformidade"] = ask_bool("Gerar relatório de conformidade institucional?", True)
    data["qualidade"] = ask_bool("Gerar relatório de qualidade?", True)


# -----------------------------------------------------------------------------
# Renderização do TOML
# -----------------------------------------------------------------------------


def document_type_name(tipo: str) -> str:
    if tipo == "resumo_artigos":
        return "Resumo analítico de artigos"
    if tipo == "atividade":
        return "Atividade acadêmica"
    if tipo == "dissertacao":
        return "Dissertação"
    if tipo == "relatorio_prisma":
        return "Relatório de Pesquisa PRISMA"
    return "Paper acadêmico"


def prompt_paths_for_type(data: dict[str, Any]) -> dict[str, list[str]]:
    preset: Preset = data["preset"]
    tipo = preset.document_type
    extras = data.get("prompt_extra_paths", [])
    paper: list[str] = []
    atividade: list[str] = []
    dissertacao: list[str] = []
    prisma: list[str] = []
    resumo_artigos: list[str] = []

    if preset.key == "resumo_artigos_local_fgv":
        # O tipo canônico continua sendo atividade para preservar a Ficha Técnica.
        # Por isso o prompt especializado entra em atividade_paths.
        atividade = ["../../prompts/document/atividade.txt", "../../prompts/document/resumo_artigos.txt", *extras]
        resumo_artigos = ["../../prompts/document/resumo_artigos.txt", *extras]
    elif tipo == "paper":
        paper = ["../../prompts/document/paper.txt", *extras]
    elif tipo == "atividade":
        atividade = ["../../prompts/document/atividade.txt", *extras]
    elif tipo == "dissertacao":
        dissertacao = ["../../prompts/document/dissertacao.txt", *extras]
    else:
        prisma = ["../../prompts/prisma/relatorio_prisma.txt", *extras]
    if preset.prisma_report and "../../prompts/prisma/relatorio_prisma.txt" not in prisma:
        prisma.append("../../prompts/prisma/relatorio_prisma.txt")
    return {
        "paper_paths": paper,
        "atividade_paths": atividade,
        "resumo_artigos_paths": resumo_artigos,
        "dissertacao_paths": dissertacao,
        "prisma_paths": prisma,
    }


def build_orientacao_inline(data: dict[str, Any]) -> str:
    preset: Preset = data["preset"]
    professor = str(data.get("orientacao_professor") or "").strip()
    if preset.key == "resumo_artigos_local_fgv":
        parts = [
            "O documento deve ser produzido exclusivamente a partir do corpus local.",
            "Todos os textos/artigos/capítulos fornecidos devem ser mencionados e resumidos individualmente.",
            "Não use revisão bibliográfica externa como base principal e não acrescente autores, títulos ou conceitos não presentes no corpus, salvo se a orientação do usuário exigir explicitamente.",
            "Estrutura preferencial: 1 INTRODUÇÃO; 2 RESUMO INDIVIDUAL DOS TEXTOS; 3 COMPARAÇÃO ENTRE OS TEXTOS; 4 SÍNTESE ANALÍTICA; 5 CONSIDERAÇÕES FINAIS. Não crie seção textual de REFERÊNCIAS/BIBLIOGRAFIA; o renderizador insere a bibliografia automaticamente a partir do .bib. Se o mapa mental estiver ativado, ele será inserido após a bibliografia renderizada.",
            "Cada resumo individual deve explicitar objetivo do texto, problema central, argumento principal, conceitos relevantes, contribuição para o tema/foco da leitura e limites ou tensões quando pertinentes.",
        ]
        if bool(data.get("resumo_comparar_textos", True)):
            parts.append("A comparação deve destacar convergências, divergências, complementaridades e diferenças de objeto, método ou escala entre os textos.")
        if bool(data.get("resumo_sintese_analitica", True)):
            parts.append("A síntese analítica deve articular o conjunto do corpus em uma interpretação própria, evitando mera justaposição de resumos.")
        if bool(data.get("resumo_apontar_limites", True)):
            parts.append("Quando pertinente, identifique limites, tensões analíticas ou lacunas dos textos, sem extrapolar além do corpus.")
        if professor:
            parts.append("Orientação específica do professor/usuário: " + professor)
        return "\n".join(parts)
    if preset.document_type == "atividade" and professor:
        return professor
    return ""

def render_toml(data: dict[str, Any]) -> str:
    preset: Preset = data["preset"]
    project_slug = data["project_slug"]
    tipo = preset.document_type if preset.document_type != "relatorio_prisma" else "paper"
    logical_tipo = "resumo_artigos" if preset.key == "resumo_artigos_local_fgv" else tipo
    doc_prefix = project_slug
    rel_prefix = f"relatorio_prisma_{project_slug}" if preset.prisma_report else ""
    prompt_groups = prompt_paths_for_type(data)

    # Como o TOML fica em app_bundle/projetos/<slug>, estes caminhos são relativos ao arquivo.
    output_documento = "../../output/documento"
    output_pesquisa = "../../output/pesquisa"
    output_work = "../../output/work"
    output_cache = "../../output/cache"

    if preset.render_only:
        # Render-only ainda precisa de seções suficientes para PDF/DOCX/conformidade.
        executar_pesquisa = False
        executar_documento = True
    else:
        executar_pesquisa = preset.executar_pesquisa
        executar_documento = preset.executar_documento

    lines: list[str] = []
    lines.append(f"# Gerado por academic_pipeline_toml_generator_interativo.py")
    lines.append(f"# Preset: {preset.key} — {preset.label}")
    lines.append(f"# Descrição: {preset.description}")
    if preset.render_only:
        lines.append(f"# Uso: academic_pipeline_rc10.py --config {data['config_path']} --somente-renderizar --document-json {data.get('document_json', '')}")
    lines.append("")

    lines.append("[projeto]")
    lines.append(f"nome = {tstr(project_slug)}")
    lines.append(f"descricao = {tstr(preset.description)}")
    lines.append(f"preset = {tstr(preset.key)}")
    lines.append("")

    lines.append("[instituicao]")
    lines.append(f"perfil = {tstr(data['institution'])}")
    lines.append("")

    lines.append("[openai]")
    lines.append(f"model = {tstr(os.getenv('OPENAI_MODEL', 'gpt-5.4'))}")
    lines.append("")

    lines.append("[pipeline]")
    lines.append(f"modo_entrada = {tstr('somente_renderizar' if preset.render_only else 'documentos_locais')}")
    lines.append(f"executar_pesquisa = {tbool(executar_pesquisa)}")
    lines.append(f"executar_documento = {tbool(executar_documento)}")
    lines.append("executar_bundle = false")
    if data.get("pesquisa_dir_existente"):
        lines.append(f"pesquisa_dir_existente = {tstr(rel_for_toml(data['pesquisa_dir_existente'], data['config_dir']))}")
    else:
        lines.append("pesquisa_dir_existente = \"\"")
    lines.append("")

    lines.append("[paths]")
    lines.append("# A partir da rc10.7.20, todos os diretórios de saída/cache/trabalho ficam aqui.")
    lines.append(f"document_output_dir = {tstr(output_documento)}")
    lines.append(f"research_output_dir = {tstr(output_pesquisa)}")
    lines.append(f"work_dir = {tstr(output_work)}")
    lines.append(f"cache_dir = {tstr(output_cache)}")
    lines.append(f"document_prefix = {tstr(doc_prefix)}")
    lines.append(f"research_prefix = {tstr(rel_prefix or 'relatorio_prisma')}")
    lines.append("create_document_subdir = true")
    lines.append("create_research_subdir = true")
    lines.append("create_work_subdir = true")
    lines.append("create_cache_subdir = true")
    lines.append("")

    lines.append("[orientacoes]")
    lines.append(f"paths = {tlist(data.get('orientacoes_paths', []))}")
    lines.append(f"inline = {tstr(build_orientacao_inline(data))}")
    lines.append("")

    lines.append("[documentos_locais]")
    lines.append(f"ativos = {tbool(preset.local_corpus and not preset.render_only)}")
    lines.append("modo_entrada = \"documentos_locais\"")
    lines.append(f"input_zip = {tstr(data.get('documentos_input_zip', ''))}")
    lines.append(f"input_dir = {tstr(data.get('documentos_input_dir', ''))}")
    lines.append("tipos = [\"pdf\", \"docx\", \"txt\", \"md\", \"org\"]")
    lines.append("recursive = true")
    lines.append("limpar_extracao_anterior = true")
    lines.append("copiar_para_fulltext_cache = true")
    lines.append("limpar_cache_anterior = true")
    lines.append("auto_detect_bib = true")
    lines.append("gerar_bib_revisado_ia = true")
    lines.append(f"enriquecer_metadados_buscadores = {tbool(data.get('enriquecer_metadados', False))}")
    lines.append(f"fontes_metadados = {tlist(data.get('fontes_metadados', []))}")
    lines.append("min_score_match_metadados = 0.82")
    lines.append(f"extrair_doi_dos_pdfs = {tbool(data.get('extrair_doi_dos_pdfs', True))}")
    lines.append(f"doi_manifest_path = {tstr(data.get('doi_manifest_path', ''))}")
    lines.append("preferir_doi_manual = true")
    lines.append(f"buscar_metadados_por_doi = {tbool(data.get('buscar_metadados_por_doi', False))}")
    lines.append("incluir_notas_metadados_inferidos = false")
    lines.append("deduplicar_bib = true")
    lines.append("deduplicar_referencias = true")
    lines.append("autor_padrao = \"\"")
    lines.append("ano_padrao = \"s.d.\"")
    lines.append("")

    lines.append("[pesquisa]")
    lines.append(f"tema = {tstr(data.get('tema', ''))}")
    lines.append(f"recorte = {tstr(data.get('recorte', ''))}")
    lines.append(f"objetivo = {tstr(data.get('objetivo', ''))}")
    lines.append(f"pergunta_pesquisa = {tstr(data.get('pergunta_pesquisa', ''))}")
    lines.append(f"hipotese = {tstr(data.get('hipotese', ''))}")
    lines.append(f"palavras_chave = {tlist(data.get('palavras_chave', []))}")
    lines.append(f"idiomas = {tlist(data.get('idiomas', ['português']))}")
    lines.append(f"tipo_estudo = {tstr(data.get('tipo_estudo', document_type_name(logical_tipo)))}")
    lines.append("periodo = \"\"")
    lines.append("bases = [\"Crossref\", \"OpenAlex\", \"Semantic Scholar\", \"Scopus\"]")
    lines.append("")

    lines.append("[resumo_artigos]")
    resumo_ativo = preset.key == "resumo_artigos_local_fgv"
    lines.append(f"ativo = {tbool(resumo_ativo)}")
    lines.append(f"geracao_em_etapas = {tbool(resumo_ativo)}")
    lines.append("# Quando true, o pipeline gera o document.json em chamadas separadas:")
    lines.append("# análise do artigo 1/N, análise do artigo 2/N, comparação e síntese.")
    lines.append("# Isso exibe progresso no terminal e salva checkpoints .checkpoint_*.json no output.")
    lines.append("modo = \"analitico_comparativo\"")
    lines.append(f"usar_apenas_corpus_local = {tbool(resumo_ativo)}")
    lines.append(f"incluir_introducao = {tbool(resumo_ativo)}")
    lines.append(f"incluir_resumos_individuais = {tbool(resumo_ativo)}")
    lines.append(f"incluir_comparacao = {tbool(bool(data.get('resumo_comparar_textos', resumo_ativo)))}")
    lines.append(f"incluir_sintese_analitica = {tbool(bool(data.get('resumo_sintese_analitica', resumo_ativo)))}")
    lines.append(f"incluir_consideracoes_finais = {tbool(resumo_ativo)}")
    lines.append("incluir_referencias = true")
    lines.append(f"incluir_mapa_mental = {tbool(data.get('gerar_mapa_mental', False))}")
    lines.append(f"uma_secao_por_artigo = {tbool(resumo_ativo)}")
    lines.append(f"comparar_convergencias = {tbool(bool(data.get('resumo_comparar_textos', resumo_ativo)))}")
    lines.append(f"comparar_divergencias = {tbool(bool(data.get('resumo_comparar_textos', resumo_ativo)))}")
    lines.append(f"apontar_limites = {tbool(bool(data.get('resumo_apontar_limites', resumo_ativo)))}")
    lines.append(f"nivel_detalhamento = {tstr(data.get('resumo_nivel_detalhamento', 'profundo' if resumo_ativo else 'medio'))}")
    lines.append(f"profundidade_analitica = {tstr(data.get('resumo_nivel_detalhamento', 'profundo' if resumo_ativo else 'medio'))}")
    if resumo_ativo:
        lines.append(f"min_palavras_por_artigo = {int(str(data.get('resumo_min_palavras_por_artigo') or 1200).strip() or 1200)}")
        lines.append(f"min_paragrafos_por_artigo = {int(str(data.get('resumo_min_paragrafos_por_artigo') or 9).strip() or 9)}")
        lines.append(f"min_palavras_comparacao = {int(str(data.get('resumo_min_palavras_comparacao') or 1100).strip() or 1100)}")
        lines.append(f"min_palavras_sintese = {int(str(data.get('resumo_min_palavras_sintese') or 900).strip() or 900)}")
        lines.append(f"max_chars_por_documento = {int(str(data.get('resumo_max_chars_por_documento') or 14000).strip() or 14000)}")
        lines.append(f"max_chars_total_corpus = {int(str(data.get('resumo_max_chars_total_corpus') or 95000).strip() or 95000)}")
        lines.append(f"exigir_matriz_analitica_por_texto = {tbool(bool(data.get('resumo_matriz_analitica', True)))}")
        lines.append(f"incluir_tabela_comparativa = {tbool(bool(data.get('resumo_tabela_comparativa', True)))}")
        lines.append(f"exigir_dialogo_entre_textos = {tbool(bool(data.get('resumo_dialogo_entre_textos', True)))}")
        lines.append("evitar_resumo_sinoptico = true")
        lines.append('eixos_analise = ["problema/questão central", "objetivo e escopo", "argumento/tese principal", "conceitos/categorias", "método/evidências", "achados/contribuições", "limites/tensões", "diálogo com o corpus"]')
    lines.append("")

    lines.append("[atividade]")
    lines.append(f"curso = {tstr(data.get('curso', ''))}")
    lines.append(f"turma = {tstr(data.get('turma', ''))}")
    lines.append(f"polo = {tstr(data.get('polo', ''))}")
    lines.append(f"disciplina = {tstr(data.get('disciplina', ''))}")
    lines.append(f"professor = {tstr(data.get('professor', ''))}")
    lines.append(f"aluno = {tstr(data.get('autor', ''))}")
    lines.append(f"data = {tstr(data.get('data', ''))}")
    lines.append(f"titulo_trabalho = {tstr(data.get('titulo', ''))}")
    lines.append("")

    lines.append("[documento]")
    lines.append(f"tipo_documento = {tstr(tipo)}")
    # Caminhos/prefixo ficam em [paths].
    lines.append(f"titulo_trabalho = {tstr(data.get('titulo', ''))}")
    lines.append(f"autor = {tstr(data.get('autor', ''))}")
    lines.append("inferir_campos_vazios_ia = true")
    lines.append("institution_name = \"Fundação Getulio Vargas\"")
    lines.append("program_name = \"\"")
    lines.append(f"course_name = {tstr(data.get('curso', ''))}")
    lines.append(f"discipline_name = {tstr(data.get('disciplina', ''))}")
    lines.append(f"professor_name = {tstr(data.get('professor', ''))}")
    lines.append(f"city_name = {tstr(data.get('polo', 'Brasília'))}")
    lines.append(f"ano = {tstr(data.get('data', ''))}")
    lines.append(f"data = {tstr(data.get('data', ''))}")
    papertype = "Resumo analítico de artigos" if preset.key == "resumo_artigos_local_fgv" else document_type_name(tipo)
    perfil_redacao = "academico_analitico_comparativo" if preset.key == "resumo_artigos_local_fgv" else "academico_analitico"
    lines.append(f"papertype = {tstr(papertype)}")
    lines.append(f"perfil_redacao = {tstr(perfil_redacao)}")
    lines.append("covernote = \"Trabalho acadêmico elaborado para a disciplina.\"")
    if tipo == "dissertacao":
        lines.append(f"area_de_concentracao = {tstr(data.get('area_de_concentracao', ''))}")
        lines.append(f"linha_pesquisa = {tstr(data.get('linha_pesquisa', ''))}")
        lines.append(f"orientador = {tstr(data.get('orientador', ''))}")
        lines.append(f"coorientador = {tstr(data.get('coorientador', ''))}")
        lines.append(f"natureza_trabalho = {tstr(data.get('natureza_trabalho', ''))}")
        lines.append(f"data_aprovacao = {tstr(data.get('data_aprovacao', ''))}")
    lines.append(f"estilo_citacao = {tstr(data.get('estilo', 'abnt'))}")
    lines.append(f"exportar_org = {tbool(data.get('exportar_org', True))}")
    lines.append(f"exportar_pdf = {tbool(data.get('exportar_pdf', True))}")
    lines.append(f"exportar_docx = {tbool(data.get('exportar_docx', True))}")
    lines.append("gerar_documento_json = true")
    lines.append("modo_renderizacao = \"document_model\"")
    lines.append("usar_citacoes_latex_diretas = true")
    lines.append("validar_org_final = true")
    lines.append("falhar_se_org_tiver_chave_crua = true")
    lines.append("falhar_se_org_tiver_empty_citation = true")
    lines.append("falhar_se_org_tiver_mencao_tecnica = true")
    lines.append("")

    lines.append("[bibliografia]")
    lines.append("# O .bib é neutro. O estilo visual é aplicado na renderização.")
    lines.append(f"estilo_citacao = {tstr(data.get('estilo', 'abnt'))}")
    lines.append(f"latex_style = {tstr(data.get('latex_style', 'abnt'))}")
    lines.append(f"latex_options = {tstr(data.get('latex_options', 'backend=biber,style=abnt,sorting=nty,giveninits=true'))}")
    lines.append(f"docx_csl = {tstr(data.get('docx_csl', ''))}")
    lines.append(f"buscar_metadados_por_doi = {tbool(data.get('buscar_metadados_por_doi', False))}")
    lines.append(f"enriquecer_metadados_buscadores = {tbool(data.get('enriquecer_metadados', False))}")
    lines.append("")

    lines.append("[relatorio_pesquisa]")
    lines.append(f"ativo = {tbool(preset.prisma_report)}")
    lines.append("tipo = \"prisma\"")
    lines.append(f"titulo = {tstr(data.get('relatorio_prisma_titulo', 'Relatório de Pesquisa PRISMA'))}")
    # Caminhos/prefixo ficam em [paths].
    lines.append("exportar_json = true")
    lines.append("exportar_org = true")
    lines.append(f"exportar_pdf = {tbool(data.get('rel_exportar_pdf', False))}")
    lines.append(f"exportar_docx = {tbool(data.get('rel_exportar_docx', False))}")
    lines.append(f"exportar_xlsx = {tbool(data.get('rel_exportar_xlsx', False))}")
    lines.append(f"exportar_fluxograma = {tbool(data.get('rel_exportar_fluxograma', False))}")
    lines.append("validar = true")
    lines.append("falhar_se_invalido = false")
    lines.append(f"prisma_json_path = {tstr(rel_for_toml(data.get('prisma_json_path', ''), data['config_dir']))}")
    lines.append(f"pesquisa_dir_existente = {tstr(rel_for_toml(data.get('pesquisa_dir_existente', ''), data['config_dir']))}")
    lines.append("criterios_inclusao = [")
    lines.append("  \"Aderência substantiva ao tema, recorte e objetivo.\",")
    lines.append("  \"Relação direta com os textos-base ou com o problema de pesquisa.\",")
    lines.append("  \"Disponibilidade de metadados mínimos ou DOI para identificação bibliográfica.\"")
    lines.append("]")
    lines.append("criterios_exclusao = [")
    lines.append("  \"Fora do tema ou do recorte.\",")
    lines.append("  \"Duplicado.\",")
    lines.append("  \"Ausência de relação substantiva com a pergunta de pesquisa.\"")
    lines.append("]")
    lines.append("")

    lines.append("[docx]")
    lines.append(f"ativo = {tbool(data.get('exportar_docx', True))}")
    # Preferência por referência institucional quando existir.
    lines.append(f"reference_docx = {tstr('../../institutions/' + data['institution'] + '/docx/reference_fgv.docx')}")
    lines.append(f"usar_pandoc = {tbool(data.get('usar_pandoc_docx', False))}")
    lines.append(f"csl_path = {tstr(data.get('docx_csl', ''))}")
    lines.append("falhar_se_pandoc_falhar = false")
    lines.append("incluir_capa = true")
    lines.append("incluir_referencias = true")
    lines.append(f"incluir_mapa_mental = {tbool(data.get('gerar_mapa_mental', False))}")
    lines.append("")

    lines.append("[latex]")
    lines.append(f"pdf_engine = {tstr(data.get('pdf_engine', 'lualatex'))}")
    lines.append("org_latex_class_init = \"../../misc/academic-writing.el\"")
    lines.append("latex_extra_path = \"../../misc/fgv\"")
    lines.append("fgv_logo_path = \"../../misc/fgv.png\"")
    lines.append("")

    lines.append("[prompts]")
    lines.append("ativos = true")
    lines.append("global_paths = [\"../../prompts/global/orientacao_geral_execucao.txt\"]")
    lines.append("institution_paths = [\"profile://prompts/fgv_geral.txt\"]")
    lines.append("research_paths = [")
    lines.append("  \"../../prompts/research/triagem_prompt.txt\",")
    lines.append("  \"../../prompts/research/diretivas_extras.txt\"")
    lines.append("]")
    for key in ("paper_paths", "atividade_paths", "resumo_artigos_paths", "dissertacao_paths", "prisma_paths"):
        lines.append(f"{key} = {tlist(prompt_groups[key])}")
    lines.append("document_paths = []")
    lines.append("")

    lines.append("[mapa_mental]")
    lines.append(f"gerar = {tbool(data.get('gerar_mapa_mental', False))}")
    lines.append(f"ativo = {tbool(data.get('gerar_mapa_mental', False))}")
    lines.append("posicao = \"apos_referencias\"")
    lines.append("titulo = \"Mapa mental dos textos analisados\"")
    lines.append("arquivo = \"mapa_mental\"")
    lines.append("formato = \"png\"")
    lines.append(f"renderizar = {tbool(data.get('gerar_mapa_mental', False))}")
    lines.append(f"inserir_no_org = {tbool(data.get('gerar_mapa_mental', False))}")
    lines.append(f"plantuml_jar_path = {tstr(data.get('plantuml_jar_path', ''))}")
    lines.append("plantuml_limit_size = 8192")
    lines.append("colorido = true")
    lines.append("sobrescrever_cores_existentes = true")
    lines.append('cores_niveis = ["#D9EAF7", "#DFF2E1", "#FFF2CC", "#F8D7DA", "#F8D7DA", "#F8D7DA", "#F8D7DA"]')
    lines.append("falhar_se_nao_renderizar = false")
    lines.append("")

    lines.append("[conformidade]")
    lines.append(f"ativo = {tbool(data.get('conformidade', True))}")
    lines.append("gerar_relatorio = true")
    lines.append("")

    lines.append("[qualidade]")
    lines.append(f"ativo = {tbool(data.get('qualidade', True))}")
    lines.append("gerar_relatorio = true")
    lines.append("")

    lines.append("[controle]")
    lines.append("nao_interativo = true")
    lines.append("dry_run = false")
    lines.append("mock_run = false")
    return "\n".join(lines).rstrip() + "\n"


# -----------------------------------------------------------------------------
# Execução
# -----------------------------------------------------------------------------


def generate_interactive(non_interactive_profile: str | None = None, project_name: str | None = None) -> Path:
    install_path_completion()
    if non_interactive_profile:
        preset_map = {p.key: p for p in PRESETS}
        if non_interactive_profile not in preset_map:
            raise RuntimeError(f"Preset não encontrado: {non_interactive_profile}. Opções: {', '.join(preset_map)}")
        preset = preset_map[non_interactive_profile]
    else:
        preset = choose_preset()

    data = collect_common(preset)
    if project_name:
        # Permite chamada sem perguntar nome; mantém config_path já calculado se não usou interactivo.
        pass
    collect_metadata(data)
    collect_research(data)
    collect_sources(data)
    collect_outputs_and_options(data)

    toml = render_toml(data)
    config_path: Path = data["config_path"]
    if config_path.exists():
        if not ask_bool(f"O TOML já existe ({config_path}). Sobrescrever?", False):
            alt = ask("Informe outro nome de arquivo (vazio para config_novo.toml)", "").strip() or "config_novo.toml"
            config_path = data["project_dir"] / alt
    write_text(config_path, toml)

    print("\nTOML gerado com sucesso:")
    print(f"- {config_path}")
    print("\nPróximos comandos sugeridos:")
    print(f"pipenv run python app_bundle/scripts/pipeline/academic_pipeline_rc10.py --config {config_path.relative_to(ROOT)} --show-prompts")
    print(f"pipenv run python app_bundle/scripts/pipeline/academic_pipeline_rc10.py --config {config_path.relative_to(ROOT)} --check-config")
    if preset.render_only:
        doc_json = data.get("document_json") or "CAMINHO/document.document.json"
        print(f"pipenv run python app_bundle/scripts/pipeline/academic_pipeline_rc10.py --config {config_path.relative_to(ROOT)} --somente-renderizar --document-json {doc_json}")
    else:
        print(f"pipenv run python app_bundle/scripts/pipeline/academic_pipeline_rc10.py --config {config_path.relative_to(ROOT)}")
        print("# Opcional: acrescente --output-dir /caminho/de/saida para sobrescrever [paths].document_output_dir")
    return config_path


def print_profiles() -> None:
    for p in PRESETS:
        print(f"{p.key}: {p.label}")
        print(textwrap.fill("  " + p.description, width=92, subsequent_indent="  "))
        print()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Gerador interativo completo de TOML para academic_pipeline rc10.7.27")
    parser.add_argument("--list-profiles", action="store_true", help="Lista presets disponíveis e encerra")
    parser.add_argument("--profile", default="", help="Inicia diretamente em um preset, ex.: atividade_local_fgv")
    parser.add_argument("--project-name", default="", help="Reservado para automações futuras")
    args = parser.parse_args(argv)
    if args.list_profiles:
        print_profiles()
        return 0
    generate_interactive(non_interactive_profile=args.profile or None, project_name=args.project_name or None)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
