#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Gera uma atividade acadêmica em Org-mode com fluxograma PRISMA em SVG,
a partir de busca em múltiplas bases (Semantic Scholar, Scopus e Web of Science)
e análise via OpenAI API.

A v3.8.60 mantém o autocomplete interativo de caminhos no terminal via prompt_toolkit
(quando instalado), com fallback automático para input() simples, preserva o
comportamento de padrões apenas entre colchetes, mantém a opção
interativa/por flag para limpar arquivos auxiliares ao final, passa a sugerir
palavras-chave e strings de busca automaticamente via OpenAI, com revisão do
usuário antes da execução, corrige a tabela multipágina dos estudos do fluxo
PRISMA para usar ``xltabular`` em vez da combinação inválida ``tabularx`` +
comandos de cabeçalho/rodapé de ``longtable`` e torna o parser de idioma
robusto a formatos estruturados retornados pelas bases, como ``{'code': 'pt'}``.
A v3.8.60 remove a quebra manual interna na célula `Estudo` da tabela de classificação
dos estudos, mantendo `Base(s)` na mesma célula em fluxo contínuo para reduzir o
efeito visual de desalinhamento vertical nas quebras de página.

Fluxo recomendado:
1. O script coleta os parâmetros por flags ou por perguntas interativas no terminal.
2. Busca candidatos nas bases selecionadas.
3. Deduplica, aplica filtro temporal e envia os candidatos para a OpenAI.
4. A OpenAI devolve JSON estruturado para a triagem e a análise final.
5. O Python monta o .org e o SVG localmente, de forma determinística.

Dependências sugeridas:
    pip install openai requests python-dotenv pydantic prompt_toolkit

Variáveis de ambiente aceitas:
    OPENAI_API_KEY
    SEMANTIC_SCHOLAR_API_KEY   (opcional)
    SCOPUS_API_KEY             (necessária para Scopus)
    SCOPUS_INSTTOKEN           (opcional, conforme entitlement Elsevier)
    WOS_API_KEY                (necessária para Web of Science Starter API)

Exemplo:
    python gerar_atividade_prisma_api_multibase_interativo.py \
      --disciplina "Teorias de Administração Pública" \
      --professor "Bernardo Buta" \
      --curso "Mestrado de Políticas Públicas e Governo" \
      --tema "stakeholders" \
      --recorte "artigo de revisão recente" \
      --objetivo "localizar um artigo de revisão recente e analisá-lo" \
      --palavras-chave "stakeholder,stakeholders,stakeholder engagement" \
      --bases "semantic_scholar,scopus,web_of_science" \
      --aluno "Gustavo M. Mendes de Tarso"
"""
from __future__ import annotations

import argparse
import hashlib
import json
import logging
import math
import os
import re
import shutil
import subprocess
import sys
import textwrap
import time
import zipfile
import xml.etree.ElementTree as ET
from datetime import datetime
from urllib.parse import urljoin, quote
from dataclasses import dataclass, field, replace
from html import escape, unescape
from pathlib import Path
from typing import Iterable, Literal, Any

try:
    import tomllib  # Python 3.11+
except ImportError:  # pragma: no cover
    try:
        import tomli as tomllib  # type: ignore
    except ImportError:  # pragma: no cover
        tomllib = None  # type: ignore

import requests
from dotenv import load_dotenv, dotenv_values
from openai import OpenAI
from pydantic import BaseModel, Field, ValidationError

try:
    from prompt_toolkit import prompt as pt_prompt
    from prompt_toolkit.completion import PathCompleter, WordCompleter
    PROMPT_TOOLKIT_AVAILABLE = True
except ImportError:  # pragma: no cover - dependência opcional em runtime
    pt_prompt = None
    PathCompleter = None
    WordCompleter = None
    PROMPT_TOOLKIT_AVAILABLE = False


DEFAULT_MODEL = "gpt-5.4"
DEFAULT_BASES = ["semantic_scholar"]
DEFAULT_MODO = "revisao_sistematica"
DEFAULT_TIPO_ESTUDO = "artigo de revisão"
DEFAULT_TIPO_ESTUDO_EMPIRICO = "estudo empírico"

REVIEW_STUDY_TYPE_CHOICES: dict[str, str] = {
    "1": "Revisão sistemática",
    "2": "Revisão de literatura",
    "3": "Scoping review",
    "4": "Metanálise",
    "5": "Qualquer revisão",
    "6": "Personalizado",
}

EMPIRICAL_STUDY_TYPE_CHOICES: dict[str, str] = {
    "1": "Estudo empírico em geral",
    "2": "Estudo de caso",
    "3": "Estudo qualitativo",
    "4": "Estudo quantitativo",
    "5": "Métodos mistos",
    "6": "Survey",
    "7": "Entrevistas / análise qualitativa",
    "8": "Personalizado",
}
DEFAULT_PERIODO = "2022-2026"
DEFAULT_IDIOMAS = "inglês,português"
DEFAULT_TRIAGEM = 12
DEFAULT_SELECIONADOS = 3
DEFAULT_POLO = "Brasília"
DEFAULT_TURMA = "T-01"
DEFAULT_CITATION_STYLE = "ABNT"
DEFAULT_ORG_MODEL_FILENAME = "template_research.org"
DEFAULT_ORG_LATEX_CLASS_INIT = "/home/gustavodetarso/.emacs.d/lisp/academic-writing.el"
DEFAULT_LATEX_EXTRA_PATH = "/home/gustavodetarso/texmf/tex/latex/fgv/fgv-paper.sty"
DEFAULT_PDF_EXPORT_COMMAND = ""
DEFAULT_FGV_LOGO_PATH = "/home/gustavodetarso/Documentos/.share/mgs_org/fgv.png"

PT_MONTHS = {1: "janeiro", 2: "fevereiro", 3: "março", 4: "abril", 5: "maio", 6: "junho", 7: "julho", 8: "agosto", 9: "setembro", 10: "outubro", 11: "novembro", 12: "dezembro"}

def today_pt_br() -> str:
    now = datetime.now()
    return f"{now.day} de {PT_MONTHS[now.month]} de {now.year}"

CITATION_STYLE_CHOICES = {
    "abnt": "ABNT",
    "apa": "APA",
    "chicago": "Chicago",
    "mla": "MLA",
    "vancouver": "Vancouver",
}

REMOVABLE_OUTPUT_SUFFIXES = {".aux", ".log", ".out", ".tex", ".toc", ".fls", ".fdb_latexmk", ".bbl", ".blg", ".synctex.gz", ".pdf_tex", ".xdv"}
REMOVABLE_OUTPUT_EXACT_NAMES = {"svg-inkscape"}

S2_SEARCH_URL = "https://api.semanticscholar.org/graph/v1/paper/search"
S2_BULK_SEARCH_URL = "https://api.semanticscholar.org/graph/v1/paper/search/bulk"
SEMANTIC_SCHOLAR_DEFAULT_MIN_INTERVAL_SECONDS = 1.25
SEMANTIC_SCHOLAR_DEFAULT_MAX_RETRIES = 3
_SEMANTIC_SCHOLAR_LAST_REQUEST_MONOTONIC = 0.0
SCOPUS_SEARCH_URL = "https://api.elsevier.com/content/search/scopus"
WOS_STARTER_URL = "https://api.clarivate.com/apis/wos-starter/v1/documents"
PUBMED_ESEARCH_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
PUBMED_EFETCH_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"
OPENALEX_WORKS_URL = "https://api.openalex.org/works"
CROSSREF_WORKS_URL = "https://api.crossref.org/works"
EUROPEPMC_SEARCH_URL = "https://www.ebi.ac.uk/europepmc/webservices/rest/search"
CORE_SEARCH_URL = "https://api.core.ac.uk/v3/search/works"

SOURCE_LABELS = {
    "semantic_scholar": "Semantic Scholar",
    "scopus": "Scopus",
    "web_of_science": "Web of Science",
    "pubmed": "PubMed",
    "openalex": "OpenAlex",
    "crossref": "Crossref",
    "europe_pmc": "Europe PMC",
    "core": "CORE",
}

PRISMA_STATEMENT_REF = (
    "PAGE, Matthew J. et al. *The PRISMA 2020 statement: an updated guideline "
    "for reporting systematic reviews*. BMJ, 2021."
)


SCRIPT_DIR = Path(__file__).resolve().parent
ENV_FILE = SCRIPT_DIR / ".env"
CONTROLLED_ENV_KEYS = (
    "OPENAI_API_KEY",
    "SEMANTIC_SCHOLAR_API_KEY",
    "SCOPUS_API_KEY",
    "SCOPUS_INSTTOKEN",
    "WOS_API_KEY",
    "NCBI_API_KEY",
    "NCBI_EMAIL",
    "OPENALEX_API_KEY",
    "OPENALEX_EMAIL",
    "CROSSREF_EMAIL",
    "EUROPEPMC_EMAIL",
    "CORE_API_KEY",
    "CORE_EMAIL",
    "HTTP_PROXY",
    "HTTPS_PROXY",
    "OPENAI_MODEL",
)


def load_local_env_file() -> Path | None:
    """Carrega sempre o .env do diretório do script, sobrescrevendo o ambiente."""
    if not ENV_FILE.exists():
        return None
    values = dotenv_values(ENV_FILE)
    for key in CONTROLLED_ENV_KEYS:
        value = values.get(key)
        if value not in (None, ""):
            os.environ[key] = str(value).strip()
    load_dotenv(dotenv_path=ENV_FILE, override=True)
    return ENV_FILE


def fallback_work_title(config: "Config") -> str:
    tema = config.tema.strip()
    recorte = config.recorte.strip()
    tipo = config.tipo_estudo.strip()
    base = f"{tema}: análise de {tipo}"
    if recorte:
        return textwrap.shorten(f"{base} sobre {recorte}", width=140, placeholder="…")
    return textwrap.shorten(base, width=140, placeholder="…")


def study_type_title_phrase(config: "Config") -> str:
    tipo = (config.tipo_estudo or "").strip()
    modo = (config.modo or "").strip()
    if tipo:
        return tipo
    return "revisão sistemática" if modo == "revisao_sistematica" else "pesquisa empírica"


def ensure_title_mentions_study_type(title: str, config: "Config") -> str:
    title = (title or "").strip()
    if not title:
        return fallback_work_title(config)
    phrase = study_type_title_phrase(config).strip()
    if not phrase:
        return title
    low_title = title.casefold()
    low_phrase = phrase.casefold()
    generic = ("revisão" if config.modo == "revisao_sistematica" else "empír")
    if low_phrase in low_title or generic in low_title:
        return textwrap.shorten(title, width=160, placeholder="…")
    if ":" in title:
        candidate = f"{title} ({phrase})"
    else:
        candidate = f"{title}: {phrase}"
    return textwrap.shorten(candidate, width=160, placeholder="…")


def strip_org_cite_directives(doc: str) -> str:
    banned = ("#+cite_export:", "#+bibliography:", "#+print_bibliography:")
    kept = []
    for line in doc.splitlines():
        if line.strip().lower().startswith(banned):
            continue
        kept.append(line)
    return "\n".join(kept).strip() + "\n"


def org_uses_citation_pipeline(doc: str) -> bool:
    if not doc or not doc.strip():
        return False
    patterns = (
        r"(?im)^\s*#\+cite_export:",
        r"(?im)^\s*#\+bibliography:",
        r"(?im)^\s*#\+print_bibliography:",
        r"\[cite:[^\]]+\]",
    )
    return any(re.search(pattern, doc) for pattern in patterns)


def sanitize_empirical_conclusion_text(texto: str) -> str:
    if not texto:
        return ""
    linhas = []
    for line in texto.splitlines():
        if re.match(r"^\*+\s+", line.strip()):
            continue
        linhas.append(line)
    cleaned = "\n".join(linhas).strip()
    cleaned = re.sub(r"^(Introdução|INTRODUÇÃO)\s*\n+", "", cleaned)
    return cleaned.strip()


def normalize_citation_style(value: str | None) -> str:
    if not value:
        return DEFAULT_CITATION_STYLE
    raw = value.strip()
    lower = raw.lower()
    aliases = {
        "abnt": "ABNT",
        "apa": "APA",
        "apa 7": "APA",
        "apa 7th": "APA",
        "apa7": "APA",
        "chicago": "Chicago",
        "chicago author-date": "Chicago",
        "mla": "MLA",
        "vancouver": "Vancouver",
    }
    return aliases.get(lower, raw)


def format_prisma_statement_reference(style: str) -> str:
    style = normalize_citation_style(style)
    refs = {
        "ABNT": "PAGE, Matthew J. et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ, v. 372, p. n71, 2021.",
        "APA": "Page, M. J., McKenzie, J. E., Bossuyt, P. M., Boutron, I., Hoffmann, T. C., Mulrow, C. D., et al. (2021). The PRISMA 2020 statement: An updated guideline for reporting systematic reviews. BMJ, 372, n71.",
        "Chicago": "Page, Matthew J., Joanne E. McKenzie, Patrick M. Bossuyt, Isabelle Boutron, Tammy C. Hoffmann, Cynthia D. Mulrow, et al. 2021. 'The PRISMA 2020 Statement: An Updated Guideline for Reporting Systematic Reviews.' BMJ 372: n71.",
        "MLA": "Page, Matthew J., et al. 'The PRISMA 2020 Statement: An Updated Guideline for Reporting Systematic Reviews.' BMJ, vol. 372, 2021, p. n71.",
        "Vancouver": "Page MJ, McKenzie JE, Bossuyt PM, Boutron I, Hoffmann TC, Mulrow CD, et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ. 2021;372:n71.",
    }
    return refs.get(style, refs["ABNT"])



def study_type_terms(tipo_estudo: str) -> list[str]:
    """Extrai termos úteis do tipo de estudo para palavras-chave e queries."""
    raw = (tipo_estudo or "").strip()
    if not raw:
        return []
    lower = raw.lower()
    buckets: list[str] = []

    if "systematic" in lower or "sistem" in lower:
        buckets.extend(["systematic review", "revisão sistemática"])
    if "literature review" in lower or "revisão de literatura" in lower:
        buckets.extend(["literature review", "revisão de literatura"])
    if "scoping" in lower:
        buckets.extend(["scoping review", "revisão de escopo"])
    if "integrative" in lower or "integrativa" in lower:
        buckets.extend(["integrative review", "revisão integrativa"])
    if "narrative" in lower or "narrativa" in lower:
        buckets.extend(["narrative review", "revisão narrativa"])
    if "meta-analysis" in lower or "meta analysis" in lower or "meta-análise" in lower or "metanálise" in lower:
        buckets.extend(["meta-analysis", "meta-análise"])
    if "review" in lower or "revis" in lower:
        buckets.extend(["review", "revisão"])

    buckets.append(raw)

    seen: set[str] = set()
    out: list[str] = []
    for item in buckets:
        key = item.strip().lower()
        if key and key not in seen:
            seen.add(key)
            out.append(item.strip())
    return out


def ensure_study_type_in_keywords(palavras: list[str], tipo_estudo: str) -> list[str]:
    base = [str(p).strip() for p in palavras if str(p).strip()]
    extras = study_type_terms(tipo_estudo)
    seen: set[str] = set()
    out: list[str] = []
    for item in base + extras:
        key = item.lower()
        if key not in seen:
            seen.add(key)
            out.append(item)
    return out


def build_study_type_clause(tipo_estudo: str) -> str:
    terms = study_type_terms(tipo_estudo)
    if not terms:
        terms = ["systematic review", "literature review", "review"]
    return " OR ".join(f'"{t}"' if " " in t else t for t in terms)


BILINGUAL_TERM_MAP: dict[str, list[str]] = {
    "governanca": ["governance", "public governance", "governança"],
    "governança": ["governance", "public governance", "governanca"],
    "governance": ["governança", "governanca", "public governance"],
    "governanca publica": ["public governance", "governança pública"],
    "governança pública": ["public governance", "governanca publica"],
    "public governance": ["governança pública", "governanca publica"],
    "administracao publica": ["public administration", "administração pública"],
    "administração pública": ["public administration", "administracao publica"],
    "public administration": ["administração pública", "administracao publica"],
    "servico publico": ["public service", "setor público", "serviço público"],
    "serviço público": ["public service", "setor público", "servico publico"],
    "public service": ["serviço público", "servico publico", "setor público"],
    "setor publico": ["public sector", "setor público"],
    "setor público": ["public sector", "setor publico"],
    "public sector": ["setor público", "setor publico"],
    "integridade": ["integrity"],
    "integrity": ["integridade"],
    "controle interno": ["internal control", "controles internos"],
    "controles internos": ["internal controls", "controle interno"],
    "internal control": ["controle interno", "controles internos"],
    "internal controls": ["controle interno", "controles internos"],
    "accountability": ["accountability", "prestação de contas"],
    "prestacao de contas": ["accountability", "prestação de contas"],
    "prestação de contas": ["accountability", "prestacao de contas"],
    "gestao de riscos": ["risk management", "gestão de riscos"],
    "gestão de riscos": ["risk management", "gestao de riscos"],
    "risk management": ["gestão de riscos", "gestao de riscos"],
    "compliance": ["compliance"],
    "stakeholders": ["partes interessadas"],
    "stakeholder": ["parte interessada"],
    "partes interessadas": ["stakeholders"],
    "parte interessada": ["stakeholder"],
    "capacidades estatais": ["state capacity", "state capabilities"],
    "capacidade estatal": ["state capacity", "state capability"],
    "state capacity": ["capacidades estatais", "state capabilities"],
    "state capabilities": ["capacidades estatais", "state capacity"],
    "capacidade coercitiva": ["coercive capacity", "state coercion"],
    "coercive capacity": ["capacidade coercitiva", "state coercion"],
    "centralizacao do poder": ["political centralization", "administrative centralization"],
    "centralização do poder": ["political centralization", "administrative centralization"],
    "political centralization": ["centralização do poder", "administrative centralization"],
    "desempenho estatal": ["state performance", "government effectiveness", "policy performance"],
    "state performance": ["desempenho estatal", "government effectiveness", "policy performance"],
}


def _normalize_key(text: str) -> str:
    return slugify(text).replace('_', ' ').strip()


def languages_include_both_pt_en(idiomas: list[str] | None) -> bool:
    langs = ' '.join((idiomas or [])).lower()
    has_pt = any(tok in langs for tok in ['portugues', 'português', 'pt-br', 'pt_br', 'pt'])
    has_en = any(tok in langs for tok in ['ingles', 'inglês', 'english', 'en'])
    return has_pt and has_en




def _ascii_fold(text: str) -> str:
    repl = {
        "á": "a", "à": "a", "â": "a", "ã": "a", "ä": "a",
        "é": "e", "ê": "e", "è": "e", "ë": "e",
        "í": "i", "ì": "i", "î": "i", "ï": "i",
        "ó": "o", "ô": "o", "õ": "o", "ò": "o", "ö": "o",
        "ú": "u", "ù": "u", "û": "u", "ü": "u",
        "ç": "c", "ñ": "n",
    }
    out = text.casefold()
    for old, new in repl.items():
        out = out.replace(old, new)
    return out


LANGUAGE_ALIASES = {
    "ingles": "english", "inglês": "english", "english": "english", "en": "english", "eng": "english",
    "portugues": "portuguese", "português": "portuguese", "portuguese": "portuguese", "pt": "portuguese", "por": "portuguese",
    "espanhol": "spanish", "spanish": "spanish", "es": "spanish", "spa": "spanish",
    "frances": "french", "francês": "french", "french": "french", "fr": "french", "fre": "french", "fra": "french",
    "alemao": "german", "alemão": "german", "german": "german", "de": "german", "ger": "german", "deu": "german",
    "italiano": "italian", "italian": "italian", "it": "italian", "ita": "italian",
    "russo": "russian", "russian": "russian", "ru": "russian", "rus": "russian",
    "ucraniano": "ukrainian", "ukrainian": "ukrainian", "uk": "ukrainian", "ukr": "ukrainian",
    "indonesio": "indonesian", "indonésio": "indonesian", "indonesian": "indonesian", "id": "indonesian", "ind": "indonesian",
}

SCOPUS_LANGUAGE_LABELS = {
    "english": "English",
    "portuguese": "Portuguese",
    "spanish": "Spanish",
    "french": "French",
    "german": "German",
    "italian": "Italian",
    "russian": "Russian",
    "ukrainian": "Ukrainian",
    "indonesian": "Indonesian",
}

WOS_LANGUAGE_LABELS = SCOPUS_LANGUAGE_LABELS

REPORT_LANGUAGE_LABELS = {
    "english": "inglês",
    "portuguese": "português",
    "spanish": "espanhol",
    "french": "francês",
    "german": "alemão",
    "italian": "italiano",
    "russian": "russo",
    "ukrainian": "ucraniano",
    "indonesian": "indonésio",
}


def normalize_language_name(value: object | None) -> str | None:
    if value is None:
        return None

    if isinstance(value, dict):
        for key_name in ("code", "lang", "language", "name", "label", "value"):
            inner = value.get(key_name)
            if inner not in (None, ""):
                return normalize_language_name(inner)
        return None

    if isinstance(value, (list, tuple, set)):
        for item in value:
            norm = normalize_language_name(item)
            if norm:
                return norm
        return None

    raw = str(value).strip()
    if not raw:
        return None

    if raw.startswith("{") and raw.endswith("}"):
        match = re.search(
            r"[\'\"]?(?:code|lang|language|name|label|value)[\'\"]?\s*:\s*[\'\"]([^\'\"]+)[\'\"]",
            raw,
            flags=re.IGNORECASE,
        )
        if match:
            raw = match.group(1).strip()

    if raw.startswith("[") and raw.endswith("]"):
        match = re.search(r"[\'\"]([^\'\"]+)[\'\"]", raw)
        if match:
            raw = match.group(1).strip()

    parts = re.split(r"[,;/|]+", raw)
    normalized_parts = []
    for part in parts:
        key = _ascii_fold(part).strip().replace("_", "-")
        key = re.sub(r"\s+", " ", key)
        if not key:
            continue
        normalized_parts.append(LANGUAGE_ALIASES.get(key, key))
    return normalized_parts[0] if normalized_parts else None


def display_language_name(value: object | None) -> str:
    norm = normalize_language_name(value)
    if norm:
        return REPORT_LANGUAGE_LABELS.get(norm, norm)
    if value is None:
        return "não identificado"
    raw = str(value).strip()
    if not raw:
        return "não identificado"
    if raw.startswith("{") and raw.endswith("}"):
        match = re.search(
            r"[\'\"]?(?:code|lang|language|name|label|value)[\'\"]?\s*:\s*[\'\"]([^\'\"]+)[\'\"]",
            raw,
            flags=re.IGNORECASE,
        )
        if match:
            return display_language_name(match.group(1).strip())
    if raw.startswith("[") and raw.endswith("]"):
        match = re.search(r"[\'\"]([^\'\"]+)[\'\"]", raw)
        if match:
            return display_language_name(match.group(1).strip())
    return raw


def allowed_language_set(idiomas: list[str] | None) -> set[str]:
    allowed: set[str] = set()
    for item in idiomas or []:
        norm = normalize_language_name(item)
        if norm:
            allowed.add(norm)
    return allowed


def scopus_language_filter(idiomas: list[str] | None) -> str:
    allowed = allowed_language_set(idiomas)
    labels = [SCOPUS_LANGUAGE_LABELS.get(lang) for lang in sorted(allowed)]
    labels = [label for label in labels if label]
    if not labels:
        return ""
    joined = " OR ".join(f'LIMIT-TO(LANGUAGE, "{label}")' for label in labels)
    return f"({joined})"


def wos_language_filter(idiomas: list[str] | None) -> str:
    allowed = allowed_language_set(idiomas)
    labels = [WOS_LANGUAGE_LABELS.get(lang) for lang in sorted(allowed)]
    labels = [label for label in labels if label]
    if not labels:
        return ""
    joined = " OR ".join(labels)
    return f"LA=({joined})"


def append_scopus_language_filter(query: str, idiomas: list[str] | None) -> str:
    filt = scopus_language_filter(idiomas)
    if not filt or not query:
        return query
    if "LIMIT-TO(LANGUAGE" in query.upper():
        return query
    return f"{query} AND {filt}"


def append_wos_language_filter(query: str, idiomas: list[str] | None) -> str:
    filt = wos_language_filter(idiomas)
    if not filt or not query:
        return query
    if "LA=(" in query.upper() or "LANGUAGE" in query.upper():
        return query
    return f"{query} AND {filt}"


def _contains_non_latin_script(text: str) -> bool:
    return bool(re.search(r"[\u0370-\u03FF\u0400-\u052F\u0590-\u05FF\u0600-\u06FF\u0900-\u097F\u3040-\u30FF\u3400-\u9FFF]", text or ""))


def candidate_language_allowed(candidate: "CandidatePaper", idiomas: list[str] | None) -> tuple[bool, str | None]:
    allowed = allowed_language_set(idiomas)
    if not allowed:
        return True, None
    cand_lang = normalize_language_name(candidate.language)
    if cand_lang:
        if cand_lang in allowed:
            return True, None
        return False, f"idioma informado pela base fora do escopo: {display_language_name(candidate.language)}"
    latin_allowed = allowed <= {"english", "portuguese", "spanish", "french", "german", "italian"}
    if latin_allowed and _contains_non_latin_script(candidate.title):
        return False, "idioma/script do título incompatível com os idiomas permitidos"
    return True, None


def filter_candidates_by_language(candidates: list["CandidatePaper"], idiomas: list[str] | None) -> tuple[list["CandidatePaper"], int, list[str]]:
    kept: list[CandidatePaper] = []
    warnings: list[str] = []
    removed = 0
    for cand in candidates:
        ok, reason = candidate_language_allowed(cand, idiomas)
        if ok:
            kept.append(cand)
        else:
            removed += 1
            warnings.append(f"Excluído por idioma fora do escopo ({', '.join(idiomas or [])}): {cand.title}. Motivo: {reason}.")
    return kept, removed, warnings


def expand_bilingual_terms(terms: list[str], tema: str = '', recorte: str = '', idiomas: list[str] | None = None, enabled: bool = False) -> list[str]:
    if not enabled:
        return [t for t in terms if t]

    pool = [t.strip() for t in terms if t and str(t).strip()]
    for extra in [tema, recorte]:
        if extra and extra.strip():
            pool.append(extra.strip())

    out: list[str] = []
    seen: set[str] = set()

    def add(term: str) -> None:
        term = term.strip()
        if not term:
            return
        key = term.lower()
        if key not in seen:
            seen.add(key)
            out.append(term)

    normalized_pool = [(_normalize_key(item), item) for item in pool]
    for _, original in normalized_pool:
        add(original)

    for normalized, original in normalized_pool:
        for key, values in BILINGUAL_TERM_MAP.items():
            if key and key in normalized:
                for value in values:
                    add(value)

    if languages_include_both_pt_en(idiomas):
        for term in list(out):
            normalized = _normalize_key(term)
            for key, values in BILINGUAL_TERM_MAP.items():
                if key == normalized:
                    for value in values:
                        add(value)

    return out


class CandidateDecision(BaseModel):
    paper_id: str
    stage: Literal["incluido", "excluido_triagem", "excluido_elegibilidade"]
    tipo_estudo: str
    motivo: str
    ranking: int = Field(ge=1, description="Posição ordinal de aderência; 1 = mais semelhante à tríade tema-recorte-objetivo")
    aderencia_score: int = Field(ge=0, le=100, description="Score de aderência à tríade tema-recorte-objetivo")
    alinhado_triada: bool = Field(description="Indica se o texto ainda se mantém claramente dentro da tríade tema-recorte-objetivo")


class TriageOutput(BaseModel):
    pergunta_orientadora: str
    introducao: str
    base_logica_busca: str
    criterios_inclusao: list[str]
    criterios_exclusao: list[str]
    observacao_metodologica: str
    selected_paper_ids: list[str]
    selected_papers_justification: str
    selection_warning: str | None = None
    decisions: list[CandidateDecision]



class MissingDecisionBatchOutput(BaseModel):
    decisions: list[CandidateDecision]


def enforce_included_top_ranking(parsed: TriageOutput) -> tuple[TriageOutput, str | None]:
    """Reorganiza a lista final para que textos incluídos ocupem o topo do ranking.

    Mantém a ordem relativa previamente atribuída pela IA dentro de cada grupo
    (incluídos e não incluídos) e apenas corrige a inconsistência estrutural
    quando candidatos excluídos aparecem acima dos incluídos.
    """
    ordered = sorted(parsed.decisions, key=lambda x: (x.ranking, -x.aderencia_score, x.paper_id))
    included = [d for d in ordered if d.stage == "incluido"]
    others = [d for d in ordered if d.stage != "incluido"]
    if not included:
        return parsed, None
    current_included_ranks = [d.ranking for d in included]
    expected = list(range(1, len(included) + 1))
    if current_included_ranks == expected:
        return parsed, None

    rebuilt = included + others
    repaired_decisions: list[CandidateDecision] = []
    for idx, d in enumerate(rebuilt, start=1):
        repaired_decisions.append(
            CandidateDecision(
                paper_id=d.paper_id,
                stage=d.stage,
                tipo_estudo=d.tipo_estudo,
                motivo=d.motivo,
                ranking=idx,
                aderencia_score=d.aderencia_score,
                alinhado_triada=d.alinhado_triada,
            )
        )
    parsed = TriageOutput(
        pergunta_orientadora=parsed.pergunta_orientadora,
        introducao=parsed.introducao,
        base_logica_busca=parsed.base_logica_busca,
        criterios_inclusao=parsed.criterios_inclusao,
        criterios_exclusao=parsed.criterios_exclusao,
        observacao_metodologica=parsed.observacao_metodologica,
        decisions=repaired_decisions,
        selected_paper_ids=[d.paper_id for d in repaired_decisions if d.stage == "incluido"],
        selected_papers_justification=parsed.selected_papers_justification,
        selection_warning=parsed.selection_warning,
    )
    return parsed, (
        "Triagem retornou ranking inconsistente, com texto(s) excluído(s) acima de texto(s) incluído(s); "
        "o ranking foi reorganizado automaticamente para que os incluídos ocupem o topo."
    )


def _normalize_paper_id(value: str) -> str:
    value = (value or "").strip()
    value = re.sub(r"\s+", "", value)
    return value.lower()


def repair_triage_output(
    parsed: TriageOutput,
    candidates: list[CandidatePaper],
    *,
    auto_fill_missing: bool = True,
    missing_reason: str = "Excluído automaticamente porque a triagem retornada pela IA omitiu este candidato.",
) -> tuple[TriageOutput, list[str], list[str]]:
    warnings: list[str] = []
    candidate_map = {c.paper_id: c for c in candidates}
    normalized_candidate_map = {_normalize_paper_id(c.paper_id): c.paper_id for c in candidates}

    repaired_decisions: list[CandidateDecision] = []
    seen_ids: set[str] = set()
    extras: list[str] = []

    for d in parsed.decisions:
        pid = d.paper_id
        if pid not in candidate_map:
            mapped = normalized_candidate_map.get(_normalize_paper_id(pid))
            if mapped:
                pid = mapped
            else:
                extras.append(d.paper_id)
                continue
        if pid in seen_ids:
            continue
        seen_ids.add(pid)
        repaired_decisions.append(
            CandidateDecision(
                paper_id=pid,
                stage=d.stage,
                tipo_estudo=d.tipo_estudo,
                motivo=d.motivo,
                ranking=d.ranking,
                aderencia_score=d.aderencia_score,
                alinhado_triada=d.alinhado_triada,
            )
        )

    if extras:
        warnings.append(
            "Triagem retornou decisões com paper_id inexistente e elas foram descartadas: "
            + ", ".join(sorted(extras))
        )

    if repaired_decisions:
        min_score = min(d.aderencia_score for d in repaired_decisions)
        max_rank = max(d.ranking for d in repaired_decisions)
    else:
        min_score = 0
        max_rank = 0

    missing_ids = [c.paper_id for c in candidates if c.paper_id not in seen_ids]
    if auto_fill_missing:
        for offset, pid in enumerate(missing_ids, start=1):
            cand = candidate_map[pid]
            repaired_decisions.append(
                CandidateDecision(
                    paper_id=pid,
                    stage="excluido_triagem",
                    tipo_estudo=cand.document_type or "não identificado",
                    motivo=missing_reason,
                    ranking=max_rank + offset,
                    aderencia_score=max(0, min_score - offset),
                    alinhado_triada=False,
                )
            )
        if missing_ids:
            warnings.append(
                "Triagem ainda retornou menos decisões do que candidatos após as tentativas de complementação; "
                "os itens faltantes foram preenchidos por fallback documental: "
                + ", ".join(missing_ids)
            )
    else:
        if missing_ids:
            warnings.append(
                "Triagem retornou menos decisões do que candidatos; será solicitada complementação para os itens faltantes: "
                + ", ".join(missing_ids)
            )

    repaired_decisions = sorted(repaired_decisions, key=lambda x: (x.ranking, -x.aderencia_score, x.paper_id))
    repaired_decisions = [
        CandidateDecision(
            paper_id=d.paper_id,
            stage=d.stage,
            tipo_estudo=d.tipo_estudo,
            motivo=d.motivo,
            ranking=i,
            aderencia_score=d.aderencia_score,
            alinhado_triada=d.alinhado_triada,
        )
        for i, d in enumerate(repaired_decisions, start=1)
    ]

    allowed_selected = {d.paper_id for d in repaired_decisions if d.stage == "incluido"}
    normalized_selected_ids = []
    seen_selected: set[str] = set()
    for pid in parsed.selected_paper_ids:
        mapped = pid if pid in candidate_map else normalized_candidate_map.get(_normalize_paper_id(pid))
        if not mapped or mapped not in allowed_selected or mapped in seen_selected:
            continue
        seen_selected.add(mapped)
        normalized_selected_ids.append(mapped)

    included_ranked_ids = [d.paper_id for d in repaired_decisions if d.stage == "incluido"]
    if normalized_selected_ids != included_ranked_ids:
        normalized_selected_ids = included_ranked_ids

    repaired = TriageOutput(
        pergunta_orientadora=parsed.pergunta_orientadora,
        introducao=parsed.introducao,
        base_logica_busca=parsed.base_logica_busca,
        criterios_inclusao=parsed.criterios_inclusao,
        criterios_exclusao=parsed.criterios_exclusao,
        observacao_metodologica=parsed.observacao_metodologica,
        selected_paper_ids=normalized_selected_ids,
        selected_papers_justification=parsed.selected_papers_justification,
        selection_warning=parsed.selection_warning,
        decisions=repaired_decisions,
    )
    return repaired, warnings, missing_ids


class PaperAnalysisOutput(BaseModel):
    referencia_completa: str
    resumo_abstract: str
    problema_objetivo: str
    argumento_central: str
    desenho_pesquisa: str
    principais_achados: str
    contribuicao_estudo: str
    justificativa_selecao_final: str
    texto_corrido_entrega: str


class MultiPaperSynthesisOutput(BaseModel):
    texto_sintese_integrada: str


class EmpiricalProjectOutput(BaseModel):
    contextualizacao: str
    problema_pesquisa: str
    justificativa_relevancia: str
    objetivo_geral: str
    objetivos_especificos: list[str]
    proposta_conducao: str
    possibilidades_coleta_dados: list[str]
    possibilidades_analise_dados: list[str]
    hipotese_ou_resposta_teorica: str
    modelo_teorico: str
    texto_corrido_entrega: str


class SearchSuggestionOutput(BaseModel):
    palavras_chave: list[str] = Field(default_factory=list)
    termos_relacionados: list[str] = Field(default_factory=list)

    # Blocos principais usados pelo Python para montar queries determinísticas.
    bloco_tecnologia: list[str] = Field(default_factory=list)
    bloco_contexto: list[str] = Field(default_factory=list)
    bloco_dimensao_analitica: list[str] = Field(default_factory=list)
    bloco_tipo_estudo: list[str] = Field(default_factory=list)

    # Sinônimos/termos equivalentes entram como OR dentro do respectivo bloco.
    sinonimos_tecnologia: list[str] = Field(default_factory=list)
    sinonimos_contexto: list[str] = Field(default_factory=list)
    sinonimos_dimensao_analitica: list[str] = Field(default_factory=list)
    sinonimos_tipo_estudo: list[str] = Field(default_factory=list)

    termos_exclusao: list[str] = Field(default_factory=list)
    query_semantic: str = ""
    query_scopus: str = ""
    query_wos: str = ""
    query_pubmed: str = ""
    query_openalex: str = ""
    query_crossref: str = ""
    query_europepmc: str = ""
    query_core: str = ""
    observacoes: str = ""


class EmpiricalKeywordSuggestionOutput(BaseModel):
    palavras_chave: list[str]
    conceitos_centrais: list[str]
    observacoes: str


class WorkTitleOutput(BaseModel):
    titulo_trabalho: str = Field(description="Título acadêmico em português para a atividade")


@dataclass
class Config:
    modo: str
    disciplina: str
    professor: str
    curso: str
    tema: str
    recorte: str
    objetivo: str
    bases: list[str]
    tipo_estudo: str
    estilo_citacao: str
    periodo: str
    idiomas: list[str]
    palavras_chave: list[str]
    query_bilingue: bool
    aluno: str
    turma: str
    polo: str
    trabalho: str
    titulo_trabalho: str | None
    quantidade_triagem: int
    quantidade_selecionados: int
    model: str
    output_dir: Path
    create_subdiretorio: bool
    org_modelo: Path
    saida_orientacoes_paths: list[Path]
    saida_orientacao_inline: str | None
    texto_orientacao_extra: str | None
    prefixo: str
    query_geral: str | None
    query_semantic: str | None
    query_scopus: str | None
    query_wos: str | None
    query_pubmed: str | None
    query_openalex: str | None
    query_crossref: str | None
    query_europepmc: str | None
    query_core: str | None
    nao_interativo: bool
    exportar_pdf: bool
    salvar_busca_bruta_json: bool
    gerar_env_example: bool
    remover_auxiliares: bool
    incluir_analise_detalhada_ia: bool
    incluir_sintese_integradora_ia: bool
    org_latex_class_init: Path | None
    latex_extra_path: Path | None
    comando_exportacao_pdf: str | None
    fgv_logo_path: Path
    triagem_rigor: str
    triagem_score_hibrido: bool = True
    triagem_orientacoes_paths: list[Path] = field(default_factory=list)
    triagem_orientacao_inline: str | None = None
    triagem_diretivas_extras: str | None = None
    permitir_textos_nao_publicos: bool = False
    config_path: Path | None = None
    salvar_config: bool = False
    config_output_path: Path | None = None

    @property
    def bases_label(self) -> str:
        if not self.bases:
            return "Não se aplica"
        return ", ".join(SOURCE_LABELS.get(src, src) for src in self.bases)

    def source_query(self, source: str) -> str:
        if source == "semantic_scholar" and self.query_semantic:
            return self.query_semantic
        if source == "scopus" and self.query_scopus:
            return self.query_scopus
        if source == "web_of_science" and self.query_wos:
            return self.query_wos
        if source == "pubmed" and self.query_pubmed:
            return self.query_pubmed
        if source == "openalex" and self.query_openalex:
            return self.query_openalex
        if source == "crossref" and self.query_crossref:
            return self.query_crossref
        if source == "europe_pmc" and self.query_europepmc:
            return self.query_europepmc
        if source == "core" and self.query_core:
            return self.query_core
        if self.query_geral:
            return self.query_geral
        return build_query_for_source(
            source,
            self.tema,
            self.palavras_chave,
            self.tipo_estudo,
            recorte=self.recorte,
            objetivo=self.objetivo,
            idiomas=self.idiomas,
            query_bilingue=self.query_bilingue,
            periodo=self.periodo,
        )


@dataclass
class CandidatePaper:
    paper_id: str
    title: str
    abstract: str
    year: int | None
    venue: str | None
    publication_date: str | None
    authors: list[str]
    tldr: str | None
    url: str | None
    pdf_url: str | None
    doi: str | None
    document_type: str | None = None
    language: str | None = None
    sources: list[str] = field(default_factory=list)
    source_ids: dict[str, str] = field(default_factory=dict)
    full_text_verified: bool = False
    full_text_source: str | None = None
    full_text_note: str | None = None
    downloaded_pdf_path: str | None = None
    downloaded_pdf_note: str | None = None
    extracted_pdf_text: str | None = None
    extracted_abstract: str | None = None

    def short_dict(self) -> dict:
        return {
            "paper_id": self.paper_id,
            "title": self.title,
            "year": self.year,
            "venue": self.venue,
            "authors": self.authors,
            "doi": self.doi,
            "document_type": self.document_type,
            "language": self.language,
            "url": self.url,
            "pdf_url": self.pdf_url,
            "tldr": self.tldr,
            "abstract": self.abstract,
            "full_text_verified": self.full_text_verified,
            "full_text_source": self.full_text_source,
            "full_text_note": self.full_text_note,
            "downloaded_pdf_path": self.downloaded_pdf_path,
            "downloaded_pdf_note": self.downloaded_pdf_note,
            "sources": [SOURCE_LABELS.get(s, s) for s in self.sources],
            "source_ids": self.source_ids,
        }


@dataclass
class SourceFetchResult:
    source: str
    query: str
    retrieved: int
    candidates: list[CandidatePaper]
    warnings: list[str] = field(default_factory=list)
    raw_payloads: list[dict] = field(default_factory=list)


@dataclass
class SearchAudit:
    per_source: list[SourceFetchResult]
    identified_total: int
    duplicates_removed: int
    other_removed: int
    screened_total: int
    warnings: list[str] = field(default_factory=list)


@dataclass
class PrismaCounts:
    identified: int
    removed_pre: int
    duplicates_removed: int
    other_removed: int
    screened: int
    excluded_screening: int
    full_text_sought: int
    not_retrieved: int
    full_text_assessed: int
    excluded_full_text: int
    included_qualitative: int


def slugify(text: str) -> str:
    text = text.strip().lower()
    text = re.sub(r"[^a-z0-9áàâãéêíóôõúç\s_-]", "", text, flags=re.I)
    repl = {
        "á": "a", "à": "a", "â": "a", "ã": "a",
        "é": "e", "ê": "e", "í": "i", "ó": "o",
        "ô": "o", "õ": "o", "ú": "u", "ç": "c",
    }
    for k, v in repl.items():
        text = text.replace(k, v)
    text = re.sub(r"[\s_-]+", "_", text)
    return text.strip("_") or "atividade_prisma"


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


TEXT_GUIDANCE_SUFFIXES = {".txt", ".md", ".org", ".rst", ".tex", ".yaml", ".yml", ".json", ".csv", ".xml"}


def _strip_xml_like_tags(text: str) -> str:
    text = re.sub(r"<w:tab[^>]*/>", "\t", text)
    text = re.sub(r"<w:br[^>]*/>", "\n", text)
    text = re.sub(r"<[^>]+>", " ", text)
    text = unescape(text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def read_orientation_file(path: Path, max_chars: int = 20000) -> str:
    suffix = path.suffix.lower()
    if suffix in TEXT_GUIDANCE_SUFFIXES:
        return read_text(path)[:max_chars]
    if suffix == ".docx":
        with zipfile.ZipFile(path) as zf:
            xml = zf.read("word/document.xml").decode("utf-8", errors="ignore")
        return _strip_xml_like_tags(xml)[:max_chars]
    if suffix == ".pdf":
        try:
            from pypdf import PdfReader  # type: ignore
            reader = PdfReader(str(path))
            chunks = []
            for page in reader.pages[:20]:
                chunks.append(page.extract_text() or "")
            return re.sub(r"\s+", " ", "\n".join(chunks)).strip()[:max_chars]
        except Exception:
            pdftotext = shutil.which("pdftotext")
            if pdftotext:
                try:
                    result = subprocess.run([pdftotext, str(path), "-"], capture_output=True, text=True, check=True)
                    return re.sub(r"\s+", " ", result.stdout).strip()[:max_chars]
                except Exception as exc:
                    raise RuntimeError(f"Não foi possível extrair texto do PDF: {exc}") from exc
            raise RuntimeError("Não foi possível extrair texto do PDF. Instale pypdf ou pdftotext.")
    raise RuntimeError(f"Formato de arquivo de orientação não suportado: {suffix}")


SUPPORTED_DIRECTIVE_FILE_SUFFIXES = TEXT_GUIDANCE_SUFFIXES | {".docx", ".pdf"}


def looks_like_directives_file_reference(raw: str) -> bool:
    raw = (raw or "").strip()
    if not raw:
        return False
    suffix = Path(raw).suffix.lower()
    return (
        raw.startswith(".")
        or "/" in raw
        or "\\" in raw
        or suffix in SUPPORTED_DIRECTIVE_FILE_SUFFIXES
    )


def resolve_text_reference_path(raw: str, *, config_path: Path | None = None) -> Path | None:
    raw = (raw or "").strip()
    if not raw or not looks_like_directives_file_reference(raw):
        return None

    raw_path = Path(raw).expanduser()
    candidates: list[Path] = []
    if raw_path.is_absolute():
        candidates.append(raw_path)
    else:
        if config_path is not None and config_path.parent.exists():
            candidates.append((config_path.parent / raw_path).expanduser())
        candidates.append((Path.cwd() / raw_path).expanduser())
        candidates.append(raw_path)

    seen: set[str] = set()
    for candidate in candidates:
        try:
            resolved = candidate.resolve()
        except Exception:
            resolved = candidate
        key = resolved.as_posix()
        if key in seen:
            continue
        seen.add(key)
        if resolved.exists() and resolved.is_file():
            return resolved
    return None


def load_inline_or_file_directives(raw: str | None, *, config_path: Path | None = None, max_chars: int = 20000) -> tuple[str | None, Path | None]:
    raw = (raw or "").strip()
    if not raw:
        return None, None

    resolved = resolve_text_reference_path(raw, config_path=config_path)
    if resolved is not None:
        return read_orientation_file(resolved, max_chars=max_chars).strip(), resolved
    return raw, None


def _clean_extracted_text_for_matching(text: str) -> str:
    text = text.replace("\xad", "")
    text = text.replace("‐", "-").replace("‑", "-").replace("‒", "-").replace("–", "-").replace("—", "-")
    text = re.sub(r"([A-Za-zÀ-ÿ])\s*-\s*([A-Za-zÀ-ÿ])", r"\1\2", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def extract_abstract_from_pdf_text(text: str) -> str | None:
    if not text or not text.strip():
        return None
    clean = _clean_extracted_text_for_matching(text)
    patterns = [
        r"\bAbstract\b[:\s-]*(.+?)(?=\bKeywords?\b|\bKey\s*words?\b|\bIndex\s*Terms?\b|\b1\.?\s*Introduction\b|\bIntroduction\b)",
        r"\bResumo\b[:\s-]*(.+?)(?=\bPalavras[- ]chave\b|\b1\.?\s*Introdu[cç][aã]o\b|\bIntrodu[cç][aã]o\b)",
        r"\bA\s*B\s*S\s*T\s*R\s*A\s*C\s*T\b[:\s-]*(.+?)(?=\bK\s*E\s*Y\s*W\s*O\s*R\s*D\s*S?\b|\b1\.?\s*Introduction\b|\bIntroduction\b)",
    ]
    for pattern in patterns:
        m = re.search(pattern, clean, flags=re.IGNORECASE | re.DOTALL)
        if m:
            abstract = re.sub(r"\s+", " ", m.group(1)).strip(" :-\n\t")
            if len(abstract) >= 120:
                return abstract[:3500].strip()
    markers = ["Abstract", "Resumo", "A B S T R A C T"]
    for marker in markers:
        idx = clean.lower().find(marker.lower())
        if idx != -1:
            snippet = clean[idx + len(marker): idx + len(marker) + 4500]
            end_candidates = []
            for token in ["Keywords", "Key words", "Index Terms", "1. Introduction", "1 Introduction", "Introduction", "Palavras-chave", "Introdução"]:
                pos = snippet.lower().find(token.lower())
                if pos != -1:
                    end_candidates.append(pos)
            end = min(end_candidates) if end_candidates else len(snippet)
            abstract = snippet[:end].strip(" :-\n\t")
            abstract = re.sub(r"\s+", " ", abstract)
            if len(abstract) >= 120:
                return abstract[:3500].strip()
    return None


def enrich_candidate_from_local_pdf(candidate: CandidatePaper, max_chars: int = 120000) -> CandidatePaper:
    local_pdf_path = Path(candidate.downloaded_pdf_path) if candidate.downloaded_pdf_path else None
    if local_pdf_path is None or not local_pdf_path.exists():
        return candidate
    if not candidate.extracted_pdf_text:
        try:
            candidate.extracted_pdf_text = read_orientation_file(local_pdf_path, max_chars=max_chars)
        except Exception:
            candidate.extracted_pdf_text = None
    if candidate.extracted_pdf_text and not candidate.extracted_abstract:
        candidate.extracted_abstract = extract_abstract_from_pdf_text(candidate.extracted_pdf_text)
    if (not candidate.abstract or not candidate.abstract.strip()) and candidate.extracted_abstract:
        candidate.abstract = candidate.extracted_abstract.strip()
    return candidate


def get_candidate_abstract(candidate: CandidatePaper, analysis: PaperAnalysisOutput | None = None) -> str:
    for value in [candidate.abstract, candidate.extracted_abstract, candidate.tldr, getattr(analysis, 'resumo_abstract', None) if analysis else None]:
        if value and str(value).strip():
            return str(value).strip()
    return "Resumo não disponível nos metadados recuperados nem no texto completo baixado localmente."


def candidate_has_non_public_access_reference(candidate: CandidatePaper) -> bool:
    for value in [candidate.url, candidate.pdf_url, candidate.doi]:
        if value and str(value).strip():
            return True
    return False


def fallback_paper_analysis(candidate: CandidatePaper) -> PaperAnalysisOutput:
    resumo = get_candidate_abstract(candidate, None)
    referencia = f"{author_list(candidate.authors)} ({candidate.year or 's.d.'}). {candidate.title}."
    base_text = candidate.extracted_pdf_text or resumo or candidate.title
    base_text = re.sub(r"\s+", " ", base_text)[:2500]
    tem_pdf_local = bool(candidate.downloaded_pdf_path and Path(candidate.downloaded_pdf_path).exists())
    tem_referencia_nao_publica = candidate_has_non_public_access_reference(candidate)
    if tem_pdf_local:
        problema_base = "Com base no texto completo disponível"
        desenho_base = "O desenho de pesquisa pôde ser identificado a partir do texto completo e dos metadados disponíveis."
        achados_base = "Os principais achados identificados no estudo, a partir do texto baixado localmente, podem ser resumidos da seguinte forma:"
        justificativa = "O estudo foi mantido na seleção final por aderência temática e por possuir texto completo baixado localmente."
    elif tem_referencia_nao_publica:
        problema_base = "Com base nos metadados, no resumo disponível e no link verificável do registro"
        desenho_base = "O desenho de pesquisa foi inferido a partir dos metadados disponíveis, sem leitura local do PDF."
        achados_base = "Os principais achados abaixo foram inferidos a partir do resumo e dos metadados disponíveis, pois o PDF não pôde ser baixado localmente:"
        justificativa = "O estudo foi mantido na seleção final por aderência temática, apesar de não haver download local do PDF; a análise foi limitada a metadados, resumo e link verificável do registro."
    else:
        problema_base = "Com base apenas nos metadados disponíveis"
        desenho_base = "O desenho de pesquisa foi inferido apenas a partir dos metadados disponíveis."
        achados_base = "Os principais achados abaixo foram inferidos apenas a partir dos metadados disponíveis:"
        justificativa = "O estudo foi mantido na seleção final por aderência temática, com análise limitada aos metadados disponíveis."
    return PaperAnalysisOutput(
        referencia_completa=referencia,
        resumo_abstract=resumo,
        problema_objetivo=f"{problema_base}, o estudo investiga o tema '{candidate.title}' no contexto desta atividade. Trecho-base: {base_text[:700]}",
        argumento_central=f"O argumento central extraído do estudo enfatiza a contribuição do trabalho para o tema analisado. Trecho-base: {base_text[:700]}",
        desenho_pesquisa=f"{desenho_base} Trecho-base: {base_text[:700]}",
        principais_achados=f"{achados_base} {base_text[:900]}",
        contribuicao_estudo=f"O estudo contribui para o tema desta atividade ao oferecer evidências, argumentos ou sínteses compatíveis com a tríade tema-recorte-objetivo. Trecho-base: {base_text[:800]}",
        justificativa_selecao_final=justificativa,
        texto_corrido_entrega=f"{candidate.title}. {base_text[:1800]}"
    )


def setup_logging(output_dir: Path, prefixo: str) -> tuple[logging.Logger, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    log_path = output_dir / f"{prefixo}.log"
    logger = logging.getLogger(f"atividade_prisma.{prefixo}")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")

    fh = logging.FileHandler(log_path, encoding="utf-8")
    fh.setFormatter(formatter)
    logger.addHandler(fh)

    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(formatter)
    logger.addHandler(sh)
    logger.propagate = False
    return logger, log_path


TOTAL_PROGRESS_PHASES = 11


def log_phase(logger: logging.Logger, step: int, message: str, *, total: int = TOTAL_PROGRESS_PHASES) -> None:
    banner = f"[FASE {step}/{total}] {message}"
    separator = "=" * max(24, len(banner))
    logger.info(separator)
    logger.info(banner)
    logger.info(separator)


def log_subphase(logger: logging.Logger | None, message: str) -> None:
    if logger is not None:
        cleaned = (message or "").strip()
        if cleaned.startswith("[ANDAMENTO]"):
            logger.info(cleaned)
        else:
            logger.info("[ANDAMENTO] %s", cleaned)



def write_env_example(path: Path) -> None:
    content = textwrap.dedent("""
    # OpenAI
    OPENAI_API_KEY=
    OPENAI_MODEL=gpt-5.4

    # Bases acadêmicas
    SEMANTIC_SCHOLAR_API_KEY=
    SCOPUS_API_KEY=
    SCOPUS_INSTTOKEN=
    WOS_API_KEY=
    NCBI_API_KEY=
    NCBI_EMAIL=

    # Opcional
    HTTP_PROXY=
    HTTPS_PROXY=
    """).strip() + "\n"
    write_text(path, content)



# =========================
# Arquivo de configuração TOML/JSON
# =========================

CONFIG_ARG_ALIASES: dict[str, str] = {
    "modo": "modo",
    "disciplina": "disciplina",
    "professor": "professor",
    "curso": "curso",
    "tema": "tema",
    "recorte": "recorte",
    "objetivo": "objetivo",
    "bases": "bases",
    "tipo_estudo": "tipo_estudo",
    "tipo-estudo": "tipo_estudo",
    "estilo_citacao": "estilo_citacao",
    "estilo-citacao": "estilo_citacao",
    "periodo": "periodo",
    "idiomas": "idiomas",
    "palavras_chave": "palavras_chave",
    "palavras-chave": "palavras_chave",
    "query_bilingue": "query_bilingue",
    "query-bilingue": "query_bilingue",
    "aluno": "aluno",
    "turma": "turma",
    "polo": "polo",
    "trabalho": "trabalho",
    "quantidade_triagem": "quantidade_triagem",
    "quantidade-triagem": "quantidade_triagem",
    "quantidade_selecionados": "quantidade_selecionados",
    "quantidade-selecionados": "quantidade_selecionados",
    "model": "model",
    "sugerir_palavras_chave_ia": "sugerir_palavras_chave_ia",
    "sugerir-palavras-chave-ia": "sugerir_palavras_chave_ia",
    "query_geral": "query_geral",
    "query-geral": "query_geral",
    "query_semantic": "query_semantic",
    "query-semantic": "query_semantic",
    "query_scopus": "query_scopus",
    "query-scopus": "query_scopus",
    "query_wos": "query_wos",
    "query-wos": "query_wos",
    "query_pubmed": "query_pubmed",
    "query-pubmed": "query_pubmed",
    "query_openalex": "query_openalex",
    "query-openalex": "query_openalex",
    "query_crossref": "query_crossref",
    "query-crossref": "query_crossref",
    "query_europepmc": "query_europepmc",
    "query-europepmc": "query_europepmc",
    "query_europe_pmc": "query_europepmc",
    "query-europe-pmc": "query_europepmc",
    "query_core": "query_core",
    "query-core": "query_core",
    "salvar_busca_bruta_json": "salvar_busca_bruta_json",
    "salvar-busca-bruta-json": "salvar_busca_bruta_json",
    "incluir_analise_detalhada_ia": "incluir_analise_detalhada_ia",
    "incluir-analise-detalhada-ia": "incluir_analise_detalhada_ia",
    "incluir_sintese_integradora_ia": "incluir_sintese_integradora_ia",
    "incluir-sintese-integradora-ia": "incluir_sintese_integradora_ia",
    "prefixo": "prefixo",
    "output_dir": "output_dir",
    "output-dir": "output_dir",
    "criar_subdiretorio": "create_subdiretorio",
    "criar-subdiretorio": "create_subdiretorio",
    "create_subdiretorio": "create_subdiretorio",
    "org_modelo": "org_modelo",
    "org-modelo": "org_modelo",
    "saida_orientacoes_paths": "saida_orientacoes_paths",
    "saida-orientacoes-paths": "saida_orientacoes_paths",
    "saida_orientacao_inline": "saida_orientacao_inline",
    "saida-orientacao-inline": "saida_orientacao_inline",
    "exportar_pdf": "exportar_pdf",
    "exportar-pdf": "exportar_pdf",
    "gerar_env_example": "gerar_env_example",
    "gerar-env-example": "gerar_env_example",
    "remover_auxiliares": "remover_auxiliares",
    "remover-auxiliares": "remover_auxiliares",
    "org_latex_class_init": "org_latex_class_init",
    "org-latex-class-init": "org_latex_class_init",
    "latex_extra_path": "latex_extra_path",
    "latex-extra-path": "latex_extra_path",
    "comando_exportacao_pdf": "comando_exportacao_pdf",
    "comando-exportacao-pdf": "comando_exportacao_pdf",
    "fgv_logo_path": "fgv_logo_path",
    "fgv-logo-path": "fgv_logo_path",
    "nao_interativo": "nao_interativo",
    "nao-interativo": "nao_interativo",
    "salvar_config": "salvar_config",
    "salvar-config": "salvar_config",
    "config_output": "config_output",
    "config-output": "config_output",
    "rigor": "triagem_rigor",
    "triagem_rigor": "triagem_rigor",
    "triagem-rigor": "triagem_rigor",
    "permitir_textos_nao_publicos": "permitir_textos_nao_publicos",
    "permitir-textos-nao-publicos": "permitir_textos_nao_publicos",
    "usar_textos_nao_publicos": "permitir_textos_nao_publicos",
    "usar-textos-nao-publicos": "permitir_textos_nao_publicos",
    "triagem_score_hibrido": "triagem_score_hibrido",
    "triagem-score-hibrido": "triagem_score_hibrido",
    "usar_score_hibrido": "triagem_score_hibrido",
    "usar-score-hibrido": "triagem_score_hibrido",
    "triagem_orientacoes_paths": "triagem_orientacoes_paths",
    "triagem-orientacoes-paths": "triagem_orientacoes_paths",
    "triagem_orientacao_inline": "triagem_orientacao_inline",
    "triagem-orientacao-inline": "triagem_orientacao_inline",
}

CONFIG_SECTIONS_ORDER = ("atividade", "pesquisa", "bibliografia", "busca", "triagem", "queries", "saida", "latex", "openai", "controle")


CONFIG_SECTION_ARG_ALIASES = {
    ("saida", "orientacoes_paths"): "saida_orientacoes_paths",
    ("saida", "orientacao_inline"): "saida_orientacao_inline",
    ("triagem", "orientacoes_paths"): "triagem_orientacoes_paths",
    ("triagem", "orientacao_inline"): "triagem_orientacao_inline",

    # compatibilidade opcional com nomenclaturas anteriores
    ("saida", "arquivo_orientacao"): "saida_orientacoes_paths",
    ("triagem", "triagem_prompt_path"): "triagem_orientacoes_paths",
    ("triagem", "diretivas_extras"): "triagem_orientacao_inline",
}


def _config_value_to_arg(value):
    if isinstance(value, list):
        return ",".join(str(x).strip() for x in value if str(x).strip())
    return value


def _split_csv_values(raw: str | list[str] | None) -> list[str]:
    if raw is None:
        return []
    if isinstance(raw, list):
        return [str(x).strip() for x in raw if str(x).strip()]
    return [x.strip() for x in str(raw).split(",") if x.strip()]


def _load_orientation_bundle(
    paths_raw: str | list[str] | None,
    inline_raw: str | None,
    *,
    config_path: Path | None = None,
    max_chars_per_file: int = 20000,
) -> tuple[list[Path], str | None]:
    resolved_paths: list[Path] = []
    chunks: list[str] = []

    for item in _split_csv_values(paths_raw):
        resolved = resolve_text_reference_path(item, config_path=config_path)
        if resolved is None:
            raise RuntimeError(f"Arquivo de orientação não encontrado: {item}")
        resolved_paths.append(resolved)
        chunks.append(read_orientation_file(resolved, max_chars=max_chars_per_file).strip())

    inline = (inline_raw or "").strip()
    if inline:
        chunks.append(inline)

    merged = "\n\n".join(chunk for chunk in chunks if chunk).strip() or None
    return resolved_paths, merged


def read_config_file(path: Path) -> dict:
    """Lê configuração em TOML ou JSON. Não lê nem armazena chaves de API."""
    suffix = path.suffix.lower()
    if not path.exists():
        raise RuntimeError(f"Arquivo de configuração não encontrado: {path}")
    if suffix == ".json":
        return json.loads(path.read_text(encoding="utf-8"))
    if suffix in {".toml", ".tml"}:
        if tomllib is None:
            raise RuntimeError("Para ler TOML no Python < 3.11, instale o pacote 'tomli'.")
        with open(path, "rb") as fh:
            return tomllib.load(fh)
    raise RuntimeError("Formato de configuração não suportado. Use .toml ou .json.")


def _flatten_config_dict(data: dict) -> dict:
    flat: dict = {}
    for key, value in data.items():
        if not isinstance(value, dict):
            flat[key] = value
    for section in CONFIG_SECTIONS_ORDER:
        section_data = data.get(section, {})
        if isinstance(section_data, dict):
            flat.update(section_data)
    return flat


def apply_config_to_args(args: argparse.Namespace, config_path: Path) -> argparse.Namespace:
    data = read_config_file(config_path)

    for raw_key, raw_value in data.items():
        if isinstance(raw_value, dict) or raw_value is None:
            continue
        key = CONFIG_ARG_ALIASES.get(str(raw_key).strip(), str(raw_key).strip())
        if hasattr(args, key):
            setattr(args, key, _config_value_to_arg(raw_value))

    for section in CONFIG_SECTIONS_ORDER:
        section_data = data.get(section, {})
        if not isinstance(section_data, dict):
            continue
        for raw_key, raw_value in section_data.items():
            if raw_value is None:
                continue
            skey = (section, str(raw_key).strip())
            key = CONFIG_SECTION_ARG_ALIASES.get(skey)
            if key is None:
                key = CONFIG_ARG_ALIASES.get(str(raw_key).strip(), str(raw_key).strip())
            if not hasattr(args, key):
                continue
            setattr(args, key, _config_value_to_arg(raw_value))

    args.config = str(config_path)
    setattr(args, "config_loaded_path", str(config_path))
    args.nao_interativo = True
    return args


def maybe_load_initial_config(args: argparse.Namespace) -> argparse.Namespace:
    if getattr(args, "config", None):
        return apply_config_to_args(args, Path(args.config).expanduser().resolve())
    interactive = not getattr(args, "nao_interativo", False)
    if interactive and prompt_yes_no("Você possui um arquivo de configuração?", default=False):
        config_txt = prompt_path("Caminho do arquivo de configuração", None, None, force=True, must_exist=True)
        if config_txt:
            return apply_config_to_args(args, Path(config_txt).expanduser().resolve())
    return args


def _toml_quote(value: str) -> str:
    return json.dumps(str(value), ensure_ascii=False)


def _toml_scalar(value):
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, list):
        return "[" + ", ".join(_toml_quote(str(x)) for x in value) + "]"
    if isinstance(value, Path):
        return _toml_quote(value.as_posix())
    if value is None:
        return None
    return _toml_quote(str(value))


def _toml_section(name: str, mapping: dict) -> str:
    lines = [f"[{name}]"]
    for key, value in mapping.items():
        rendered = _toml_scalar(value)
        if rendered is not None:
            lines.append(f"{key} = {rendered}")
    return "\n".join(lines)


def save_config_toml(config: "Config", path: Path) -> Path:
    """Salva as respostas em TOML, sem incluir segredos/chaves de API."""
    payload_sections = [
        _toml_section("atividade", {
            "modo": config.modo,
            "disciplina": config.disciplina,
            "professor": config.professor,
            "curso": config.curso,
            "turma": config.turma,
            "polo": config.polo,
            "aluno": config.aluno,
        }),
        _toml_section("pesquisa", {
            "tema": config.tema,
            "recorte": config.recorte,
            "objetivo": config.objetivo,
            "trabalho": config.titulo_trabalho or config.trabalho,
            "tipo_estudo": config.tipo_estudo,
            "periodo": config.periodo if config.modo == "revisao_sistematica" else None,
            "idiomas": config.idiomas,
            "bases": config.bases if config.modo == "revisao_sistematica" else None,
            "palavras_chave": config.palavras_chave,
        }),
        _toml_section("bibliografia", {
            "estilo_citacao": config.estilo_citacao if config.modo == "revisao_sistematica" else None,
        }),
        _toml_section("busca", {
            "query_bilingue": config.query_bilingue if config.modo == "revisao_sistematica" else None,
            "quantidade_triagem": config.quantidade_triagem if config.modo == "revisao_sistematica" else None,
            "quantidade_selecionados": config.quantidade_selecionados if config.modo == "revisao_sistematica" else None,
            "salvar_busca_bruta_json": config.salvar_busca_bruta_json if config.modo == "revisao_sistematica" else None,
            "incluir_analise_detalhada_ia": config.incluir_analise_detalhada_ia if config.modo == "revisao_sistematica" else None,
            "incluir_sintese_integradora_ia": config.incluir_sintese_integradora_ia if config.modo == "revisao_sistematica" else None,
        }),
        _toml_section("triagem", {
            "rigor": config.triagem_rigor if config.modo == "revisao_sistematica" else None,
            "usar_score_hibrido": config.triagem_score_hibrido if config.modo == "revisao_sistematica" else None,
            "orientacoes_paths": [p.as_posix() for p in config.triagem_orientacoes_paths] if (config.modo == "revisao_sistematica" and config.triagem_orientacoes_paths) else None,
            "orientacao_inline": config.triagem_orientacao_inline if config.modo == "revisao_sistematica" else None,
            "permitir_textos_nao_publicos": config.permitir_textos_nao_publicos if config.modo == "revisao_sistematica" else None,
        }),
        _toml_section("queries", {
            "query_geral": config.query_geral,
            "query_semantic": config.query_semantic,
            "query_scopus": config.query_scopus,
            "query_wos": config.query_wos,
            "query_pubmed": config.query_pubmed,
            "query_openalex": config.query_openalex,
            "query_crossref": config.query_crossref,
            "query_europepmc": config.query_europepmc,
            "query_core": config.query_core,
        }),
        _toml_section("saida", {
            "prefixo": config.prefixo,
            "output_dir": config.output_dir.parent.as_posix() if config.create_subdiretorio else config.output_dir.as_posix(),
            "criar_subdiretorio": config.create_subdiretorio,
            "org_modelo": config.org_modelo.as_posix(),
            "orientacoes_paths": [p.as_posix() for p in config.saida_orientacoes_paths] if config.saida_orientacoes_paths else None,
            "orientacao_inline": config.saida_orientacao_inline,
            "exportar_pdf": config.exportar_pdf,
            "gerar_env_example": config.gerar_env_example,
            "remover_auxiliares": config.remover_auxiliares,
        }),
        _toml_section("latex", {
            "org_latex_class_init": config.org_latex_class_init.as_posix() if config.org_latex_class_init else None,
            "latex_extra_path": config.latex_extra_path.as_posix() if config.latex_extra_path else None,
            "comando_exportacao_pdf": config.comando_exportacao_pdf,
            "fgv_logo_path": config.fgv_logo_path.as_posix(),
        }),
        _toml_section("openai", {
            "model": config.model,
        }),
    ]
    content = "\n\n".join(section for section in payload_sections if section.strip()) + "\n"
    write_text(path, content)
    return path



def save_raw_search_jsons(output_dir: Path, prefixo: str, audit: SearchAudit) -> list[Path]:
    paths: list[Path] = []
    for item in audit.per_source:
        path = output_dir / f"{prefixo}_{item.source}_raw.json"
        payload = {
            "source": item.source,
            "label": SOURCE_LABELS.get(item.source, item.source),
            "query": item.query,
            "retrieved": item.retrieved,
            "warnings": item.warnings,
            "saved_at": datetime.now().isoformat(),
            "pages": item.raw_payloads,
        }
        write_text(path, json.dumps(payload, ensure_ascii=False, indent=2))
        paths.append(path)
    return paths


def save_source_logs(output_dir: Path, prefixo: str, audit: SearchAudit) -> list[Path]:
    paths: list[Path] = []
    for item in audit.per_source:
        path = output_dir / f"{prefixo}_{item.source}.log"
        lines = [
            f"Fonte: {SOURCE_LABELS.get(item.source, item.source)}",
            f"Query: {item.query}",
            f"Recuperados: {item.retrieved}",
            f"Warnings: {'; '.join(item.warnings) if item.warnings else 'nenhum'}",
            "Candidatos:",
        ]
        for idx, cand in enumerate(item.candidates, start=1):
            lines.extend([
                f"  {idx}. {cand.title}",
                f"     Ano: {cand.year or 's.d.'}",
                f"     DOI: {cand.doi or 'n/d'}",
                f"     URL: {cand.url or 'n/d'}",
                f"     ID fonte: {cand.source_ids.get(item.source, 'n/d')}",
            ])
        write_text(path, "\n".join(lines) + "\n")
        paths.append(path)
    return paths


def which_or_none(cmd: str) -> str | None:
    return shutil.which(cmd)


def convert_svg_to_pdf(svg_path: Path, logger: logging.Logger) -> Path:
    inkscape = which_or_none("inkscape")
    if not inkscape:
        raise RuntimeError("O comando 'inkscape' não foi encontrado no PATH. Ele é necessário para converter o fluxograma SVG em PDF.")
    pdf_path = svg_path.with_suffix('.pdf')
    cmd = [inkscape, str(svg_path), f"--export-filename={pdf_path}"]
    proc = subprocess.run(cmd, cwd=str(svg_path.parent), capture_output=True, text=True)
    if proc.stdout:
        logger.info("Saída da conversão SVG->PDF (stdout): %s", proc.stdout.strip()[:4000])
    if proc.stderr:
        logger.info("Saída da conversão SVG->PDF (stderr): %s", proc.stderr.strip()[:4000])
    if proc.returncode != 0 or not pdf_path.exists():
        raise RuntimeError(f"Falha ao converter SVG em PDF com Inkscape (código {proc.returncode}).")
    logger.info("PDF do fluxograma gerado em %s", pdf_path)
    return pdf_path


def _build_latex_env(logger: logging.Logger, latex_extra_path: Path | None) -> dict[str, str]:
    env = os.environ.copy()
    if latex_extra_path:
        resolved_extra = latex_extra_path.resolve()
        latex_dir_path = resolved_extra.parent if resolved_extra.is_file() else resolved_extra
        latex_dir = latex_dir_path.as_posix()
        texinputs_prefix = f"{latex_dir}//:"
        env["TEXINPUTS"] = texinputs_prefix + env.get("TEXINPUTS", "")
        env["BIBINPUTS"] = texinputs_prefix + env.get("BIBINPUTS", "")
        env["BSTINPUTS"] = texinputs_prefix + env.get("BSTINPUTS", "")
        logger.info("Usando caminho extra de classes/pacotes LaTeX: %s (diretório efetivo: %s)", resolved_extra, latex_dir)
    return env


def export_org_to_pdf_internal(org_path: Path, logger: logging.Logger,
                               org_latex_class_init: Path | None = None,
                               latex_extra_path: Path | None = None) -> Path | None:
    emacs = which_or_none("emacs")
    lualatex = which_or_none("lualatex")
    if not emacs or not lualatex:
        logger.warning("Exportação automática para PDF ignorada: 'emacs' ou 'lualatex' não encontrados no PATH.")
        return None

    org_text = read_text(org_path)
    uses_citations = org_uses_citation_pipeline(org_text)
    elisp_path = org_path.parent / f"{org_path.stem}_export_pdf.el"
    init_loader = ""
    if org_latex_class_init:
        init_loader = f'(load-file "{org_latex_class_init.as_posix()}")\n'

    cite_requirements = ""
    cite_guard = ""
    export_call = "(org-latex-export-to-pdf)"
    pdf_process_lines = [
        '"lualatex -shell-escape -interaction nonstopmode -output-directory %o %f"',
        '"lualatex -shell-escape -interaction nonstopmode -output-directory %o %f"',
    ]

    if uses_citations:
        cite_requirements = "(ignore-errors (require 'oc))\n(ignore-errors (require 'oc-biblatex))\n"
        cite_guard = textwrap.dedent("""
        (setq org-cite-insert-processor 'basic
              org-cite-follow-processor 'basic
              org-cite-activate-processor 'basic
              org-cite-export-processors '((latex biblatex) (t basic)))
        (setq-local org-cite-export-processors '((latex biblatex) (t basic)))
        """).strip() + "\n"
        pdf_process_lines = [
            '"lualatex -shell-escape -interaction nonstopmode -output-directory %o %f"',
            '"biber %b"',
            '"lualatex -shell-escape -interaction nonstopmode -output-directory %o %f"',
            '"lualatex -shell-escape -interaction nonstopmode -output-directory %o %f"',
        ]
    else:
        cite_guard = textwrap.dedent("""
        (setq org-cite-insert-processor 'basic
              org-cite-follow-processor 'basic
              org-cite-activate-processor 'basic
              org-cite-export-processors '((latex basic) (t basic)))
        (setq-local org-cite-export-processors '((latex basic) (t basic)))
        (setq-local org-cite-global-bibliography nil)
        (when (boundp 'org-export-with-cite-processors)
          (setq org-export-with-cite-processors nil)
          (setq-local org-export-with-cite-processors nil))
        (when (boundp 'org-export-process-citations)
          (setq org-export-process-citations nil)
          (setq-local org-export-process-citations nil))
        """).strip() + "\n"
        export_call = "(let ((org-cite-export-processors '((latex basic) (t basic))) (org-export-with-cite-processors nil) (org-export-process-citations nil)) (org-latex-export-to-pdf nil nil nil nil '(:with-cite-processors nil)))"

    pdf_process = "\n            ".join(pdf_process_lines)
    elisp = textwrap.dedent(f"""
    {init_loader}(require 'org)
    (require 'ox)
    (require 'ox-latex)
    {cite_requirements}(find-file "{org_path.as_posix()}")
    (setq-local org-export-use-babel nil)
    (setq-local org-confirm-babel-evaluate nil)
    {cite_guard}(setq org-latex-pdf-process
          '({pdf_process}))
    {export_call}
    """).strip() + "\n"
    write_text(elisp_path, elisp)
    logger.info("Tentando exportar PDF automaticamente via Emacs batch + LuaLaTeX (fallback interno, usando a configuração normal do Emacs).")
    logger.info(
        "Pipeline interno de exportação detectado: %s",
        "com citações/biber" if uses_citations else "sem citações/biber (modo local, sem fallback global)",
    )

    env = _build_latex_env(logger, latex_extra_path)
    if org_latex_class_init:
        logger.info("Carregando arquivo Emacs de registro da classe LaTeX: %s", org_latex_class_init)

    cmd = [emacs, "--batch"]
    if org_latex_class_init:
        cmd.extend(["-l", str(org_latex_class_init)])
    cmd.extend(["-l", str(elisp_path)])

    proc = subprocess.run(cmd, cwd=str(org_path.parent), capture_output=True, text=True, env=env)
    logger.info("Saída do Emacs batch (stdout): %s", (proc.stdout or "").strip()[:4000])
    if proc.stderr:
        logger.info("Saída do Emacs batch (stderr): %s", proc.stderr.strip()[:4000])
    if proc.returncode != 0:
        logger.warning("Exportação automática para PDF falhou com código %s.", proc.returncode)
        return None
    pdf_path = org_path.with_suffix('.pdf')
    if pdf_path.exists():
        logger.info("PDF gerado com sucesso: %s", pdf_path)
        return pdf_path
    logger.warning("O processo terminou sem erro, mas o PDF final não foi localizado em %s.", pdf_path)
    return None


def export_org_to_pdf_external(org_path: Path, bib_path: Path | None, logger: logging.Logger,
                               command_template: str,
                               org_latex_class_init: Path | None = None,
                               latex_extra_path: Path | None = None) -> Path | None:
    pdf_path = org_path.with_suffix('.pdf')
    latex_dir_resolved = None
    class_init_resolved = None
    if latex_extra_path:
        latex_resolved = latex_extra_path.resolve()
        latex_dir_resolved = latex_resolved.parent if latex_resolved.is_file() else latex_resolved
    if org_latex_class_init:
        class_init_resolved = org_latex_class_init.resolve()

    placeholders = {
        'org': org_path.as_posix(),
        'org_dir': org_path.parent.as_posix(),
        'org_stem': org_path.stem,
        'pdf': pdf_path.as_posix(),
        'pdf_dir': pdf_path.parent.as_posix(),
        'class_init': class_init_resolved.as_posix() if class_init_resolved else '',
        'latex_path': latex_extra_path.resolve().as_posix() if latex_extra_path else '',
        'latex_dir': latex_dir_resolved.as_posix() if latex_dir_resolved else '',
        'bib': bib_path.as_posix() if bib_path else '',
    }
    try:
        command = command_template.format(**placeholders)
    except KeyError as exc:
        logger.warning("Comando de exportação PDF contém placeholder desconhecido: %s", exc)
        return None

    logger.info("Tentando exportar PDF via comando externo: %s", command)
    env = _build_latex_env(logger, latex_extra_path)
    proc = subprocess.run(command, cwd=str(org_path.parent), shell=True, capture_output=True, text=True, env=env)
    logger.info("Saída do comando externo (stdout): %s", (proc.stdout or '').strip()[:4000])
    if proc.stderr:
        logger.info("Saída do comando externo (stderr): %s", proc.stderr.strip()[:4000])
    if proc.returncode != 0:
        logger.warning("Exportação automática para PDF via comando externo falhou com código %s.", proc.returncode)
        return None
    if pdf_path.exists():
        logger.info("PDF gerado com sucesso: %s", pdf_path)
        return pdf_path
    logger.warning("O comando externo terminou sem erro, mas o PDF final não foi localizado em %s.", pdf_path)
    return None


def export_org_to_pdf(org_path: Path, bib_path: Path | None, logger: logging.Logger,
                      org_latex_class_init: Path | None = None,
                      latex_extra_path: Path | None = None,
                      command_template: str | None = None) -> Path | None:
    if command_template:
        return export_org_to_pdf_external(org_path, bib_path, logger, command_template, org_latex_class_init, latex_extra_path)
    return export_org_to_pdf_internal(org_path, logger, org_latex_class_init, latex_extra_path)


def cleanup_generated_files(output_dir: Path, prefixo: str, logger: logging.Logger) -> list[Path]:
    removed: list[Path] = []
    for path in output_dir.iterdir():
        if path.name == ".env.example":
            continue
        if path.is_dir():
            if path.name in REMOVABLE_OUTPUT_EXACT_NAMES:
                try:
                    shutil.rmtree(path)
                    removed.append(path)
                except Exception as exc:
                    logger.warning("Não foi possível remover diretório auxiliar %s: %s", path, exc)
            continue
        if not path.name.startswith(prefixo):
            continue
        if path.suffix.lower() in {".org", ".pdf", ".svg", ".json", ".bib"}:
            continue
        should_remove = False
        if path.name.endswith("_export_pdf.el"):
            should_remove = True
        elif path.suffix.lower() in REMOVABLE_OUTPUT_SUFFIXES:
            should_remove = True
        if should_remove:
            try:
                path.unlink()
                removed.append(path)
            except Exception as exc:
                logger.warning("Não foi possível remover arquivo auxiliar %s: %s", path, exc)
    return removed


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Gera atividade acadêmica em Org-mode + SVG PRISMA usando OpenAI e múltiplas bases."
    )
    parser.add_argument("--modo", choices=["revisao_sistematica", "pesquisa_empirica"], default=DEFAULT_MODO, help="Modo da atividade: revisão sistemática/PRISMA ou pesquisa empírica.")
    parser.add_argument("--disciplina")
    parser.add_argument("--professor")
    parser.add_argument("--curso")
    parser.add_argument("--tema")
    parser.add_argument("--recorte")
    parser.add_argument("--objetivo")
    parser.add_argument("--bases", help="Bases separadas por vírgula: semantic_scholar,scopus,web_of_science,pubmed")
    parser.add_argument("--tipo-estudo")
    parser.add_argument("--estilo-citacao")
    parser.add_argument("--periodo", default=DEFAULT_PERIODO)
    parser.add_argument("--idiomas")
    parser.add_argument("--palavras-chave")
    parser.add_argument("--sugerir-palavras-chave-ia", action="store_true", help="Usa a OpenAI para sugerir palavras-chave e queries por base antes da busca.")
    parser.add_argument("--aluno")
    parser.add_argument("--turma", default=DEFAULT_TURMA)
    parser.add_argument("--polo", default=DEFAULT_POLO)
    parser.add_argument("--trabalho", help="Título do trabalho; se informado, substitui a sugestão automática da IA.")
    parser.add_argument("--quantidade-triagem", type=int, default=DEFAULT_TRIAGEM)
    parser.add_argument("--quantidade-selecionados", type=int, default=DEFAULT_SELECIONADOS, help="Quantidade desejada de textos selecionados na síntese final.")
    parser.add_argument("--triagem-rigor", dest="triagem_rigor", choices=["estrito", "moderado", "exploratorio"], help="Rigor da triagem PRISMA: estrito, moderado ou exploratorio.")
    triagem_score_group = parser.add_mutually_exclusive_group()
    triagem_score_group.add_argument("--usar-score-hibrido", dest="triagem_score_hibrido", action="store_true", help="Usa uma calibragem híbrida local (tema/recorte/objetivo/tipo de estudo/acesso) para ordenar os candidatos antes da triagem da IA.")
    triagem_score_group.add_argument("--sem-score-hibrido", dest="triagem_score_hibrido", action="store_false", help="Desativa a calibragem híbrida local da triagem.")
    parser.set_defaults(triagem_score_hibrido=None)
    parser.add_argument("--triagem-orientacoes-paths", help="Arquivos textuais opcionais, separados por vírgula, com orientações específicas de triagem/ranking.")
    parser.add_argument("--triagem-orientacao-inline", help="Texto inline opcional com orientações específicas de triagem/ranking.")
    parser.add_argument("--permitir-textos-nao-publicos", dest="permitir_textos_nao_publicos", action="store_true", help="Permite manter textos sem download local de PDF quando houver ao menos landing page/URL verificável do registro.")
    parser.add_argument("--model", default=DEFAULT_MODEL)
    parser.add_argument("--query-geral")
    parser.add_argument("--query-semantic")
    parser.add_argument("--query-scopus")
    parser.add_argument("--query-wos")
    parser.add_argument("--query-pubmed")
    parser.add_argument("--query-openalex")
    parser.add_argument("--query-crossref")
    parser.add_argument("--query-europepmc")
    parser.add_argument("--query-core")
    query_group = parser.add_mutually_exclusive_group()
    query_group.add_argument("--query-bilingue", dest="query_bilingue", action="store_true", help="Monta/sugere queries bilíngues em português e inglês quando possível.")
    query_group.add_argument("--sem-query-bilingue", dest="query_bilingue", action="store_false", help="Desativa a montagem bilíngue das queries.")
    parser.set_defaults(query_bilingue=None)
    parser.add_argument("--saida-orientacoes-paths", help="Arquivos textuais opcionais, separados por vírgula, com orientações gerais da etapa de pesquisa.")
    parser.add_argument("--saida-orientacao-inline", help="Texto inline opcional com orientações gerais da etapa de pesquisa.")
    parser.add_argument("--prefixo")
    parser.add_argument("--output-dir", default=".")
    subdir_group = parser.add_mutually_exclusive_group()
    subdir_group.add_argument("--criar-subdiretorio", dest="create_subdiretorio", action="store_true", help="Cria por padrão um subdiretório com o nome do prefixo dentro do diretório de saída.")
    subdir_group.add_argument("--sem-criar-subdiretorio", dest="create_subdiretorio", action="store_false", help="Desativa a criação automática do subdiretório com o prefixo.")
    parser.set_defaults(create_subdiretorio=None)
    parser.add_argument("--org-modelo", default=DEFAULT_ORG_MODEL_FILENAME)
    parser.add_argument("--org-latex-class-init", default=DEFAULT_ORG_LATEX_CLASS_INIT, help="Arquivo .el que registra a classe LaTeX fgv-paper no Emacs batch (ex.: academic-writing.el).")
    parser.add_argument("--latex-extra-path", default=DEFAULT_LATEX_EXTRA_PATH, help="Diretório ou arquivo LaTeX da classe/pacotes (ex.: diretório com fgv-paper.sty/fgv-header.sty, ou o próprio arquivo fgv-paper.sty).")
    parser.add_argument("--comando-exportacao-pdf", default=DEFAULT_PDF_EXPORT_COMMAND, help="Comando externo para exportar o .org para PDF. Aceita placeholders como {org}, {org_dir}, {org_stem}, {pdf}, {pdf_dir}, {class_init}, {latex_path}, {latex_dir} e {bib}.")
    parser.add_argument("--fgv-logo-path", default=DEFAULT_FGV_LOGO_PATH, help="Caminho do logo da FGV a ser usado no cabeçalho do relatório.")
    parser.add_argument("--exportar-pdf", action="store_true", help="Tenta exportar o .org para PDF automaticamente.")
    parser.add_argument("--salvar-busca-bruta-json", action="store_true", help="Salva as respostas brutas das bases em JSON por fonte.")
    parser.add_argument("--gerar-env-example", action="store_true", help="Gera um arquivo .env.example no diretório de saída.")
    parser.add_argument("--remover-auxiliares", action="store_true", help="Remove arquivos auxiliares ao final, preservando apenas .org, .pdf, .svg e .json do trabalho atual.")
    analise_group = parser.add_mutually_exclusive_group()
    analise_group.add_argument("--incluir-analise-detalhada-ia", dest="incluir_analise_detalhada_ia", action="store_true", help="Inclui no .org a análise detalhada gerada pela IA para cada texto selecionado.")
    analise_group.add_argument("--sem-analise-detalhada-ia", dest="incluir_analise_detalhada_ia", action="store_false", help="Não inclui no .org a análise detalhada gerada pela IA para cada texto selecionado.")
    sintese_group = parser.add_mutually_exclusive_group()
    sintese_group.add_argument("--incluir-sintese-integradora-ia", dest="incluir_sintese_integradora_ia", action="store_true", help="Inclui no .org a síntese integradora final gerada pela IA com base em todos os textos selecionados.")
    sintese_group.add_argument("--sem-sintese-integradora-ia", dest="incluir_sintese_integradora_ia", action="store_false", help="Não inclui no .org a síntese integradora final gerada pela IA com base em todos os textos selecionados.")
    parser.set_defaults(incluir_analise_detalhada_ia=None, incluir_sintese_integradora_ia=None)
    parser.add_argument("--config", help="Arquivo TOML ou JSON com as respostas/configurações da execução.")
    parser.add_argument("--salvar-config", action="store_true", help="Salva as respostas finais em um arquivo TOML reutilizável.")
    parser.add_argument("--config-output", help="Caminho do arquivo TOML a ser salvo com as respostas finais.")
    parser.add_argument("--nao-interativo", action="store_true")
    return parser.parse_args()


def _supports_prompt_toolkit() -> bool:
    return PROMPT_TOOLKIT_AVAILABLE and bool(sys.stdin.isatty()) and bool(sys.stdout.isatty())


def _prompt_raw(label: str, default: str | None = None, completer=None, password: bool = False) -> str:
    suffix = f" [{default}]" if default not in (None, "") else ""
    message = f"{label}{suffix}: "
    if _supports_prompt_toolkit():
        kwargs = {"is_password": password}
        if completer is not None:
            kwargs["completer"] = completer
            kwargs["complete_while_typing"] = True
        try:
            return pt_prompt(message, **kwargs).strip()
        except TypeError:
            # Compatibilidade com variações de assinatura entre versões.
            kwargs.pop("is_password", None)
            if password:
                kwargs["password"] = True
            return pt_prompt(message, **kwargs).strip()
    return input(message).strip()


def _path_completer(only_directories: bool = False):
    if not _supports_prompt_toolkit():
        return None
    return PathCompleter(only_directories=only_directories, expanduser=True)


def _word_completer(words: list[str]):
    if not _supports_prompt_toolkit():
        return None
    return WordCompleter(words, ignore_case=True, sentence=True)


def prompt_text(label: str, current: str | None = None, default: str | None = None, force: bool = True) -> str:
    if not force and current is not None:
        return current
    base = current if current not in (None, "") else default
    while True:
        raw = _prompt_raw(label, str(base) if base is not None else None)
        if raw:
            return raw
        if base is not None:
            return str(base)


def prompt_path(
    label: str,
    current: str | None = None,
    default: str | None = None,
    *,
    force: bool = True,
    only_directories: bool = False,
    must_exist: bool = False,
) -> str:
    if not force and current is not None:
        return current
    base = current if current not in (None, "") else default
    while True:
        raw = _prompt_raw(label, str(base) if base is not None else None, completer=_path_completer(only_directories=only_directories))
        if not raw and base is not None:
            raw = str(base)
        expanded = os.path.expanduser(raw).strip()
        if not expanded:
            if must_exist:
                print("Informe um caminho válido.")
                continue
            return expanded
        path = Path(expanded)
        if must_exist and not path.exists():
            print(f"Caminho não encontrado: {path}")
            continue
        if only_directories and path.exists() and not path.is_dir():
            print(f"O caminho precisa ser um diretório: {path}")
            continue
        return expanded


def prompt_list(label: str, current_csv: str | None = None, default_csv: str | None = None, force: bool = True) -> list[str]:
    raw = prompt_text(label, current_csv, default_csv, force=force)
    return [x.strip() for x in raw.split(",") if x.strip()]


def prompt_int(label: str, current: int | None = None, default: int | None = None, force: bool = True) -> int:
    if not force and current is not None:
        return current
    base = current if current is not None else default
    while True:
        raw = _prompt_raw(label, str(base) if base is not None else None)
        if not raw and base is not None:
            return int(base)
        try:
            return int(raw)
        except ValueError:
            print("Digite um número inteiro válido.")


def prompt_yes_no(label: str, default: bool = True) -> bool:
    suffix = "S/n" if default else "s/N"
    raw = _prompt_raw(f"{label} [{suffix}]", None).lower()
    if not raw:
        return default
    return raw in {"s", "sim", "y", "yes"}


def normalize_sources(raw_sources: Iterable[str]) -> list[str]:
    norm = []
    seen = set()
    mapping = {
        "semantic": "semantic_scholar",
        "semantic_scholar": "semantic_scholar",
        "semantic-scholar": "semantic_scholar",
        "semanticscholar": "semantic_scholar",
        "scopus": "scopus",
        "wos": "web_of_science",
        "web_of_science": "web_of_science",
        "web-of-science": "web_of_science",
        "web of science": "web_of_science",
        "pubmed": "pubmed",
        "pub med": "pubmed",
        "ncbi": "pubmed",
        "medline": "pubmed",
        "openalex": "openalex",
        "open alex": "openalex",
        "crossref": "crossref",
        "cross ref": "crossref",
        "europepmc": "europe_pmc",
        "europe pmc": "europe_pmc",
        "europe_pmc": "europe_pmc",
        "europe-pmc": "europe_pmc",
        "core": "core",
    }
    for item in raw_sources:
        key = mapping.get(item.strip().lower(), item.strip().lower())
        if key not in SOURCE_LABELS:
            raise ValueError(f"Base desconhecida: {item}")
        if key not in seen:
            seen.add(key)
            norm.append(key)
    return norm


def prompt_sources(current_csv: str | None, force: bool) -> list[str]:
    if not force and current_csv:
        return normalize_sources(current_csv.split(","))

    print("Bases disponíveis:")
    print("  1) Semantic Scholar")
    print("  2) Scopus")
    print("  3) Web of Science")
    print("  4) PubMed")
    print("  5) OpenAlex")
    print("  6) Crossref")
    print("  7) Europe PMC")
    print("  8) CORE")
    default_txt = ",".join(DEFAULT_BASES)
    tokens_hint = [
        "1", "2", "3", "4", "5", "6", "7", "8",
        "semantic_scholar", "semantic scholar", "semantic-scholar",
        "scopus",
        "web_of_science", "web of science", "web-of-science", "wos",
        "pubmed", "pub med", "ncbi", "medline",
        "openalex", "open alex", "crossref", "cross ref", "europepmc", "europe pmc", "core",
    ]
    raw = _prompt_raw(
        "Selecione as bases (números ou nomes, separados por vírgula)",
        default_txt,
        completer=_word_completer(tokens_hint),
    )
    if not raw:
        return list(DEFAULT_BASES)

    tokens = [x.strip() for x in raw.split(",") if x.strip()]
    resolved = []
    num_map = {"1": "semantic_scholar", "2": "scopus", "3": "web_of_science", "4": "pubmed", "5": "openalex", "6": "crossref", "7": "europe_pmc", "8": "core"}
    for tok in tokens:
        resolved.append(num_map.get(tok, tok))
    return normalize_sources(resolved)


def _semantic_scholar_terms_for_query(terms: list[str]) -> list[str]:
    """Monta uma lista enxuta de termos para o Semantic Scholar.

    O endpoint /paper/search funciona melhor com texto curto e sem booleanos
    pesados (AND/OR/parênteses). Aqui priorizamos poucos termos únicos,
    preservando expressões compostas entre aspas na etapa final.
    """
    cleaned: list[str] = []
    seen: set[str] = set()
    for raw in terms:
        term = re.sub(r'\s+', ' ', str(raw or '').strip())
        if not term:
            continue
        term = re.sub(r'^[()]+|[()]+$', '', term)
        term = re.sub(r'\b(?:AND|OR|NOT)\b', ' ', term, flags=re.IGNORECASE)
        term = re.sub(r'\s+', ' ', term).strip(' ,;')
        if not term:
            continue
        key = term.lower()
        if key in seen:
            continue
        seen.add(key)
        cleaned.append(term)

    phrases = [t for t in cleaned if ' ' in t]
    singles = [t for t in cleaned if ' ' not in t]

    ordered: list[str] = []
    for bucket in (phrases, singles):
        for item in bucket:
            if item not in ordered:
                ordered.append(item)

    return ordered[:8]


def simplify_semantic_scholar_query(query: str) -> str:
    """Reduz uma query arbitrária a um formato compatível com o Semantic Scholar."""
    raw_parts = re.split(r'\s+', query or '')
    parts: list[str] = []
    buffer: list[str] = []
    in_quotes = False
    for token in raw_parts:
        if not token:
            continue
        # preserva frases entre aspas quando possível
        if token.count('"') % 2 == 1:
            if not in_quotes:
                buffer = [token]
                in_quotes = True
            else:
                buffer.append(token)
                parts.append(' '.join(buffer).replace('"', '').strip())
                buffer = []
                in_quotes = False
            continue
        if in_quotes:
            buffer.append(token)
            continue
        parts.append(token)
    if buffer:
        parts.extend(buffer)

    simplified_terms = _semantic_scholar_terms_for_query(parts)
    return ' '.join(f'"{t}"' if ' ' in t else t for t in simplified_terms)


def parse_periodo_year_range(periodo: str | None) -> tuple[int, int] | None:
    if not periodo:
        return None
    m = re.fullmatch(r"\s*(\d{4})\s*[-–]\s*(\d{4})\s*", str(periodo))
    if not m:
        return None
    start, end = int(m.group(1)), int(m.group(2))
    if start > end:
        start, end = end, start
    return start, end


def is_review_like_type(tipo_estudo: str) -> bool:
    low = (tipo_estudo or "").casefold()
    return any(tok in low for tok in ["revis", "review", "scoping", "meta", "metan"])


def _clean_query_term(term: str) -> str:
    term = re.sub(r"\s+", " ", str(term or "").strip())
    term = term.strip('"“”\'`´ ,;')
    return term


def _unique_terms(items: Iterable[str], max_items: int = 12) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for item in items:
        term = _clean_query_term(str(item))
        if not term:
            continue
        key = term.casefold()
        if key in seen:
            continue
        seen.add(key)
        out.append(term)
        if len(out) >= max_items:
            break
    return out


def _quoted(term: str, *, wildcard: bool = False) -> str:
    term = _clean_query_term(term)
    if not term:
        return ""
    if wildcard and term.endswith("*"):
        return term
    if re.search(r"\s", term) or any(ch in term for ch in ["-", "/"]):
        return f'"{term}"'
    return term


def _semantic_group(terms: list[str]) -> str:
    cleaned = [_quoted(t) for t in _unique_terms(terms, max_items=10)]
    cleaned = [t for t in cleaned if t]
    if not cleaned:
        return ""
    if len(cleaned) == 1:
        return cleaned[0]
    return "(" + " | ".join(cleaned) + ")"


def _scopus_group(terms: list[str]) -> str:
    cleaned = [_quoted(t, wildcard=True) for t in _unique_terms(terms, max_items=12)]
    cleaned = [t for t in cleaned if t]
    if not cleaned:
        return ""
    return "(" + " OR ".join(cleaned) + ")"


def _wos_group(terms: list[str]) -> str:
    cleaned = [_quoted(t, wildcard=True) for t in _unique_terms(terms, max_items=12)]
    cleaned = [t for t in cleaned if t]
    if not cleaned:
        return ""
    return "(" + " OR ".join(cleaned) + ")"


def _classify_term(term: str) -> str:
    low = _normalize_key(term)
    if low in {"ia", "ai"}:
        return "technology"
    technology = ["inteligencia artificial", "artificial intelligence", "machine learning", "algorithm", "algorit", "data science", "analytics"]
    context = [
        "governo", "government", "administracao publica", "public administration", "public sector", "setor publico", "federal", "public governance",
        "capacidades estatais", "capacidade estatal", "state capacity", "state capabilities", "coercive capacity", "capacidade coercitiva",
        "state coercion", "coercao estatal", "coerção estatal", "centralizacao", "centralização", "centralization", "decentralization",
        "descentralizacao", "descentralização", "political centralization", "administrative centralization"
    ]
    analytic = [
        "governanca", "governance", "compliance", "risco", "risk", "integridade", "integrity", "controle", "control", "accountability", "transparencia", "transparency",
        "desempenho estatal", "state performance", "government effectiveness", "policy performance", "policy outcomes", "resultados de políticas públicas",
        "resultados de politicas publicas", "policy effectiveness", "coordenação institucional", "coordenacao institucional", "institutional coordination",
        "arranjos institucionais", "institutional arrangements", "implementacao", "implementação"
    ]
    study = ["review", "revis", "scoping", "meta", "metan", "literature"]
    if any(tok in low for tok in study):
        return "study"
    if any(tok in low for tok in technology):
        return "technology"
    if any(tok in low for tok in context):
        return "context"
    if any(tok in low for tok in analytic):
        return "analytic"
    return "general"


AI_POSITIVE_NOISE_TERMS = {
    "ai", "ia", "artificial intelligence", "inteligencia artificial", "inteligência artificial",
    "machine learning", "deep learning", "neural network", "neural networks",
    "algorithmic decision making", "algorithmic decision-making", "algorithmic governance",
    "predictive analytics", "data science", "large language model", "large language models",
    "llm", "llms", "chatgpt",
}


def _is_ai_related_theme(tema: str, recorte: str, palavras: list[str] | None = None) -> bool:
    """Detecta se IA é realmente parte do tema informado pelo usuário."""
    joined = " ".join([tema or "", recorte or ""] + [str(x) for x in (palavras or [])])
    norm = _normalize_key(joined)
    markers = [
        "inteligencia artificial", "ia", "artificial intelligence", "machine learning",
        "deep learning", "algorithmic", "algoritmico", "algoritmica",
        "data science", "predictive analytics", "large language model", "llm", "chatgpt",
    ]
    return any(re.search(rf"\b{re.escape(marker)}\b", norm) for marker in markers)


def _is_ai_noise_term(term: str) -> bool:
    norm = _normalize_key(term)
    return norm in AI_POSITIVE_NOISE_TERMS


def remove_ai_noise_from_blocks(blocks: dict[str, list[str]], tema: str, recorte: str, palavras: list[str] | None = None) -> dict[str, list[str]]:
    """Remove termos positivos de IA quando IA não é parte explícita do tema."""
    if _is_ai_related_theme(tema, recorte, palavras):
        return blocks
    cleaned: dict[str, list[str]] = {}
    for key, values in blocks.items():
        if key == "exclude":
            cleaned[key] = list(values)
            continue
        cleaned[key] = [v for v in values if not _is_ai_noise_term(v)]
    return cleaned


QUERY_SYNONYM_MAP: dict[str, dict[str, list[str]]] = {
    "technology": {
        "inteligencia artificial": ["artificial intelligence", "machine learning", "algorithmic decision-making", "algorithmic governance", "AI"],
        "inteligência artificial": ["artificial intelligence", "machine learning", "algorithmic decision-making", "algorithmic governance", "AI"],
        "artificial intelligence": ["machine learning", "algorithmic decision-making", "algorithmic governance", "AI"],
        "machine learning": ["artificial intelligence", "predictive analytics", "algorithmic decision-making"],
        "algorit": ["algorithm", "algorithmic decision-making", "algorithmic governance"],
        "analytics": ["data analytics", "predictive analytics", "decision support systems"],
    },
    "context": {
        "capacidades estatais": ["state capacity", "state capabilities"],
        "state capacity": ["capacidades estatais", "state capabilities"],
        "capacidade coercitiva": ["coercive capacity", "state coercion"],
        "coercive capacity": ["capacidade coercitiva", "state coercion"],
        "centralização do poder": ["political centralization", "administrative centralization"],
        "political centralization": ["centralização do poder", "administrative centralization"],
        "governo federal": ["federal government", "central government", "Brazilian federal government"],
        "federal government": ["governo federal", "central government", "Brazilian federal government"],
        "administracao publica": ["public administration", "public sector", "public governance"],
        "administração pública": ["public administration", "public sector", "public governance"],
        "public administration": ["administração pública", "public sector", "public governance"],
        "setor publico": ["public sector", "public administration", "government"],
        "setor público": ["public sector", "public administration", "government"],
        "public sector": ["setor público", "public administration", "government"],
        "governanca publica": ["public governance", "public administration", "public sector"],
        "governança pública": ["public governance", "public administration", "public sector"],
        "public governance": ["governança pública", "public administration", "public sector"],
    },
    "analytic": {
        "desempenho estatal": ["state performance", "government effectiveness", "policy performance", "policy outcomes"],
        "state performance": ["desempenho estatal", "government effectiveness", "policy performance", "policy outcomes"],
        "resultados de políticas públicas": ["policy outcomes", "policy performance", "policy effectiveness"],
        "policy outcomes": ["resultados de políticas públicas", "policy performance", "policy effectiveness"],
        "implementação de políticas públicas": ["policy implementation", "policy performance"],
        "policy implementation": ["implementação de políticas públicas", "policy performance"],
        "governanca": ["governance", "public governance", "governance arrangements"],
        "governança": ["governance", "public governance", "governance arrangements"],
        "governance": ["governança", "public governance", "governance arrangements"],
        "compliance": ["regulatory compliance", "conformity", "compliance management"],
        "gestao de riscos": ["risk management", "risk governance", "risk assessment"],
        "gestão de riscos": ["risk management", "risk governance", "risk assessment"],
        "risk management": ["gestão de riscos", "risk governance", "risk assessment"],
        "integridade": ["integrity", "public integrity", "anti-corruption"],
        "integrity": ["integridade", "public integrity", "anti-corruption"],
        "controle interno": ["internal control", "internal controls", "control systems"],
        "controles internos": ["internal control", "internal controls", "control systems"],
        "internal control": ["controle interno", "internal controls", "control systems"],
        "accountability": ["responsibility", "oversight", "transparency"],
        "tomada de decisao": ["decision-making", "decision support", "evidence-based decision-making"],
        "tomada de decisão": ["decision-making", "decision support", "evidence-based decision-making"],
        "decision-making": ["tomada de decisão", "decision support", "evidence-based decision-making"],
    },
    "study": {
        "revisao sistematica": ["systematic review", "systematic literature review", "evidence synthesis"],
        "revisão sistemática": ["systematic review", "systematic literature review", "evidence synthesis"],
        "systematic review": ["revisão sistemática", "systematic literature review", "evidence synthesis"],
        "revisao de literatura": ["literature review", "systematic literature review", "review"],
        "revisão de literatura": ["literature review", "systematic literature review", "review"],
        "literature review": ["revisão de literatura", "systematic literature review", "review"],
        "scoping review": ["revisão de escopo", "evidence mapping", "mapping review"],
        "metanalise": ["meta-analysis", "systematic review"],
        "metanálise": ["meta-analysis", "systematic review"],
        "meta-analysis": ["metanálise", "systematic review"],
        "review": ["literature review", "systematic review"],
    },
}


def expand_terms_with_query_synonyms(terms: list[str], block_key: str, *, query_bilingue: bool = False) -> list[str]:
    """Expande termos com sinônimos controlados, preservando limites de ruído.

    A expansão é feita dentro do bloco conceitual, para que os sinônimos entrem
    como OR na query final, enquanto os blocos permanecem ligados por AND.
    """
    base = _unique_terms(terms, max_items=18)
    mapping = QUERY_SYNONYM_MAP.get(block_key, {})
    expanded: list[str] = list(base)
    for term in base:
        normalized = _normalize_key(term)
        for key, synonyms in mapping.items():
            key_norm = _normalize_key(key)
            if key_norm and (key_norm == normalized or key_norm in normalized or normalized in key_norm):
                expanded.extend(synonyms)
    # Não aplicamos expansão bilíngue genérica aqui para evitar contaminação entre blocos
    # por termos compostos como "algorithmic governance". A expansão bilíngue principal
    # já ocorre antes da classificação e nos acréscimos controlados por bloco.
    return _unique_terms(expanded, max_items=18)


def split_main_terms_and_synonyms(main_terms: list[str], synonym_terms: list[str], *, main_limit: int = 8, synonym_limit: int = 10) -> tuple[list[str], list[str]]:
    main = _unique_terms(main_terms, max_items=main_limit)
    main_keys = {m.casefold() for m in main}
    synonyms = []
    seen = set(main_keys)
    for item in synonym_terms:
        term = _clean_query_term(item)
        key = term.casefold()
        if term and key not in seen:
            seen.add(key)
            synonyms.append(term)
        if len(synonyms) >= synonym_limit:
            break
    return main, synonyms


def extract_controlled_query_terms(text: str) -> list[str]:
    """Extrai termos conceituais curtos de frases longas de tema/recorte.

    Evita que a query receba frases completas como um único termo, preservando
    apenas conceitos úteis para os blocos booleanos.
    """
    raw = _clean_query_term(text)
    if not raw:
        return []

    word_count = len(re.findall(r"[A-Za-zÀ-ÿ0-9]+", raw))
    if word_count <= 6:
        return [raw]

    normalized = _normalize_key(raw)
    candidates: list[str] = []

    controlled_keys: list[str] = []
    controlled_keys.extend(BILINGUAL_TERM_MAP.keys())
    for mapping in QUERY_SYNONYM_MAP.values():
        controlled_keys.extend(mapping.keys())
        for values in mapping.values():
            controlled_keys.extend(values)

    for key in controlled_keys:
        key_clean = _clean_query_term(key)
        if not key_clean:
            continue
        key_norm = _normalize_key(key_clean)
        if not key_norm:
            continue
        if len(re.findall(r"[A-Za-zÀ-ÿ0-9]+", key_norm)) <= 1 and len(key_norm) <= 3:
            if re.search(rf"(?<![A-Za-zÀ-ÿ0-9]){re.escape(key_norm)}(?![A-Za-zÀ-ÿ0-9])", normalized):
                candidates.append(key_clean)
            continue
        if key_norm in normalized:
            candidates.append(key_clean)

    # Complementa com fragmentos separados por vírgula/ponto-e-vírgula somente
    # quando nenhum conceito controlado tiver sido detectado.
    if not candidates:
        for part in re.split(r"[,;]", raw):
            part = _clean_query_term(part)
            if part and len(re.findall(r"[A-Za-zÀ-ÿ0-9]+", part)) <= 6:
                candidates.append(part)

    return _unique_terms(candidates, max_items=16)


def expand_seed_items_for_query(items: list[str]) -> list[str]:
    expanded: list[str] = []
    for item in items:
        extracted = extract_controlled_query_terms(item)
        if extracted:
            expanded.extend(extracted)
    return _unique_terms(expanded, max_items=40)


def infer_search_blocks(
    tema: str,
    recorte: str,
    palavras: list[str],
    tipo_estudo: str,
    *,
    idiomas: list[str] | None = None,
    query_bilingue: bool = False,
    explicit_blocks: dict[str, list[str]] | None = None,
) -> dict[str, list[str]]:
    explicit_blocks = explicit_blocks or {}
    terms = ensure_study_type_in_keywords(palavras[:] if palavras else [tema], tipo_estudo)
    terms = expand_bilingual_terms(terms, tema=tema, recorte=recorte, idiomas=idiomas, enabled=query_bilingue)
    seed = expand_seed_items_for_query(terms + [tema, recorte])

    blocks = {
        "technology": _unique_terms(explicit_blocks.get("technology", []), max_items=10),
        "context": _unique_terms(explicit_blocks.get("context", []), max_items=10),
        "analytic": _unique_terms(explicit_blocks.get("analytic", []), max_items=10),
        "study": _unique_terms(explicit_blocks.get("study", []), max_items=10),
        "general": [],
        "exclude": _unique_terms(explicit_blocks.get("exclude", []), max_items=8),
    }

    for term in seed:
        bucket = _classify_term(term)
        key = {"technology": "technology", "context": "context", "analytic": "analytic", "study": "study"}.get(bucket, "general")
        blocks[key].append(term)

    # Não injetar termos fixos de um tema específico quando query_bilingue=True.
    # A expansão bilíngue deve vir apenas dos termos efetivamente informados
    # pelo usuário/IA, via BILINGUAL_TERM_MAP e QUERY_SYNONYM_MAP.

    blocks["study"].extend(study_type_terms(tipo_estudo))

    # Expansão controlada de sinônimos: amplia o OR dentro de cada bloco,
    # sem transformar os sinônimos em blocos obrigatórios separados.
    for key in ["technology", "context", "analytic", "study"]:
        blocks[key] = expand_terms_with_query_synonyms(blocks[key], key, query_bilingue=query_bilingue)

    for key, max_items in [("technology", 14), ("context", 14), ("analytic", 16), ("study", 12), ("general", 8), ("exclude", 8)]:
        blocks[key] = _unique_terms(blocks[key], max_items=max_items)

    # Evita que sugestões genéricas da IA contaminem temas não relacionados a IA
    # com termos como "AI", "machine learning" ou "artificial intelligence".
    blocks = remove_ai_noise_from_blocks(blocks, tema, recorte, None)
    for key, max_items in [("technology", 14), ("context", 14), ("analytic", 16), ("study", 12), ("general", 8), ("exclude", 8)]:
        blocks[key] = _unique_terms(blocks[key], max_items=max_items)
    return blocks


QUERY_GENERIC_TERMS = {
    "governance", "public governance", "governança", "governanca", "governança pública", "governanca publica",
    "public administration", "administração pública", "administracao publica", "public sector", "setor público",
    "setor publico", "government", "governo", "state", "estado", "public policy", "políticas públicas",
    "politicas publicas", "policy implementation", "implementação de políticas", "implementacao de politicas",
    "government effectiveness", "state effectiveness", "policy effectiveness", "accountability", "review", "revisão",
    "revisao", "literature review", "systematic review", "scoping review"
}

QUERY_SPECIFICITY_MARKERS = (
    "state capacity", "capacidades estatais", "capacidade estatal",
    "coercive capacity", "capacidade coercitiva", "state coercion", "coerção estatal", "coercao estatal",
    "centralization", "centralização", "centralizacao", "decentralization", "descentralização", "descentralizacao",
    "institutional coordination", "coordenação institucional", "coordenacao institucional",
    "institutional arrangement", "institutional arrangements", "arranjo institucional", "arranjos institucionais",
    "policy outcomes", "public policy outcomes", "resultados de políticas públicas", "resultados de politicas publicas",
    "state performance", "desempenho estatal", "policy performance", "authority", "autoridade estatal"
)


def _query_source_seed_text(tema: str, recorte: str, objetivo: str, tipo_estudo: str) -> dict[str, str]:
    return {
        "tema": _normalize_key(tema),
        "recorte": _normalize_key(recorte),
        "objetivo": _normalize_key(objetivo),
        "tipo_estudo": _normalize_key(tipo_estudo),
    }


def _is_generic_query_term(term: str) -> bool:
    norm = _normalize_key(term)
    if not norm:
        return False
    if _has_specific_query_marker(term):
        return False
    if norm in {_normalize_key(x) for x in QUERY_GENERIC_TERMS}:
        return True
    generic_markers = (
        "governance", "public governance", "public administration", "public sector",
        "government", "public policy", "policy implementation",
        "government effectiveness", "policy effectiveness", "accountability"
    )
    return any(marker in norm for marker in generic_markers)


def _has_specific_query_marker(term: str) -> bool:
    norm = _normalize_key(term)
    if not norm:
        return False
    return any(_normalize_key(marker) in norm for marker in QUERY_SPECIFICITY_MARKERS)


def _term_occurs_in_seed(term_norm: str, seed_norm: str) -> bool:
    if not term_norm or not seed_norm:
        return False
    return term_norm in seed_norm


def _query_term_priority(term: str, block_key: str, seed_profile: dict[str, str]) -> int:
    norm = _normalize_key(term)
    if not norm:
        return -999
    score = 0
    token_count = len(re.findall(r"[A-Za-zÀ-ÿ0-9]+", norm))
    score += min(token_count, 5)
    if _term_occurs_in_seed(norm, seed_profile.get("tema", "")):
        score += 10
    if _term_occurs_in_seed(norm, seed_profile.get("recorte", "")):
        score += 12
    if _term_occurs_in_seed(norm, seed_profile.get("objetivo", "")):
        score += 9
    if block_key == "study" and _term_occurs_in_seed(norm, seed_profile.get("tipo_estudo", "")):
        score += 10
    if _has_specific_query_marker(term):
        score += 7
    if block_key in {"context", "analytic"} and token_count >= 2:
        score += 1
    if _is_generic_query_term(term):
        score -= 6
    if token_count == 1 and _is_generic_query_term(term):
        score -= 2
    return score


def _rank_query_terms(terms: list[str], block_key: str, seed_profile: dict[str, str]) -> list[str]:
    ranked = sorted(
        _unique_terms(terms, max_items=24),
        key=lambda term: (
            -_query_term_priority(term, block_key, seed_profile),
            _is_generic_query_term(term),
            -len(re.findall(r"[A-Za-zÀ-ÿ0-9]+", _normalize_key(term))),
            term.casefold(),
        ),
    )
    return ranked


def _trim_ranked_terms_for_source(ranked_terms: list[str], block_key: str, source: str, seed_profile: dict[str, str]) -> list[str]:
    if not ranked_terms:
        return []

    focal_terms = [t for t in ranked_terms if _query_term_priority(t, block_key, seed_profile) >= 8 or _has_specific_query_marker(t)]
    generic_terms = [t for t in ranked_terms if t not in focal_terms]

    source_caps = {
        "semantic_scholar": {"technology": 4, "context": 4, "analytic": 4, "study": 3, "general": 4},
        "scopus": {"technology": 6, "context": 6, "analytic": 7, "study": 5, "general": 5},
        "web_of_science": {"technology": 6, "context": 6, "analytic": 7, "study": 5, "general": 5},
        "pubmed": {"technology": 4, "context": 4, "analytic": 5, "study": 5, "general": 4},
        "openalex": {"technology": 4, "context": 4, "analytic": 4, "study": 4, "general": 4},
        "crossref": {"technology": 3, "context": 3, "analytic": 4, "study": 3, "general": 3},
        "europe_pmc": {"technology": 4, "context": 4, "analytic": 5, "study": 5, "general": 4},
        "core": {"technology": 4, "context": 4, "analytic": 4, "study": 3, "general": 4},
    }
    cap = source_caps.get(source, {}).get(block_key, 4)

    if source in {"pubmed", "openalex", "crossref"} and block_key in {"context", "analytic"}:
        generic_cap = 1
    elif source in {"europe_pmc", "semantic_scholar"} and block_key in {"context", "analytic"}:
        generic_cap = 1
    else:
        generic_cap = 2

    if focal_terms:
        kept = focal_terms[:cap]
        remaining = max(0, cap - len(kept))
        if remaining > 0 and generic_cap > 0:
            kept.extend(generic_terms[:min(remaining, generic_cap)])
        return _unique_terms(kept, max_items=cap)

    return _unique_terms(ranked_terms, max_items=cap)


def _normalized_terms(terms: list[str]) -> set[str]:
    return {_normalize_key(t) for t in terms if _normalize_key(t)}


def _term_matches_any_marker(term: str, markers: tuple[str, ...]) -> bool:
    norm = _normalize_key(term)
    if not norm:
        return False
    return any(_normalize_key(marker) in norm for marker in markers)


QUERY_CAPACITY_MARKERS = (
    "state capacity", "capacidades estatais", "capacidade estatal",
)

QUERY_MECHANISM_MARKERS = (
    "coercive capacity", "capacidade coercitiva", "state coercion", "coerção estatal", "coercao estatal",
    "centralization", "centralizacao", "centralização", "decentralization", "descentralizacao", "descentralização",
    "institutional coordination", "coordenação institucional", "coordenacao institucional",
    "institutional arrangement", "institutional arrangements", "arranjo institucional", "arranjos institucionais",
    "state authority", "authority", "autoridade estatal",
)

QUERY_OUTCOME_MARKERS = (
    "policy implementation", "implementação de políticas", "implementacao de politicas",
    "policy outcomes", "public policy outcomes", "resultados de políticas públicas", "resultados de politicas publicas",
    "state performance", "desempenho estatal", "policy performance", "government effectiveness",
)

QUERY_REVIEW_CANONICAL = (
    "systematic review", "literature review", "review", "scoping review",
    "revisão sistemática", "revisão de literatura", "revisão de escopo", "revisão",
)


def _related_bilingual_terms(term: str) -> list[str]:
    norm = _normalize_key(term)
    if not norm:
        return []
    related: list[str] = []
    for key, values in BILINGUAL_TERM_MAP.items():
        universe = [key] + list(values)
        normalized_universe = {_normalize_key(item) for item in universe}
        if norm in normalized_universe:
            related.extend(universe)
    return _unique_terms(related, max_items=12)


def _pick_counterpart_from_pool(term: str, pool: list[str]) -> str | None:
    related = _related_bilingual_terms(term)
    if not related:
        return None
    norm = _normalize_key(term)
    candidates = []
    for item in pool:
        item_norm = _normalize_key(item)
        if not item_norm or item_norm == norm:
            continue
        if item_norm in {_normalize_key(x) for x in related}:
            candidates.append(item)
    if not candidates:
        return None
    prefer_english = _is_portuguese_like_term(term)
    ranked = sorted(
        _unique_terms(candidates, max_items=10),
        key=lambda item: (
            0 if ((_is_portuguese_like_term(item) and not prefer_english) or (not _is_portuguese_like_term(item) and prefer_english)) else 1,
            0 if _has_specific_query_marker(item) else 1,
            -len(re.findall(r"[A-Za-zÀ-ÿ0-9]+", _normalize_key(item))),
            item.casefold(),
        ),
    )
    return ranked[0] if ranked else None


def _prepend_best_anchor_if_missing(current: list[str], pool: list[str], markers: tuple[str, ...], max_items: int) -> list[str]:
    if any(_term_matches_any_marker(term, markers) for term in current):
        return _unique_terms(current, max_items=max_items)
    candidates = [term for term in pool if _term_matches_any_marker(term, markers)]
    if not candidates:
        return _unique_terms(current, max_items=max_items)
    ranked = sorted(
        _unique_terms(candidates, max_items=12),
        key=lambda item: (
            0 if not _is_portuguese_like_term(item) else 1,
            0 if _has_specific_query_marker(item) else 1,
            -len(re.findall(r"[A-Za-zÀ-ÿ0-9]+", _normalize_key(item))),
            item.casefold(),
        ),
    )
    return _unique_terms([ranked[0]] + current, max_items=max_items)


def _augment_with_counterparts(current: list[str], pool: list[str], max_items: int) -> list[str]:
    augmented = list(current)
    for term in list(current):
        counterpart = _pick_counterpart_from_pool(term, pool)
        if counterpart and _normalize_key(counterpart) not in _normalized_terms(augmented):
            augmented.append(counterpart)
        if len(augmented) >= max_items:
            break
    return _unique_terms(augmented, max_items=max_items)


def _ensure_english_support(current: list[str], pool: list[str], max_items: int) -> list[str]:
    if any(not _is_portuguese_like_term(term) for term in current):
        return _unique_terms(current, max_items=max_items)
    candidates = [term for term in pool if not _is_portuguese_like_term(term)]
    if not candidates:
        return _unique_terms(current, max_items=max_items)
    ranked = sorted(
        _unique_terms(candidates, max_items=12),
        key=lambda item: (
            0 if _has_specific_query_marker(item) else 1,
            0 if _term_matches_any_marker(item, QUERY_CAPACITY_MARKERS + QUERY_MECHANISM_MARKERS + QUERY_OUTCOME_MARKERS) else 1,
            -len(re.findall(r"[A-Za-zÀ-ÿ0-9]+", _normalize_key(item))),
            item.casefold(),
        ),
    )
    return _unique_terms(current + [ranked[0]], max_items=max_items)


def tighten_blocks_for_source(
    blocks: dict[str, list[str]],
    source: str,
    *,
    tema: str,
    recorte: str,
    objetivo: str,
    tipo_estudo: str,
) -> dict[str, list[str]]:
    original_blocks = {key: list(value) for key, value in blocks.items()}
    tightened = {key: list(value) for key, value in blocks.items()}
    seed_profile = _query_source_seed_text(tema, recorte, objetivo, tipo_estudo)

    for key in ["technology", "context", "analytic", "study", "general"]:
        ranked = _rank_query_terms(tightened.get(key, []), key, seed_profile)
        tightened[key] = _trim_ranked_terms_for_source(ranked, key, source, seed_profile)

    if source in {"semantic_scholar", "pubmed", "openalex", "crossref", "europe_pmc", "scopus", "web_of_science"}:
        context_pool = original_blocks.get("context", []) + original_blocks.get("general", [])
        analytic_pool = original_blocks.get("analytic", []) + original_blocks.get("general", [])
        study_pool = original_blocks.get("study", []) + study_type_terms(tipo_estudo)

        tightened["context"] = _prepend_best_anchor_if_missing(tightened.get("context", []), context_pool + analytic_pool, QUERY_CAPACITY_MARKERS, max_items=max(len(tightened.get("context", [])) + 1, 5))
        tightened["analytic"] = _prepend_best_anchor_if_missing(tightened.get("analytic", []), analytic_pool + context_pool, QUERY_MECHANISM_MARKERS, max_items=max(len(tightened.get("analytic", [])) + 1, 5))
        tightened["analytic"] = _prepend_best_anchor_if_missing(tightened.get("analytic", []), analytic_pool + context_pool, QUERY_OUTCOME_MARKERS, max_items=max(len(tightened.get("analytic", [])) + 1, 6))

        if source in {"pubmed", "openalex", "crossref", "europe_pmc", "semantic_scholar"}:
            tightened["context"] = _augment_with_counterparts(tightened.get("context", []), context_pool, max_items=max(len(tightened.get("context", [])) + 2, 6))
            tightened["analytic"] = _augment_with_counterparts(tightened.get("analytic", []), analytic_pool, max_items=max(len(tightened.get("analytic", [])) + 2, 7))

        if source in {"pubmed", "europe_pmc", "semantic_scholar", "openalex"}:
            tightened["context"] = _ensure_english_support(tightened.get("context", []), context_pool + analytic_pool, max_items=max(len(tightened.get("context", [])) + 1, 6))
            tightened["analytic"] = _ensure_english_support(tightened.get("analytic", []), analytic_pool + context_pool, max_items=max(len(tightened.get("analytic", [])) + 1, 7))

        review_ranked = _rank_query_terms(_unique_terms(study_pool, max_items=12), "study", seed_profile)
        preferred_review_terms = [term for term in review_ranked if _term_matches_any_marker(term, QUERY_REVIEW_CANONICAL)]
        if preferred_review_terms:
            tightened["study"] = _unique_terms(preferred_review_terms[:4] + tightened.get("study", []), max_items=5)

    # Reforça a presença do núcleo substantivo do tema/recorte nas bases mais sensíveis a inflation.
    if source in {"pubmed", "openalex", "crossref", "europe_pmc"}:
        anchors = []
        for key in ["context", "analytic"]:
            anchors.extend([t for t in tightened.get(key, []) if _has_specific_query_marker(t)])
        if not anchors:
            extracted = expand_seed_items_for_query([tema, recorte, objetivo])
            extracted_ranked = _rank_query_terms(extracted, "analytic", seed_profile)
            anchors = [t for t in extracted_ranked if _has_specific_query_marker(t)]
            if anchors:
                tightened["analytic"] = _unique_terms(anchors[:3] + tightened.get("analytic", []), max_items=6)

    return tightened


PORTUGUESE_QUERY_MARKERS = {
    "administracao", "administração", "publica", "pública", "publicas", "públicas",
    "setor", "governo", "estado", "estatal", "estatais", "capacidades",
    "capacidade", "coercitiva", "coercao", "coerção", "centralizacao", "centralização",
    "politicas", "políticas", "desempenho", "revisao", "revisão", "sistematica",
    "sistemática", "literatura", "gestao", "gestão", "governanca", "governança",
    "integridade", "controles", "internos", "tomada", "decisao", "decisão",
}


def _is_portuguese_like_term(term: str) -> bool:
    """Heurística leve para não tornar termos em português obrigatórios no Semantic Scholar.

    A busca bilíngue continua preservada: os termos em português entram como
    alternativas nos grupos OR. Porém, como o Semantic Scholar tem predominância
    internacional/inglês nos metadados, os termos obrigatórios (+termo) devem
    preferir equivalentes em inglês quando existirem.
    """
    raw = _clean_query_term(term)
    if not raw:
        return False
    if re.search(r"[áàâãéêíóôõúçÁÀÂÃÉÊÍÓÔÕÚÇ]", raw):
        return True
    words = set(re.findall(r"[A-Za-zÀ-ÿ]+", _normalize_key(raw)))
    return bool(words & PORTUGUESE_QUERY_MARKERS)


def _semantic_filtered_terms(terms: list[str], max_items: int = 30) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for term in _unique_terms(terms, max_items=max_items):
        term = _clean_query_term(term)
        if not term or term.startswith('-'):
            continue
        if len(re.findall(r"[A-Za-zÀ-ÿ0-9]+", term)) > 5:
            continue
        key = term.casefold()
        if key in seen:
            continue
        seen.add(key)
        out.append(term)
    return out


def _semantic_primary_terms(terms: list[str], max_items: int = 4) -> list[str]:
    """Termos positivos curtos para o Semantic Scholar, com preferência por inglês.

    A preferência por inglês vale apenas para ordenação. Termos em português não
    são descartados; eles continuam disponíveis para grupos OR bilíngues.
    """
    filtered = _semantic_filtered_terms(terms, max_items=30)
    english_like = [t for t in filtered if not _is_portuguese_like_term(t)]
    portuguese_like = [t for t in filtered if _is_portuguese_like_term(t)]
    return _unique_terms(english_like + portuguese_like, max_items=max_items)


def _semantic_or_terms(terms: list[str], max_items: int = 5) -> list[str]:
    """Seleciona termos para grupo OR preservando bilinguismo quando possível."""
    filtered = _semantic_filtered_terms(terms, max_items=30)
    english_like = [t for t in filtered if not _is_portuguese_like_term(t)]
    portuguese_like = [t for t in filtered if _is_portuguese_like_term(t)]
    selected: list[str] = []
    selected.extend(english_like[:max(1, max_items - 1)])
    if portuguese_like and len(selected) < max_items:
        selected.append(portuguese_like[0])
    selected.extend(english_like[max(1, max_items - 1):])
    selected.extend(portuguese_like[1:])
    return _unique_terms(selected, max_items=max_items)


def _semantic_mandatory_term(terms: list[str]) -> str | None:
    """Escolhe termo obrigatório para Semantic Scholar preferindo equivalente em inglês."""
    filtered = _semantic_filtered_terms(terms, max_items=30)
    if not filtered:
        return None
    for term in filtered:
        if not _is_portuguese_like_term(term):
            return term
    return filtered[0]

def _best_semantic_term_for_markers(blocks: dict[str, list[str]], markers: tuple[str, ...], fallback_keys: list[str]) -> str | None:
    pool: list[str] = []
    for key in fallback_keys:
        pool.extend(blocks.get(key, []))
    candidates = [term for term in _unique_terms(pool, max_items=24) if _term_matches_any_marker(term, markers)]
    if not candidates:
        return None
    ranked = sorted(
        candidates,
        key=lambda item: (
            0 if not _is_portuguese_like_term(item) else 1,
            0 if _has_specific_query_marker(item) else 1,
            -len(re.findall(r"[A-Za-zÀ-ÿ0-9]+", _normalize_key(item))),
            item.casefold(),
        ),
    )
    return ranked[0] if ranked else None

def _best_terms_for_markers(
    blocks: dict[str, list[str]],
    markers: tuple[str, ...],
    fallback_keys: list[str],
    *,
    max_items: int = 3,
    prefer_english: bool = False,
) -> list[str]:
    pool: list[str] = []
    for key in fallback_keys:
        pool.extend(blocks.get(key, []))
    candidates = [term for term in _unique_terms(pool, max_items=32) if _term_matches_any_marker(term, markers)]
    if not candidates:
        return []
    if prefer_english:
        english_candidates = [term for term in candidates if not _is_portuguese_like_term(term)]
        if english_candidates:
            candidates = english_candidates
    ranked = sorted(
        _unique_terms(candidates, max_items=24),
        key=lambda item: (
            0 if (prefer_english and not _is_portuguese_like_term(item)) or (not prefer_english and _has_specific_query_marker(item)) else 1,
            0 if _has_specific_query_marker(item) else 1,
            -len(re.findall(r"[A-Za-zÀ-ÿ0-9]+", _normalize_key(item))),
            item.casefold(),
        ),
    )
    return _unique_terms(ranked[:max_items], max_items=max_items)


def _prefer_english_terms(terms: list[str], *, max_items: int = 4) -> list[str]:
    ranked = sorted(
        _unique_terms(terms, max_items=24),
        key=lambda item: (
            0 if not _is_portuguese_like_term(item) else 1,
            0 if _has_specific_query_marker(item) else 1,
            -len(re.findall(r"[A-Za-zÀ-ÿ0-9]+", _normalize_key(item))),
            item.casefold(),
        ),
    )
    english = [item for item in ranked if not _is_portuguese_like_term(item)]
    if english:
        ranked = english + [item for item in ranked if _is_portuguese_like_term(item)]
    return _unique_terms(ranked, max_items=max_items)



def build_semantic_bulk_query_from_blocks(blocks: dict[str, list[str]]) -> str:
    """Monta query curta e mais natural para o Semantic Scholar.

    O Semantic Scholar tende a funcionar melhor com poucas âncoras em inglês e sem
    exigir frases raras demais no mesmo pacote. Aqui priorizamos: capacidade,
    mecanismo institucional, resultado/implementação e um marcador canônico de revisão.
    """
    chosen: list[str] = []
    chosen.extend(_best_terms_for_markers(blocks, QUERY_CAPACITY_MARKERS, ["context", "analytic", "general"], max_items=1, prefer_english=True))
    chosen.extend(_best_terms_for_markers(blocks, QUERY_MECHANISM_MARKERS, ["analytic", "context", "general"], max_items=1, prefer_english=True))
    chosen.extend(_best_terms_for_markers(blocks, QUERY_OUTCOME_MARKERS, ["analytic", "general", "context"], max_items=1, prefer_english=True))
    review_terms = _best_terms_for_markers(blocks, QUERY_REVIEW_CANONICAL, ["study", "general"], max_items=2, prefer_english=True)
    if review_terms:
        chosen.append(review_terms[0])

    if not chosen:
        chosen = _prefer_english_terms(_plain_search_terms_from_blocks(blocks, max_per_block=2), max_items=4)

    parts: list[str] = []
    for term in _unique_terms(chosen, max_items=4):
        cleaned = _clean_query_term(term)
        if not cleaned:
            continue
        parts.append(_quoted(cleaned) if re.search(r"\s", cleaned) else cleaned)
    return " ".join(parts).strip()

def strip_semantic_negative_terms(query: str) -> str:
    """Remove termos negativos de uma query Semantic para fallback padrão.

    O endpoint /paper/search padrão não deve receber exclusões booleanas complexas.
    """
    # Remove -"frase com espaços" e -palavra
    cleaned = re.sub(r'-"[^"]+"', ' ', query or '')
    cleaned = re.sub(r"-'[^']+'", ' ', cleaned)
    cleaned = re.sub(r"-\S+", ' ', cleaned)
    cleaned = re.sub(r"\s+", ' ', cleaned).strip()
    return cleaned


def build_semantic_relaxed_query_from_blocks(blocks: dict[str, list[str]]) -> str:
    terms = []
    terms.extend(_best_terms_for_markers(blocks, QUERY_CAPACITY_MARKERS, ["context", "analytic", "general"], max_items=1, prefer_english=True))
    terms.extend(_best_terms_for_markers(blocks, QUERY_OUTCOME_MARKERS, ["analytic", "general", "context"], max_items=1, prefer_english=True))
    terms.extend(_best_terms_for_markers(blocks, QUERY_REVIEW_CANONICAL, ["study", "general"], max_items=1, prefer_english=True))
    if not terms:
        terms = _prefer_english_terms(_plain_search_terms_from_blocks(blocks, max_per_block=2), max_items=3)
    parts: list[str] = []
    for term in _unique_terms(terms, max_items=3):
        cleaned = _clean_query_term(term)
        if not cleaned:
            continue
        parts.append(_quoted(cleaned) if " " in cleaned else cleaned)
    return " ".join(parts).strip()


def _semantic_extract_terms_from_query(query: str) -> list[str]:
    terms: list[str] = []
    terms.extend(re.findall(r'"([^"]+)"', query or ''))
    stripped = re.sub(r'"[^"]+"', ' ', query or '')
    terms.extend(re.findall(r"[A-Za-z][A-Za-z\-]{2,}", stripped))
    cleaned = []
    for term in terms:
        term = _clean_query_term(term)
        if not term:
            continue
        if term.upper() in {'AND', 'OR', 'NOT'}:
            continue
        cleaned.append(term)
    return _unique_terms(cleaned, max_items=24)


def _semantic_has_marker(terms: list[str], markers: tuple[str, ...]) -> bool:
    return any(_term_matches_any_marker(term, markers) for term in terms)


def _semantic_pick_marker_term(terms: list[str], markers: tuple[str, ...], default: str) -> str:
    ranked = _prefer_english_terms(terms, max_items=24)
    for term in ranked:
        if _term_matches_any_marker(term, markers):
            return term
    return default


def build_semantic_fallback_queries(query: str) -> list[str]:
    terms = _semantic_extract_terms_from_query(query)
    english_terms = _prefer_english_terms(terms, max_items=24)

    capacity = _semantic_pick_marker_term(english_terms, QUERY_CAPACITY_MARKERS, 'state capacity')
    mechanism_default = 'centralization' if _semantic_has_marker(english_terms, QUERY_MECHANISM_MARKERS) else 'public policy'
    mechanism = _semantic_pick_marker_term(
        english_terms,
        QUERY_MECHANISM_MARKERS,
        mechanism_default,
    )
    outcome_default = 'policy implementation' if _semantic_has_marker(english_terms, QUERY_OUTCOME_MARKERS) else 'policy outcomes'
    outcome = _semantic_pick_marker_term(
        english_terms,
        QUERY_OUTCOME_MARKERS,
        outcome_default,
    )
    review = _semantic_pick_marker_term(english_terms, QUERY_REVIEW_CANONICAL, 'review')

    candidates: list[list[str]] = [
        [capacity, mechanism, outcome, review],
        [capacity, outcome, review],
        [capacity, 'public policy', review],
    ]

    if mechanism.lower() in {'centralization', 'decentralization'}:
        counterpart = 'decentralization' if mechanism.lower() == 'centralization' else 'centralization'
        candidates.insert(1, [capacity, mechanism, counterpart, review])

    out: list[str] = []
    seen: set[str] = set()
    for parts in candidates:
        built_parts = []
        for term in _unique_terms(parts, max_items=4):
            cleaned = _clean_query_term(term)
            if not cleaned:
                continue
            built_parts.append(_quoted(cleaned) if ' ' in cleaned else cleaned)
        built = ' '.join(built_parts).strip()
        if built and built not in seen:
            seen.add(built)
            out.append(built)
    return out

def build_scopus_query_from_blocks(blocks: dict[str, list[str]], periodo: str | None = None, idiomas: list[str] | None = None, tipo_estudo: str | None = None) -> str:
    """Monta query Scopus com tipo de estudo obrigatório, mas em bloco canônico enxuto.

    O ajuste preserva o pedido do usuário de manter o tipo de estudo como requisito,
    porém evita o modelo anterior de quatro blocos AND excessivamente raros. A query usa
    três núcleos obrigatórios: (1) capacidade/autoridade/campo, (2) mecanismo/resultado
    e (3) tipo de estudo em formulações canônicas de revisão.
    """
    capacity_terms = _best_terms_for_markers(blocks, QUERY_CAPACITY_MARKERS, ["context", "analytic", "general"], max_items=2, prefer_english=True)
    mechanism_terms = _best_terms_for_markers(blocks, QUERY_MECHANISM_MARKERS, ["analytic", "context", "general"], max_items=3, prefer_english=True)
    outcome_terms = _best_terms_for_markers(blocks, QUERY_OUTCOME_MARKERS, ["analytic", "general", "context"], max_items=3, prefer_english=True)
    review_terms = _best_terms_for_markers(blocks, QUERY_REVIEW_CANONICAL, ["study", "general"], max_items=3, prefer_english=True)

    capacity_terms = _unique_terms(
        capacity_terms + ["state capacity", "public administration", "government effectiveness"],
        max_items=5,
    )
    mechanism_outcome_terms = _unique_terms(
        mechanism_terms + outcome_terms + ["centralization", "decentralization", "institutional arrangements", "institutional coordination", "policy implementation", "policy outcomes", "state performance"],
        max_items=7,
    )
    review_terms = _unique_terms(
        review_terms + ["systematic literature review", "literature review", "systematic review", "scoping review", "review"],
        max_items=5,
    )

    anchor_group = _scopus_group(_prefer_english_terms(capacity_terms, max_items=5))
    mechanism_outcome_group = _scopus_group(_prefer_english_terms(mechanism_outcome_terms, max_items=7))
    review_group = _scopus_group(_prefer_english_terms(review_terms, max_items=4))

    groups = [g for g in [anchor_group, mechanism_outcome_group, review_group] if g]
    if not groups:
        general = _scopus_group(_prefer_english_terms(_plain_search_terms_from_blocks(blocks, max_per_block=3), max_items=8))
        groups = [general] if general else []

    core = " AND ".join(groups)
    query = f"TITLE-ABS-KEY({core})" if core else ""
    years = parse_periodo_year_range(periodo)
    if years:
        start, end = years
        query += f" AND PUBYEAR > {start - 1} AND PUBYEAR < {end + 1}"
    query = append_scopus_language_filter(query, idiomas)
    return query.strip()


def build_wos_query_from_blocks(blocks: dict[str, list[str]], periodo: str | None = None, idiomas: list[str] | None = None) -> str:
    groups: list[str] = []
    for key in ["technology", "context", "analytic", "study"]:
        group = _wos_group(blocks.get(key, []))
        if group:
            groups.append(group)
    if not groups:
        groups = [_wos_group(blocks.get("general", []))]
    core = " AND ".join(g for g in groups if g) or _wos_group(blocks.get("general", [])) or ""
    query = f"TS=({core})" if core else ""
    years = parse_periodo_year_range(periodo)
    if years:
        start, end = years
        query += f" AND PY=({start}-{end})"
    # O Web of Science Starter suporta apenas um subconjunto de field tags.
    # Como LA não consta entre os tags suportados no Starter, o filtro de idioma
    # é aplicado apenas em pós-processamento Python, não na query.
    return query.strip()

def _pubmed_term(term: str) -> str:
    term = _clean_query_term(term)
    if not term:
        return ""
    if re.search(r"\s", term):
        return f'"{term}"[tiab]'
    return f'{term}[tiab]'

def _pubmed_group(terms: list[str], max_items: int = 12) -> str:
    cleaned = [_pubmed_term(t) for t in _unique_terms(terms, max_items=max_items)]
    cleaned = [t for t in cleaned if t]
    if not cleaned:
        return ""
    return "(" + " OR ".join(cleaned) + ")"


def pubmed_language_filter(idiomas: list[str] | None) -> str:
    allowed = allowed_language_set(idiomas)
    mapping = {
        "english": "english[la]",
        "portuguese": "portuguese[la]",
        "spanish": "spanish[la]",
        "french": "french[la]",
        "german": "german[la]",
        "italian": "italian[la]",
    }
    parts = [mapping.get(lang) for lang in sorted(allowed)]
    parts = [p for p in parts if p]
    if not parts:
        return ""
    return "(" + " OR ".join(parts) + ")"

def pubmed_publication_type_filter(tipo_estudo: str | None) -> str:
    text = (tipo_estudo or "").casefold()
    if any(tok in text for tok in ["review", "revis", "metan", "meta-an", "scoping"]):
        return "(review[pt] OR systematic review[tiab] OR meta-analysis[pt] OR scoping review[tiab] OR literature review[tiab])"
    return ""

def build_pubmed_query_from_blocks(blocks: dict[str, list[str]], periodo: str | None = None, idiomas: list[str] | None = None, tipo_estudo: str | None = None) -> str:
    """Monta query PubMed com tipo de estudo obrigatório em formulação canônica leve.

    Para temas de administração pública, PubMed tem cobertura indireta; ainda assim,
    quando o usuário define um tipo de estudo, ele deve permanecer obrigatório. Aqui o
    requisito entra por um bloco de revisão canônico em inglês e pelo publication type,
    sem depender de frases literais raras em português.
    """
    capacity_terms = _best_terms_for_markers(blocks, QUERY_CAPACITY_MARKERS, ["context", "analytic", "general"], max_items=2, prefer_english=True)
    mechanism_terms = _best_terms_for_markers(blocks, QUERY_MECHANISM_MARKERS, ["analytic", "context", "general"], max_items=3, prefer_english=True)
    outcome_terms = _best_terms_for_markers(blocks, QUERY_OUTCOME_MARKERS, ["analytic", "general", "context"], max_items=3, prefer_english=True)
    review_terms = _best_terms_for_markers(blocks, QUERY_REVIEW_CANONICAL, ["study", "general"], max_items=3, prefer_english=True)

    anchor_terms = _unique_terms(
        capacity_terms + ["state capacity", "government effectiveness", "public administration", "governance", "public sector"],
        max_items=6,
    )
    mechanism_outcome_terms = _unique_terms(
        mechanism_terms + outcome_terms + ["centralization", "decentralization", "institutional arrangements", "policy implementation", "policy outcomes", "state performance"],
        max_items=7,
    )
    review_terms = _unique_terms(
        review_terms + ["systematic review", "literature review", "systematic literature review", "scoping review", "review"],
        max_items=5,
    )

    anchor_group = _pubmed_group(_prefer_english_terms(anchor_terms, max_items=6), max_items=6)
    mechanism_outcome_group = _pubmed_group(_prefer_english_terms(mechanism_outcome_terms, max_items=7), max_items=7)
    review_group = _pubmed_group(_prefer_english_terms(review_terms, max_items=4), max_items=4)

    groups: list[str] = [group for group in [anchor_group, mechanism_outcome_group, review_group] if group]
    query = " AND ".join(groups)
    years = parse_periodo_year_range(periodo)
    if years:
        start, end = years
        date_filter = f'("{start}"[dp] : "{end}"[dp])'
        query = f"{query} AND {date_filter}" if query else date_filter
    lang_filter = pubmed_language_filter(idiomas)
    if lang_filter:
        query = f"{query} AND {lang_filter}" if query else lang_filter
    ptype = pubmed_publication_type_filter(tipo_estudo)
    if ptype:
        query = f"{query} AND {ptype}" if query else ptype
    return query.strip()


def _plain_search_terms_from_blocks(blocks: dict[str, list[str]], max_per_block: int = 5) -> list[str]:
    terms: list[str] = []
    for key in ["technology", "context", "analytic", "study", "general"]:
        terms.extend(_unique_terms(blocks.get(key, []), max_items=max_per_block))
    # Remove termos de exclusão e termos vazios/muito longos.
    out: list[str] = []
    seen: set[str] = set()
    for term in terms:
        cleaned = _clean_query_term(term)
        if not cleaned or cleaned.startswith('-'):
            continue
        if len(cleaned) > 90:
            continue
        key = cleaned.casefold()
        if key not in seen:
            seen.add(key)
            out.append(cleaned)
    return out[:24]


def _openalex_term(term: str) -> str:
    """Normaliza um termo para busca textual/booleana no OpenAlex."""
    term = _clean_query_term(term)
    if not term:
        return ""
    if re.search(r"\s", term):
        return f'"{term}"'
    return term


def _openalex_group(terms: list[str], max_items: int = 6) -> str:
    cleaned = [_openalex_term(t) for t in _unique_terms(terms, max_items=max_items)]
    cleaned = [t for t in cleaned if t]
    if not cleaned:
        return ""
    if len(cleaned) == 1:
        return cleaned[0]
    return "(" + " OR ".join(cleaned) + ")"


def build_openalex_query_from_blocks(blocks: dict[str, list[str]]) -> str:
    """Monta query booleana compatível com OpenAlex.

    A documentação do OpenAlex aceita operadores booleanos AND/OR/NOT em maiúsculas
    e frases entre aspas. Quando termos não são separados por operadores, a API trata
    tudo como AND, então aqui montamos grupos explícitos para evitar concatenações
    ruins entre idiomas/sinônimos.
    """
    groups: list[str] = []
    per_block = {
        "technology": 5,
        "context": 5,
        "analytic": 6,
        "study": 5,
    }
    for key in ["technology", "context", "analytic", "study"]:
        group = _openalex_group(blocks.get(key, []), max_items=per_block.get(key, 5))
        if group:
            groups.append(group)

    if not groups:
        general = _openalex_group(blocks.get("general", []), max_items=8)
        if general:
            groups.append(general)

    query = " AND ".join(groups).strip()
    if query:
        return query

    # Fallback enxuto para casos extremos.
    terms = _plain_search_terms_from_blocks(blocks, max_per_block=4)
    priority = [_openalex_term(t) for t in terms[:10]]
    priority = [t for t in priority if t]
    return " AND ".join(priority).strip()


def build_crossref_query_from_blocks(blocks: dict[str, list[str]]) -> str:
    """Crossref funciona melhor com query.bibliographic enxuta."""
    terms = _plain_search_terms_from_blocks(blocks, max_per_block=4)
    return " ".join(terms[:14]).strip()


def _europepmc_term(term: str) -> str:
    term = _clean_query_term(term)
    if not term:
        return ""
    if re.search(r"\s", term):
        return f'"{term}"'
    return term


def _europepmc_group(terms: list[str], max_items: int = 8) -> str:
    cleaned = [_europepmc_term(t) for t in _unique_terms(terms, max_items=max_items)]
    cleaned = [x for x in cleaned if x]
    if not cleaned:
        return ""
    return "(" + " OR ".join(cleaned) + ")"


def europepmc_language_filter(idiomas: list[str] | None) -> str:
    allowed = allowed_language_set(idiomas)
    mapping = {
        "english": "ENG",
        "portuguese": "POR",
        "spanish": "SPA",
        "french": "FRE",
        "german": "GER",
        "italian": "ITA",
    }
    parts = [mapping.get(lang) for lang in sorted(allowed)]
    parts = [p for p in parts if p]
    if not parts:
        return ""
    return "(" + " OR ".join(f"LANG:{p}" for p in parts) + ")"


def build_europepmc_query_from_blocks(blocks: dict[str, list[str]], periodo: str | None = None, idiomas: list[str] | None = None, tipo_estudo: str | None = None) -> str:
    capacity_terms = _best_terms_for_markers(blocks, QUERY_CAPACITY_MARKERS, ["context", "analytic", "general"], max_items=2, prefer_english=True)
    mechanism_terms = _best_terms_for_markers(blocks, QUERY_MECHANISM_MARKERS, ["analytic", "context", "general"], max_items=3, prefer_english=True)
    outcome_terms = _best_terms_for_markers(blocks, QUERY_OUTCOME_MARKERS, ["analytic", "general", "context"], max_items=3, prefer_english=True)
    review_terms = _best_terms_for_markers(blocks, QUERY_REVIEW_CANONICAL, ["study", "general"], max_items=3, prefer_english=True)

    if not capacity_terms:
        capacity_terms = ["state capacity"]
    if not mechanism_terms:
        mechanism_terms = ["administrative centralization", "institutional arrangements"]
    if not outcome_terms:
        outcome_terms = ["policy implementation", "policy outcomes"]
    if not review_terms:
        review_terms = ["systematic review", "literature review", "review"]
    else:
        review_terms = _unique_terms(review_terms + ["systematic review", "literature review", "review"], max_items=3)

    groups: list[str] = []
    groups.append(_europepmc_group(_prefer_english_terms(capacity_terms + mechanism_terms, max_items=5), max_items=5))
    groups.append(_europepmc_group(_prefer_english_terms(outcome_terms, max_items=3), max_items=3))
    review_group = _europepmc_group(_prefer_english_terms(review_terms, max_items=3), max_items=3)
    if review_group:
        groups.append(review_group)
    query = " AND ".join(group for group in groups if group)
    years = parse_periodo_year_range(periodo)
    if years:
        start, end = years
        date_filter = f"FIRST_PDATE:[{start}-01-01 TO {end}-12-31]"
        query = f"{query} AND {date_filter}" if query else date_filter
    lang_filter = europepmc_language_filter(idiomas)
    if lang_filter:
        query = f"{query} AND {lang_filter}" if query else lang_filter
    return query.strip()


def build_core_query_from_blocks(blocks: dict[str, list[str]]) -> str:
    """CORE é sensível a queries longas/complexas; preferir busca curta e robusta.

    Prioriza poucos termos substantivos, com preferência por equivalentes em inglês
    quando houver mistura bilíngue, e sempre mantém o tipo de estudo como âncora explícita.
    """
    context_terms = _unique_terms(blocks.get("context", []), max_items=10)
    analytic_terms = _unique_terms(blocks.get("analytic", []), max_items=12)
    study_terms = _unique_terms(blocks.get("study", []), max_items=8)
    general_terms = _unique_terms(blocks.get("general", []), max_items=8)
    technology_terms = _unique_terms(blocks.get("technology", []), max_items=8)

    def _prefer_english(terms: list[str], max_items: int = 3) -> list[str]:
        english = [t for t in terms if not _is_portuguese_like_term(t)]
        portuguese = [t for t in terms if _is_portuguese_like_term(t)]
        return _unique_terms(english + portuguese, max_items=max_items)

    chosen: list[str] = []
    chosen.extend(_prefer_english(context_terms or technology_terms, max_items=2))
    chosen.extend(_prefer_english(analytic_terms, max_items=2))
    chosen.extend(_prefer_english(study_terms, max_items=1))

    if len(chosen) < 3:
        chosen.extend(_prefer_english(general_terms, max_items=6 - len(chosen)))

    chosen = _unique_terms(chosen, max_items=5)
    if not chosen:
        chosen = ['state capacity', 'policy implementation', 'review']

    return " ".join(_quoted(term) if " " in term else term for term in chosen[:5]).strip()

def build_query_for_source(
    source: str,
    tema: str,
    palavras: list[str],
    tipo_estudo: str,
    *,
    recorte: str = "",
    objetivo: str = "",
    idiomas: list[str] | None = None,
    query_bilingue: bool = False,
    periodo: str | None = None,
    explicit_blocks: dict[str, list[str]] | None = None,
) -> str:
    blocks = infer_search_blocks(
        tema,
        recorte,
        palavras,
        tipo_estudo,
        idiomas=idiomas,
        query_bilingue=query_bilingue,
        explicit_blocks=explicit_blocks,
    )
    blocks = tighten_blocks_for_source(
        blocks,
        source,
        tema=tema,
        recorte=recorte,
        objetivo=objetivo,
        tipo_estudo=tipo_estudo,
    )
    if source == "semantic_scholar":
        query = build_semantic_bulk_query_from_blocks(blocks)
        if not query:
            query = build_semantic_relaxed_query_from_blocks(blocks)
        return query
    if source == "scopus":
        return build_scopus_query_from_blocks(blocks, periodo=periodo, idiomas=idiomas, tipo_estudo=tipo_estudo)
    if source == "web_of_science":
        return build_wos_query_from_blocks(blocks, periodo=periodo, idiomas=idiomas)
    if source == "pubmed":
        return build_pubmed_query_from_blocks(blocks, periodo=periodo, idiomas=idiomas, tipo_estudo=tipo_estudo)
    if source == "openalex":
        return build_openalex_query_from_blocks(blocks)
    if source == "crossref":
        return build_crossref_query_from_blocks(blocks)
    if source == "europe_pmc":
        return build_europepmc_query_from_blocks(blocks, periodo=periodo, idiomas=idiomas, tipo_estudo=tipo_estudo)
    if source == "core":
        return build_core_query_from_blocks(blocks)
    raise ValueError(f"Base não suportada para query: {source}")

def prompt_choice(label: str, choices: dict[str, str], default: str) -> str:
    """Retorna a chave escolhida entre as opções fornecidas."""
    completer = _word_completer(list(choices.keys()) + list(choices.values()))
    while True:
        raw = _prompt_raw(label, default, completer=completer).strip().lower()
        if not raw:
            return default
        if raw in choices:
            return raw
        for key, alias in choices.items():
            if raw == alias.lower():
                return key
        print(f"Escolha inválida. Opções: {', '.join(f'{k}={v}' for k, v in choices.items())}")


def prompt_tipo_estudo_por_modo(modo: str, current: str | None, force: bool) -> str:
    if not force and current:
        return current.strip()

    if modo == "revisao_sistematica":
        print("Qual tipo de estudo você deseja pesquisar?")
        for key, label in REVIEW_STUDY_TYPE_CHOICES.items():
            print(f"  {key}. {label}")
        choice = prompt_choice(
            "Tipo de estudo a priorizar na revisão",
            REVIEW_STUDY_TYPE_CHOICES,
            "1",
        )
        if choice == "6":
            return prompt_text("Digite o tipo de estudo desejado", current, DEFAULT_TIPO_ESTUDO, force=True)
        return REVIEW_STUDY_TYPE_CHOICES[choice]

    print("Qual tipo de estudo empírico você deseja pesquisar?")
    for key, label in EMPIRICAL_STUDY_TYPE_CHOICES.items():
        print(f"  {key}. {label}")
    choice = prompt_choice(
        "Tipo de estudo empírico a priorizar",
        EMPIRICAL_STUDY_TYPE_CHOICES,
        "1",
    )
    if choice == "8":
        return prompt_text("Digite o tipo de estudo empírico desejado", current, DEFAULT_TIPO_ESTUDO_EMPIRICO, force=True)
    return EMPIRICAL_STUDY_TYPE_CHOICES[choice]


def prompt_citation_style(current: str | None, force: bool) -> str:
    if not force and current:
        return normalize_citation_style(current)
    print("Estilos bibliográficos disponíveis:")
    print("  1) ABNT")
    print("  2) APA")
    print("  3) Chicago")
    print("  4) MLA")
    print("  5) Vancouver")
    choices = {
        "1": "ABNT",
        "2": "APA",
        "3": "Chicago",
        "4": "MLA",
        "5": "Vancouver",
        "abnt": "ABNT",
        "apa": "APA",
        "chicago": "Chicago",
        "mla": "MLA",
        "vancouver": "Vancouver",
    }
    selected = prompt_choice("Estilo de citações e referências bibliográficas", choices, "1")
    return normalize_citation_style(choices[selected])


def normalize_triagem_rigor(value: str | None) -> str:
    raw = (value or "moderado").strip().lower().replace("á", "a").replace("é", "e").replace("ó", "o")
    aliases = {
        "estrito": "estrito",
        "rigido": "estrito",
        "rígido": "estrito",
        "moderado": "moderado",
        "medio": "moderado",
        "médio": "moderado",
        "exploratorio": "exploratorio",
        "exploratório": "exploratorio",
        "amplo": "exploratorio",
    }
    return aliases.get(raw, "moderado")


def prompt_triagem_rigor(current: str | None, force: bool) -> str:
    if not force and current:
        return normalize_triagem_rigor(current)
    print("Rigor da triagem PRISMA:")
    print("  1) Estrito — exige aderência forte a tema, recorte, objetivo e tipo de estudo")
    print("  2) Moderado — tema é obrigatório; recorte e objetivo orientam a seleção")
    print("  3) Exploratório — prioriza o melhor texto disponível quando a literatura é escassa")
    choices = {
        "1": "estrito",
        "2": "moderado",
        "3": "exploratorio",
        "estrito": "estrito",
        "moderado": "moderado",
        "exploratorio": "exploratorio",
        "exploratório": "exploratorio",
    }
    selected = prompt_choice("Rigor da triagem", choices, "2")
    return normalize_triagem_rigor(choices[selected])


def ensure_openai_api_key(interactive: bool) -> bool:
    if os.getenv("OPENAI_API_KEY"):
        return True
    if not interactive:
        return False
    raw = _prompt_raw("Chave da OpenAI (não será salva; Enter para cancelar)", None, password=True)
    if raw:
        os.environ["OPENAI_API_KEY"] = raw
        return True
    return False


def suggest_keywords_with_openai(
    tema: str,
    recorte: str,
    objetivo: str,
    tipo_estudo: str,
    bases: list[str],
    idiomas: list[str],
    model: str,
    query_bilingue: bool,
    periodo: str | None = None,
) -> SearchSuggestionOutput:
    client = make_openai_client()

    class _SearchSuggestionOutput(SearchSuggestionOutput):
        pass

    prompt = textwrap.dedent(
        f"""
        Você é um assistente de metodologia de busca bibliográfica.
        Gere sugestões iniciais de palavras-chave e strings de busca para bases acadêmicas.

        Tema central: {tema}
        Recorte específico: {recorte}
        Objetivo da atividade: {objetivo}
        Tipo de estudo priorizado: {tipo_estudo}
        Período desejado: {periodo or 'não informado'}
        Bases selecionadas: {', '.join(SOURCE_LABELS.get(b, b) for b in bases)}
        Idiomas aceitáveis: {', '.join(idiomas)}
        Query bilíngue (português + inglês): {'sim' if query_bilingue else 'não'}

        Regras gerais:
        - proponha palavras-chave diretamente relacionadas ao tema, ao recorte e ao objetivo;
        - inclua termos em português e inglês quando isso ampliar a busca;
        - mantenha foco em busca acadêmica, evitando termos vagos demais;
        - inclua explicitamente o descritor do tipo de estudo também no campo palavras_chave;
        - devolva blocos semânticos separados, porque o Python montará a sintaxe final de cada base;
        - não deixe blocos vazios quando houver termos pertinentes;
        - não explique demais: devolva apenas os campos estruturados.

        Blocos obrigatórios de termos:
        - bloco_tecnologia: núcleo temático principal quando houver tecnologia/IA/métodos digitais; se o tema não envolver tecnologia, use este campo apenas para conceitos centrais do tema e nunca inclua AI/IA/artificial intelligence;
        - sinonimos_tecnologia: sinônimos ou equivalentes controlados para o núcleo temático; se o tema não envolver tecnologia, não inclua termos de IA;
        - bloco_contexto: termos principais sobre setor público, governo, administração pública ou governo federal;
        - sinonimos_contexto: sinônimos ou equivalentes controlados para o bloco de contexto institucional;
        - bloco_dimensao_analitica: termos principais sobre governança, compliance, gestão de riscos, integridade, controles internos, accountability etc.;
        - sinonimos_dimensao_analitica: sinônimos ou equivalentes controlados para o bloco analítico;
        - bloco_tipo_estudo: termos principais sobre o tipo priorizado, como systematic review, literature review, scoping review, meta-analysis;
        - sinonimos_tipo_estudo: sinônimos ou equivalentes controlados para o tipo de estudo;
        - termos_exclusao: termos que devem ser excluídos quando forem claramente fora do recorte; use lista vazia se não houver.

        Regras para sinônimos:
        - sinônimos devem entrar como alternativas do mesmo conceito, não como conceitos obrigatórios independentes;
        - evite termos amplos demais, como management isolado;
        - priorize equivalentes em inglês quando a busca for acadêmica internacional;
        - mantenha no máximo 6 a 8 sinônimos relevantes por bloco.

        Campos query_semantic, query_scopus, query_wos, query_pubmed, query_openalex, query_crossref, query_europepmc e query_core:
        - podem trazer uma sugestão inicial em texto;
        - a sintaxe final será reescrita pelo Python a partir dos blocos, para preservar reprodutibilidade e compatibilidade com cada base.
        """
    ).strip()

    response = client.responses.parse(
        model=model,
        input=[{"role": "user", "content": prompt}],
        text_format=_SearchSuggestionOutput,
    )
    parsed = response.output_parsed
    if parsed is None:
        raise RuntimeError("A OpenAI não retornou sugestões estruturadas de palavras-chave.")
    parsed.palavras_chave = ensure_study_type_in_keywords(parsed.palavras_chave, tipo_estudo)
    if query_bilingue:
        parsed.palavras_chave = expand_bilingual_terms(parsed.palavras_chave, tema=tema, recorte=recorte, idiomas=idiomas, enabled=True)

    explicit_blocks = {
        "technology": list(parsed.bloco_tecnologia) + list(parsed.sinonimos_tecnologia),
        "context": list(parsed.bloco_contexto) + list(parsed.sinonimos_contexto),
        "analytic": list(parsed.bloco_dimensao_analitica) + list(parsed.sinonimos_dimensao_analitica),
        "study": list(parsed.bloco_tipo_estudo) + list(parsed.sinonimos_tipo_estudo),
        "exclude": parsed.termos_exclusao,
    }
    blocks = infer_search_blocks(
        tema,
        recorte,
        parsed.palavras_chave,
        tipo_estudo,
        idiomas=idiomas,
        query_bilingue=query_bilingue,
        explicit_blocks=explicit_blocks,
    )
    parsed.bloco_tecnologia, parsed.sinonimos_tecnologia = split_main_terms_and_synonyms(parsed.bloco_tecnologia, blocks["technology"])
    parsed.bloco_contexto, parsed.sinonimos_contexto = split_main_terms_and_synonyms(parsed.bloco_contexto, blocks["context"])
    parsed.bloco_dimensao_analitica, parsed.sinonimos_dimensao_analitica = split_main_terms_and_synonyms(parsed.bloco_dimensao_analitica, blocks["analytic"], main_limit=10, synonym_limit=12)
    parsed.bloco_tipo_estudo, parsed.sinonimos_tipo_estudo = split_main_terms_and_synonyms(parsed.bloco_tipo_estudo, blocks["study"], main_limit=8, synonym_limit=10)
    parsed.termos_exclusao = blocks["exclude"]

    # A IA sugere os blocos e sinônimos; o Python monta a sintaxe final de cada base.
    parsed.query_semantic = build_query_for_source("semantic_scholar", tema, parsed.palavras_chave, tipo_estudo, recorte=recorte, objetivo=objetivo, idiomas=idiomas, query_bilingue=query_bilingue, periodo=periodo, explicit_blocks=explicit_blocks)
    parsed.query_scopus = build_query_for_source("scopus", tema, parsed.palavras_chave, tipo_estudo, recorte=recorte, objetivo=objetivo, idiomas=idiomas, query_bilingue=query_bilingue, periodo=periodo, explicit_blocks=explicit_blocks)
    parsed.query_wos = build_query_for_source("web_of_science", tema, parsed.palavras_chave, tipo_estudo, recorte=recorte, objetivo=objetivo, idiomas=idiomas, query_bilingue=query_bilingue, periodo=periodo, explicit_blocks=explicit_blocks)
    parsed.query_pubmed = build_query_for_source("pubmed", tema, parsed.palavras_chave, tipo_estudo, recorte=recorte, objetivo=objetivo, idiomas=idiomas, query_bilingue=query_bilingue, periodo=periodo, explicit_blocks=explicit_blocks)
    parsed.query_openalex = build_query_for_source("openalex", tema, parsed.palavras_chave, tipo_estudo, recorte=recorte, objetivo=objetivo, idiomas=idiomas, query_bilingue=query_bilingue, periodo=periodo, explicit_blocks=explicit_blocks)
    parsed.query_crossref = build_query_for_source("crossref", tema, parsed.palavras_chave, tipo_estudo, recorte=recorte, objetivo=objetivo, idiomas=idiomas, query_bilingue=query_bilingue, periodo=periodo, explicit_blocks=explicit_blocks)
    parsed.query_europepmc = build_query_for_source("europe_pmc", tema, parsed.palavras_chave, tipo_estudo, recorte=recorte, objetivo=objetivo, idiomas=idiomas, query_bilingue=query_bilingue, periodo=periodo, explicit_blocks=explicit_blocks)
    parsed.query_core = build_query_for_source("core", tema, parsed.palavras_chave, tipo_estudo, recorte=recorte, objetivo=objetivo, idiomas=idiomas, query_bilingue=query_bilingue, periodo=periodo, explicit_blocks=explicit_blocks)
    return parsed


def _print_keyword_suggestions(s: SearchSuggestionOutput, bases: list[str]) -> None:
    print("\nSugestões da IA")
    print("-" * 72)
    print("Palavras-chave sugeridas:")
    print("  " + ", ".join(s.palavras_chave))
    if s.termos_relacionados:
        print("Termos relacionados:")
        print("  " + ", ".join(s.termos_relacionados))
    print("Blocos semânticos usados para montar as queries:")
    if s.bloco_tecnologia:
        print("  Tecnologia: " + ", ".join(s.bloco_tecnologia))
    if s.sinonimos_tecnologia:
        print("    Sinônimos: " + ", ".join(s.sinonimos_tecnologia))
    if s.bloco_contexto:
        print("  Contexto: " + ", ".join(s.bloco_contexto))
    if s.sinonimos_contexto:
        print("    Sinônimos: " + ", ".join(s.sinonimos_contexto))
    if s.bloco_dimensao_analitica:
        print("  Dimensão analítica: " + ", ".join(s.bloco_dimensao_analitica))
    if s.sinonimos_dimensao_analitica:
        print("    Sinônimos: " + ", ".join(s.sinonimos_dimensao_analitica))
    if s.bloco_tipo_estudo:
        print("  Tipo de estudo: " + ", ".join(s.bloco_tipo_estudo))
    if s.sinonimos_tipo_estudo:
        print("    Sinônimos: " + ", ".join(s.sinonimos_tipo_estudo))
    if s.termos_exclusao:
        print("  Exclusões: " + ", ".join(s.termos_exclusao))
    if "semantic_scholar" in bases:
        print("\nQuery sugerida para Semantic Scholar:")
        print(s.query_semantic)
    if "scopus" in bases:
        print("\nQuery sugerida para Scopus:")
        print(s.query_scopus)
    if "web_of_science" in bases:
        print("\nQuery sugerida para Web of Science:")
        print(s.query_wos)
    if "pubmed" in bases:
        print("\nQuery sugerida para PubMed:")
        print(s.query_pubmed)
    if "openalex" in bases:
        print("\nQuery sugerida para OpenAlex:")
        print(s.query_openalex)
    if "crossref" in bases:
        print("\nQuery sugerida para Crossref:")
        print(s.query_crossref)
    if "europe_pmc" in bases:
        print("\nQuery sugerida para Europe PMC:")
        print(s.query_europepmc)
    if "core" in bases:
        print("\nQuery sugerida para CORE:")
        print(s.query_core)
    if s.observacoes:
        print("\nObservações:")
        print(textwrap.fill(s.observacoes, width=88))
    print("-" * 72)


def suggest_empirical_keywords_with_openai(
    tema: str,
    recorte: str,
    objetivo: str,
    tipo_estudo: str,
    idiomas: list[str],
    model: str,
) -> EmpiricalKeywordSuggestionOutput:
    client = make_openai_client()

    class _EmpiricalKeywordSuggestionOutput(EmpiricalKeywordSuggestionOutput):
        pass

    prompt = textwrap.dedent(
        f"""
        Você é um assistente de metodologia de pesquisa empírica.
        A partir da tríade abaixo, sugira palavras-chave e conceitos centrais para orientar uma proposta de pesquisa.

        Tema central: {tema}
        Recorte específico: {recorte}
        Objetivo da atividade: {objetivo}
        Tipo de estudo empírico priorizado: {tipo_estudo}
        Idiomas aceitáveis: {', '.join(idiomas)}

        Regras:
        - sugira termos diretamente derivados da tríade tema-recorte-objetivo;
        - priorize conceitos analíticos e substantivos úteis para construir problema, hipótese e modelo teórico;
        - devolva entre 6 e 12 itens em palavras_chave;
        - devolva entre 4 e 10 itens em conceitos_centrais;
        - escreva principalmente em português; inclua equivalentes em inglês apenas quando isso ampliar a utilidade conceitual;
        - inclua explicitamente o descritor do tipo de estudo também no campo palavras_chave;
        - não explique demais: devolva apenas os campos estruturados.
        """
    ).strip()

    response = client.responses.parse(
        model=model,
        input=[{"role": "user", "content": prompt}],
        text_format=_EmpiricalKeywordSuggestionOutput,
    )
    parsed = response.output_parsed
    if parsed is None:
        raise RuntimeError("A OpenAI não retornou sugestões estruturadas de palavras-chave para o modo empírico.")
    palavras = ensure_study_type_in_keywords(parsed.palavras_chave, tipo_estudo)
    conceitos = [x.strip() for x in parsed.conceitos_centrais if x and x.strip()]
    merged = []
    seen = set()
    for item in palavras + conceitos:
        key = item.casefold()
        if key not in seen:
            seen.add(key)
            merged.append(item)
    parsed.palavras_chave = merged
    parsed.conceitos_centrais = conceitos
    return parsed




def _print_empirical_keyword_suggestions(s: EmpiricalKeywordSuggestionOutput) -> None:
    print("\nSugestões da IA")
    print("-" * 72)
    print("Palavras-chave sugeridas:")
    print("  " + ", ".join(s.palavras_chave))
    if s.conceitos_centrais:
        print("Conceitos centrais sugeridos:")
        print("  " + ", ".join(s.conceitos_centrais))
    if s.observacoes:
        print("\nObservações:")
        print(textwrap.fill(s.observacoes, width=88))
    print("-" * 72)


def configure_empirical_keywords(
    args: argparse.Namespace,
    *,
    interactive: bool,
    tema: str,
    recorte: str,
    objetivo: str,
    tipo_estudo: str,
    idiomas: list[str],
    model: str,
) -> list[str]:
    manual_csv = args.palavras_chave
    manual_words = [x.strip() for x in (manual_csv or "").split(",") if x.strip()]

    use_ai = bool(args.sugerir_palavras_chave_ia)
    if interactive:
        use_ai = prompt_yes_no(
            "Deseja que a IA sugira palavras-chave e conceitos centrais a partir do tema, recorte e objetivo?",
            default=not bool(manual_words),
        )

    suggestion = None
    if use_ai:
        if not ensure_openai_api_key(interactive):
            if interactive:
                print("Não foi possível obter a chave da OpenAI. Seguindo para preenchimento manual.")
            use_ai = False
        else:
            while True:
                try:
                    suggestion = suggest_empirical_keywords_with_openai(
                        tema=tema,
                        recorte=recorte,
                        objetivo=objetivo,
                        tipo_estudo=tipo_estudo,
                        idiomas=idiomas,
                        model=model,
                    )
                except Exception as exc:
                    if interactive:
                        print(f"Falha ao gerar sugestões com a IA: {exc}")
                        print("Seguindo para preenchimento manual.")
                        use_ai = False
                        break
                    raise

                if not interactive:
                    return suggestion.palavras_chave or manual_words or [tema]

                _print_empirical_keyword_suggestions(suggestion)
                choice = prompt_choice(
                    "Ação sobre as sugestões [a=aceitar, e=editar, r=regenerar, m=manual]",
                    {"a": "aceitar", "e": "editar", "r": "regenerar", "m": "manual"},
                    "a",
                )
                if choice == "r":
                    continue
                if choice == "m":
                    use_ai = False
                    break
                if choice == "a":
                    return suggestion.palavras_chave or manual_words or [tema]
                if choice == "e":
                    current_csv = ",".join(suggestion.palavras_chave)
                    return prompt_list(
                        "Palavras-chave e conceitos centrais (separados por vírgula)",
                        current_csv=current_csv,
                        force=True,
                    )

    palavras = prompt_list("Palavras-chave e conceitos centrais (separados por vírgula)", args.palavras_chave, force=interactive) if interactive else (manual_words or [tema])
    return ensure_study_type_in_keywords(palavras, tipo_estudo)


def configure_keywords_and_queries(
    args: argparse.Namespace,
    *,
    interactive: bool,
    tema: str,
    recorte: str,
    objetivo: str,
    bases: list[str],
    tipo_estudo: str,
    idiomas: list[str],
    model: str,
    query_bilingue: bool,
    periodo: str | None = None,
) -> tuple[list[str], str | None, str | None, str | None, str | None]:
    manual_csv = args.palavras_chave
    manual_words = [x.strip() for x in (manual_csv or "").split(",") if x.strip()]

    use_ai = bool(args.sugerir_palavras_chave_ia)
    if interactive:
        use_ai = prompt_yes_no(
            "Deseja que a IA sugira palavras-chave e queries por base a partir do tema, recorte e objetivo?",
            default=not bool(manual_words),
        )

    suggestion = None
    if use_ai:
        if not ensure_openai_api_key(interactive):
            if interactive:
                print("Não foi possível obter a chave da OpenAI. Seguindo para preenchimento manual.")
            use_ai = False
        else:
            while True:
                try:
                    suggestion = suggest_keywords_with_openai(
                        tema=tema,
                        recorte=recorte,
                        objetivo=objetivo,
                        tipo_estudo=tipo_estudo,
                        bases=bases,
                        idiomas=idiomas,
                        model=model,
                        query_bilingue=query_bilingue,
                        periodo=periodo,
                    )
                except Exception as exc:
                    if interactive:
                        print(f"Falha ao gerar sugestões com a IA: {exc}")
                        print("Seguindo para preenchimento manual.")
                        use_ai = False
                        break
                    raise

                if not interactive:
                    palavras = ensure_study_type_in_keywords(suggestion.palavras_chave or manual_words or [tema], tipo_estudo)
                    query_geral = args.query_geral
                    query_semantic = args.query_semantic or (suggestion.query_semantic if "semantic_scholar" in bases else None)
                    query_scopus = args.query_scopus or (suggestion.query_scopus if "scopus" in bases else None)
                    query_wos = args.query_wos or (suggestion.query_wos if "web_of_science" in bases else None)
                    return palavras, query_geral, query_semantic, query_scopus, query_wos

                _print_keyword_suggestions(suggestion, bases)
                choice = prompt_choice(
                    "Ação sobre as sugestões [a=aceitar, e=editar, r=regenerar, m=manual]",
                    {"a": "aceitar", "e": "editar", "r": "regenerar", "m": "manual"},
                    "a",
                )
                if choice == "r":
                    continue
                if choice == "m":
                    use_ai = False
                    break
                if choice == "a":
                    palavras = ensure_study_type_in_keywords(suggestion.palavras_chave or manual_words or [tema], tipo_estudo)
                    return (
                        palavras,
                        None,
                        suggestion.query_semantic if "semantic_scholar" in bases else None,
                        suggestion.query_scopus if "scopus" in bases else None,
                        suggestion.query_wos if "web_of_science" in bases else None,
                    )
                if choice == "e":
                    palavras = ensure_study_type_in_keywords(prompt_list(
                        "Palavras-chave finais (separadas por vírgula)",
                        current_csv=",".join(suggestion.palavras_chave),
                        force=True,
                    ), tipo_estudo)
                    query_geral = None
                    query_semantic = args.query_semantic
                    query_scopus = args.query_scopus
                    query_wos = args.query_wos
                    if "semantic_scholar" in bases:
                        query_semantic = prompt_text("Query para Semantic Scholar", suggestion.query_semantic, force=True)
                    if "scopus" in bases:
                        query_scopus = prompt_text("Query para Scopus", suggestion.query_scopus, force=True)
                    if "web_of_science" in bases:
                        query_wos = prompt_text("Query para Web of Science", suggestion.query_wos, force=True)
                    return palavras, query_geral, query_semantic, query_scopus, query_wos

    palavras = ensure_study_type_in_keywords(prompt_list("Palavras-chave iniciais (separadas por vírgula)", args.palavras_chave, force=interactive) if interactive else (manual_words or [tema]), tipo_estudo)
    palavras = expand_bilingual_terms(palavras, tema=tema, recorte=recorte, idiomas=idiomas, enabled=query_bilingue)

    if interactive:
        auto_query = prompt_yes_no("Gerar automaticamente as queries específicas por base a partir do tema, do tipo de estudo e das palavras-chave?", default=True)
        if auto_query:
            return palavras, None, args.query_semantic, args.query_scopus, args.query_wos
        query_geral = prompt_text("Query geral única (deixe vazia se quiser informar por base)", args.query_geral, default="", force=True) or None
        query_semantic = args.query_semantic
        query_scopus = args.query_scopus
        query_wos = args.query_wos
        if not query_geral:
            if "semantic_scholar" in bases:
                query_semantic = prompt_text("Query para Semantic Scholar", args.query_semantic, force=True)
            if "scopus" in bases:
                query_scopus = prompt_text("Query para Scopus", args.query_scopus, force=True)
            if "web_of_science" in bases:
                query_wos = prompt_text("Query para Web of Science", args.query_wos, force=True)
        return palavras, query_geral, query_semantic, query_scopus, query_wos

    return palavras, args.query_geral, args.query_semantic, args.query_scopus, args.query_wos


def build_config(args: argparse.Namespace) -> Config:
    args = maybe_load_initial_config(args)
    interactive = not args.nao_interativo
    config_loaded_raw = getattr(args, "config_loaded_path", None)
    config_loaded_path = Path(config_loaded_raw).expanduser().resolve() if config_loaded_raw else None

    if interactive:
        print("Qual tipo de atividade você deseja gerar?")
        print("  1. Revisão sistemática / PRISMA")
        print("  2. Pesquisa empírica")
        modo_choice = prompt_choice(
            "Escolha o modo",
            {"1": "revisao_sistematica", "2": "pesquisa_empirica"},
            "1" if (args.modo or DEFAULT_MODO) == "revisao_sistematica" else "2",
        )
        modo = "revisao_sistematica" if modo_choice == "1" else "pesquisa_empirica"
    else:
        modo = args.modo or DEFAULT_MODO

    tipo_estudo = prompt_tipo_estudo_por_modo(modo, args.tipo_estudo, force=interactive)

    curso = prompt_text("Curso/Programa", args.curso, force=interactive)
    if interactive:
        turma = prompt_text("Turma", args.turma, DEFAULT_TURMA, force=True)
        polo = prompt_text("Pólo", args.polo, DEFAULT_POLO, force=True)
        disciplina = prompt_text("Disciplina", args.disciplina, force=True)
        professor = prompt_text("Professor(a)", args.professor, force=True)
        aluno = prompt_text("Aluno(s)", args.aluno, force=True)
    else:
        turma = (args.turma or DEFAULT_TURMA).strip()
        polo = (args.polo or DEFAULT_POLO).strip()
        disciplina = (args.disciplina or "").strip()
        professor = (args.professor or "").strip()
        aluno = (args.aluno or "").strip()

    tema = prompt_text("Tema central", args.tema, force=interactive)
    recorte = prompt_text("Recorte específico", args.recorte, force=interactive)
    objetivo = prompt_text("Objetivo da atividade", args.objetivo, force=interactive)
    idiomas = prompt_list("Idiomas aceitáveis (separados por vírgula)", args.idiomas, DEFAULT_IDIOMAS, force=interactive)

    if modo == "revisao_sistematica":
        bases = prompt_sources(args.bases, force=interactive) if interactive else normalize_sources((args.bases or ",".join(DEFAULT_BASES)).split(","))
    else:
        bases = []

    if modo == "revisao_sistematica":
        estilo_citacao = prompt_citation_style(args.estilo_citacao, force=interactive)
    else:
        estilo_citacao = normalize_citation_style(args.estilo_citacao or DEFAULT_CITATION_STYLE)
    incluir_analise_detalhada_ia = False
    incluir_sintese_integradora_ia = False

    query_bilingue_default = languages_include_both_pt_en(idiomas)
    query_bilingue = prompt_yes_no("Deseja montar/sugerir queries bilíngues (português + inglês)?", default=query_bilingue_default) if (interactive and modo == "revisao_sistematica") else (query_bilingue_default if args.query_bilingue is None else bool(args.query_bilingue))
    periodo = prompt_text("Período desejado", args.periodo, DEFAULT_PERIODO, force=interactive) if modo == "revisao_sistematica" else ""
    trabalho = (args.trabalho or "").strip()
    model = prompt_text("Modelo OpenAI", args.model, DEFAULT_MODEL, force=interactive)

    if modo == "revisao_sistematica":
        palavras, query_geral, query_semantic, query_scopus, query_wos = configure_keywords_and_queries(
            args,
            interactive=interactive,
            tema=tema,
            recorte=recorte,
            objetivo=objetivo,
            bases=bases,
            tipo_estudo=tipo_estudo,
            idiomas=idiomas,
            model=model,
            query_bilingue=query_bilingue,
            periodo=periodo,
        )
        quantidade_triagem = prompt_int("Quantidade máxima de candidatos para triagem detalhada", args.quantidade_triagem, DEFAULT_TRIAGEM, force=interactive)
        quantidade_selecionados = prompt_int("Quantidade desejada de textos para seleção final", getattr(args, "quantidade_selecionados", None), DEFAULT_SELECIONADOS, force=interactive)
        if quantidade_selecionados < 1:
            quantidade_selecionados = 1
        if quantidade_selecionados > quantidade_triagem:
            quantidade_selecionados = quantidade_triagem
        triagem_rigor = prompt_triagem_rigor(getattr(args, "triagem_rigor", None), force=interactive)
        incluir_analise_detalhada_ia = (
            prompt_yes_no("Deseja incluir análise detalhada gerada pela IA para cada texto selecionado?", default=True)
            if interactive else
            (True if args.incluir_analise_detalhada_ia is None else bool(args.incluir_analise_detalhada_ia))
        )
        incluir_sintese_integradora_ia = (
            prompt_yes_no("Deseja incluir síntese integradora final gerada pela IA com base em todos os textos selecionados?", default=True)
            if interactive else
            (True if args.incluir_sintese_integradora_ia is None else bool(args.incluir_sintese_integradora_ia))
        )
        permitir_textos_nao_publicos = (
            prompt_yes_no(
                "Permitir uso de textos não públicos quando houver link do registro, mesmo sem download local do PDF?",
                default=False,
            )
            if interactive else bool(getattr(args, "permitir_textos_nao_publicos", False))
        )
    else:
        palavras = configure_empirical_keywords(
            args,
            interactive=interactive,
            tema=tema,
            recorte=recorte,
            objetivo=objetivo,
            tipo_estudo=tipo_estudo,
            idiomas=idiomas,
            model=model,
        )
        palavras = ensure_study_type_in_keywords(palavras, tipo_estudo)
        query_geral = None
        query_semantic = None
        query_scopus = None
        query_wos = None
        query_pubmed = None
        query_openalex = None
        query_crossref = None
        query_europepmc = None
        query_core = None
        quantidade_triagem = 0
        quantidade_selecionados = 0
        triagem_rigor = "moderado"
        permitir_textos_nao_publicos = False

    prefixo_default = slugify(f"atividade_{tema}_{'prisma' if modo == 'revisao_sistematica' else 'empirica'}")
    prefixo = prompt_text("Prefixo de arquivos", args.prefixo, prefixo_default, force=interactive)
    base_output_dir = Path(prompt_path("Diretório base de saída", args.output_dir, args.output_dir, force=interactive, only_directories=True)).expanduser().resolve()
    create_subdiretorio = prompt_yes_no("Criar um subdiretório com o prefixo dentro do diretório de saída?", default=True) if interactive else (True if args.create_subdiretorio is None else bool(args.create_subdiretorio))
    output_dir = (base_output_dir / prefixo) if create_subdiretorio else base_output_dir
    org_modelo = Path(prompt_path("Arquivo .org modelo", args.org_modelo, DEFAULT_ORG_MODEL_FILENAME, force=interactive, must_exist=False)).expanduser()
    if not org_modelo.is_absolute():
        org_modelo = (Path.cwd() / org_modelo).resolve()
    fgv_logo_path = Path(prompt_path("Caminho do logo da FGV para o cabeçalho", args.fgv_logo_path, DEFAULT_FGV_LOGO_PATH, force=interactive, must_exist=False, only_directories=False)).expanduser()
    if not fgv_logo_path.is_absolute():
        fgv_logo_path = (Path.cwd() / fgv_logo_path).resolve()

    saida_orientacoes_paths: list[Path] = []
    saida_orientacao_inline = (getattr(args, "saida_orientacao_inline", None) or "").strip() or None
    texto_orientacao_extra: str | None = None
    saida_orientacoes_raw = getattr(args, "saida_orientacoes_paths", None)

    if interactive and not saida_orientacoes_raw and not saida_orientacao_inline:
        if prompt_yes_no("Deseja indicar um ou mais arquivos de orientação geral para a etapa de pesquisa?", default=False):
            saida_orientacoes_raw = ",".join(prompt_list("Arquivos de orientação geral (separados por vírgula)", "", "", force=True))
        if prompt_yes_no("Deseja informar também um texto inline de orientação geral?", default=False):
            saida_orientacao_inline = _prompt_raw("Texto inline de orientação geral", None).strip() or None

    saida_orientacoes_paths, texto_orientacao_extra = _load_orientation_bundle(
        saida_orientacoes_raw,
        saida_orientacao_inline,
        config_path=config_loaded_path,
        max_chars_per_file=20000,
    )

    exportar_pdf = prompt_yes_no("Tentar exportar automaticamente o .org para PDF ao final?", default=True) if interactive else bool(args.exportar_pdf)
    org_latex_class_init: Path | None = None
    latex_extra_path: Path | None = None
    comando_exportacao_pdf: str | None = None
    if exportar_pdf:
        class_init_default = args.org_latex_class_init or DEFAULT_ORG_LATEX_CLASS_INIT
        latex_path_default = args.latex_extra_path or DEFAULT_LATEX_EXTRA_PATH
        comando_default = (args.comando_exportacao_pdf or DEFAULT_PDF_EXPORT_COMMAND).strip()
        if interactive:
            usar_class_init = prompt_yes_no("Usar o arquivo .el padrão que registra a classe LaTeX fgv-paper?", default=bool(class_init_default))
            if usar_class_init and class_init_default:
                org_latex_class_init = Path(class_init_default).expanduser().resolve()
            else:
                tmp = prompt_path("Informe outro arquivo .el de registro da classe LaTeX [opcional]", None, None, force=True, must_exist=False)
                if tmp:
                    org_latex_class_init = Path(tmp).expanduser().resolve()
            usar_latex_extra = prompt_yes_no("Usar o caminho LaTeX padrão para classes/pacotes?", default=bool(latex_path_default))
            if usar_latex_extra and latex_path_default:
                latex_extra_path = Path(latex_path_default).expanduser().resolve()
            else:
                tmp = prompt_path("Informe outro caminho extra de classes/pacotes LaTeX [opcional]", None, None, force=True, must_exist=False, only_directories=False)
                if tmp:
                    latex_extra_path = Path(tmp).expanduser().resolve()
            comando_raw = _prompt_raw(
                "Comando externo de exportação PDF [opcional; placeholders: {org}, {org_dir}, {org_stem}, {pdf}, {pdf_dir}, {class_init}, {latex_path}, {latex_dir}, {bib}]",
                comando_default or None,
            )
            comando_exportacao_pdf = (comando_raw or comando_default).strip() or None
        else:
            if class_init_default:
                org_latex_class_init = Path(class_init_default).expanduser().resolve()
            if latex_path_default:
                latex_extra_path = Path(latex_path_default).expanduser().resolve()
            comando_exportacao_pdf = comando_default or None
    salvar_busca_bruta_json = prompt_yes_no("Salvar a busca bruta de cada base em JSON?", default=True) if (interactive and modo == "revisao_sistematica") else bool(args.salvar_busca_bruta_json)
    gerar_env_example = prompt_yes_no("Gerar um arquivo .env.example no diretório de saída?", default=False) if interactive else bool(args.gerar_env_example)
    remover_auxiliares = prompt_yes_no(
        "Remover ao final os arquivos auxiliares (.aux, .log, .out, .tex, .toc, .fls, .fdb_latexmk, .bbl, .blg, .synctex.gz etc.), preservando apenas .org, .pdf, .svg e .json do trabalho atual?",
        default=True,
    ) if interactive else bool(args.remover_auxiliares)

    triagem_score_hibrido = True if modo != "revisao_sistematica" else (True if getattr(args, "triagem_score_hibrido", None) is None else bool(args.triagem_score_hibrido))
    if interactive and modo == "revisao_sistematica":
        triagem_score_hibrido = prompt_yes_no(
            "Usar score híbrido local para calibrar a triagem temática (tema, recorte, objetivo, tipo de estudo e acesso)?",
            default=triagem_score_hibrido,
        )

    triagem_orientacoes_paths: list[Path] = []
    triagem_orientacao_inline = (getattr(args, "triagem_orientacao_inline", None) or "").strip() or None
    triagem_orientacoes_raw = getattr(args, "triagem_orientacoes_paths", None)
    triagem_diretivas_extras: str | None = None

    if interactive and modo == "revisao_sistematica" and not triagem_orientacoes_raw and not triagem_orientacao_inline:
        if prompt_yes_no("Deseja indicar um ou mais arquivos com orientações específicas de triagem/ranking?", default=False):
            triagem_orientacoes_raw = ",".join(prompt_list("Arquivos de orientação da triagem (separados por vírgula)", "", "", force=True))
        if prompt_yes_no("Deseja informar também um texto inline de orientação da triagem?", default=False):
            triagem_orientacao_inline = _prompt_raw("Texto inline de orientação da triagem", None).strip() or None

    triagem_orientacoes_paths, triagem_diretivas_extras = _load_orientation_bundle(
        triagem_orientacoes_raw,
        triagem_orientacao_inline,
        config_path=config_loaded_path,
        max_chars_per_file=20000,
    )

    salvar_config = bool(getattr(args, "salvar_config", False))
    config_output_path: Path | None = Path(args.config_output).expanduser().resolve() if getattr(args, "config_output", None) else None
    if interactive and not config_loaded_path:
        salvar_config = prompt_yes_no("Deseja salvar estas respostas em um arquivo de configuração para uso futuro?", default=True)
        if salvar_config and config_output_path is None:
            default_config_path = output_dir / f"{prefixo}_config.toml"
            config_txt = prompt_path("Arquivo de configuração a salvar", str(default_config_path), str(default_config_path), force=True, must_exist=False)
            if config_txt:
                config_output_path = Path(config_txt).expanduser().resolve()
    elif salvar_config and config_output_path is None:
        config_output_path = output_dir / f"{prefixo}_config.toml"

    return Config(
        modo=modo,
        disciplina=disciplina,
        professor=professor,
        curso=curso,
        tema=tema,
        recorte=recorte,
        objetivo=objetivo,
        bases=bases,
        tipo_estudo=tipo_estudo,
        estilo_citacao=estilo_citacao,
        periodo=periodo,
        idiomas=idiomas,
        palavras_chave=palavras,
        query_bilingue=query_bilingue,
        aluno=aluno,
        turma=turma,
        polo=polo,
        trabalho=trabalho,
        titulo_trabalho=None,
        quantidade_triagem=quantidade_triagem,
        quantidade_selecionados=quantidade_selecionados,
        model=model,
        output_dir=output_dir,
        create_subdiretorio=create_subdiretorio,
        org_modelo=org_modelo,
        saida_orientacoes_paths=saida_orientacoes_paths,
        saida_orientacao_inline=saida_orientacao_inline,
        texto_orientacao_extra=texto_orientacao_extra,
        prefixo=prefixo,
        query_geral=query_geral,
        query_semantic=query_semantic,
        query_scopus=query_scopus,
        query_wos=query_wos,
        query_pubmed=(getattr(args, "query_pubmed", None) if modo == "revisao_sistematica" else None),
        query_openalex=(getattr(args, "query_openalex", None) if modo == "revisao_sistematica" else None),
        query_crossref=(getattr(args, "query_crossref", None) if modo == "revisao_sistematica" else None),
        query_europepmc=(getattr(args, "query_europepmc", None) if modo == "revisao_sistematica" else None),
        query_core=(getattr(args, "query_core", None) if modo == "revisao_sistematica" else None),
        nao_interativo=args.nao_interativo,
        exportar_pdf=exportar_pdf,
        salvar_busca_bruta_json=salvar_busca_bruta_json,
        gerar_env_example=gerar_env_example,
        remover_auxiliares=remover_auxiliares,
        incluir_analise_detalhada_ia=incluir_analise_detalhada_ia,
        incluir_sintese_integradora_ia=incluir_sintese_integradora_ia,
        org_latex_class_init=org_latex_class_init,
        latex_extra_path=latex_extra_path,
        comando_exportacao_pdf=comando_exportacao_pdf,
        fgv_logo_path=fgv_logo_path,
        triagem_rigor=triagem_rigor,
        triagem_score_hibrido=triagem_score_hibrido,
        triagem_orientacoes_paths=triagem_orientacoes_paths,
        triagem_orientacao_inline=triagem_orientacao_inline,
        triagem_diretivas_extras=triagem_diretivas_extras,
        permitir_textos_nao_publicos=permitir_textos_nao_publicos,
        config_path=config_loaded_path,
        salvar_config=salvar_config,
        config_output_path=config_output_path,
    )



def generate_work_title_with_openai(client: OpenAI, config: Config, model_org_text: str) -> str:
    class _WorkTitleOutput(WorkTitleOutput):
        pass

    orientacao_extra = f"\n\nOrientações complementares para o arquivo final:\n{config.texto_orientacao_extra[:6000]}" if config.texto_orientacao_extra else ""

    prompt = textwrap.dedent(
        f"""
        Gere um título acadêmico em português para uma atividade universitária.

        Dados da atividade:
        - Modo da atividade: {"revisão sistemática/PRISMA" if config.modo == "revisao_sistematica" else "pesquisa empírica"}
        - Tema central: {config.tema}
        - Recorte específico: {config.recorte}
        - Objetivo da atividade: {config.objetivo}
        - Tipo de estudo priorizado: {config.tipo_estudo}
        - Bases consultadas: {config.bases_label}
        {"- Estilo bibliográfico escolhido: " + config.estilo_citacao if config.modo == "revisao_sistematica" else ""}

        Regras:
        - título claro, acadêmico e objetivo;
        - entre 8 e 20 palavras, preferencialmente;
        - evitar dois pontos desnecessários ou excesso de adjetivos;
        - refletir o tema, o recorte e o objetivo;
        - não mencionar PRISMA 2020 no título, a menos que seja realmente necessário;
        - produzir apenas um título final em português.
        {orientacao_extra}

        Modelo Org de referência (somente para inferir tom acadêmico):
        {model_org_text[:5000]}
        """
    ).strip()

    response = client.responses.parse(
        model=config.model,
        input=[{"role": "user", "content": prompt}],
        text_format=_WorkTitleOutput,
    )
    parsed = response.output_parsed
    if parsed is None or not parsed.titulo_trabalho.strip():
        return ensure_title_mentions_study_type(fallback_work_title(config), config)
    return ensure_title_mentions_study_type(parsed.titulo_trabalho.strip(), config)



def suggest_and_confirm_work_title(client: OpenAI | None, config: Config, model_org_text: str, interactive: bool) -> str:
    def _generate_once() -> str:
        if (config.trabalho or "").strip():
            return config.trabalho.strip()
        if client is None:
            return fallback_work_title(config)
        try:
            return generate_work_title_with_openai(client, config, model_org_text)
        except Exception:
            return fallback_work_title(config)

    title = _generate_once()
    if not interactive:
        return ensure_title_mentions_study_type(title, config)

    while True:
        print("\nTítulo sugerido para o trabalho:")
        print(title)
        choice = prompt_choice(
            "Ação sobre o título [a=aceitar, e=editar, r=regenerar, m=manual]",
            {"a": "aceitar", "e": "editar", "r": "regenerar", "m": "manual"},
            "a",
        )
        if choice == "a":
            return ensure_title_mentions_study_type(title, config)
        if choice == "e":
            return prompt_text("Título do trabalho", title, force=True)
        if choice == "m":
            return prompt_text("Título do trabalho", None, default=title, force=True)
        if choice == "r":
            # Se houve título passado por flag, regenerar passa a usar a IA.
            config.trabalho = ""
            title = _generate_once()


def load_model_org_text(path: Path) -> str:
    if path.exists():
        return read_text(path)
    return (
        "#+LANGUAGE: pt_BR\n"
        "#+OPTIONS: toc:nil num:t title:nil html-postamble:nil ^:{}\n"
        "#+STARTUP: indent\n"
        "#+LATEX_COMPILER: lualatex\n"
        "#+LATEX_CLASS: fgv-paper\n"
        "#+LATEX_CLASS_OPTIONS: [12pt,a4paper]\n"
        "#+LATEX_HEADER: \\usepackage{fgv-header}\n"
        "#+LATEX_HEADER: \\usepackage{float}\n"
        "#+LATEX_HEADER: \\usepackage{svg}\n"
    )


def make_openai_client() -> OpenAI:
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError("OPENAI_API_KEY não encontrado no ambiente.")
    return OpenAI(api_key=api_key)


def prompt_secret_if_missing(env_name: str, label: str, required: bool, interactive: bool) -> str | None:
    current = os.getenv(env_name)
    if current:
        return current
    if not interactive:
        return None
    if required:
        raw = _prompt_raw(f"{label} (não será salvo; deixe vazio para ignorar a base)", None, password=True)
        if raw:
            os.environ[env_name] = raw
            return raw
        return None
    raw = _prompt_raw(f"{label} (opcional; Enter para pular)", None, password=True)
    if raw:
        os.environ[env_name] = raw
        return raw
    return None


def semantic_scholar_headers(api_key: str | None) -> dict[str, str]:
    headers = {"User-Agent": "atividade-prisma-script/3.8.17"}
    if api_key:
        headers["x-api-key"] = api_key
    return headers


def _semantic_scholar_min_interval_seconds() -> float:
    raw = os.getenv("SEMANTIC_SCHOLAR_MIN_INTERVAL_SECONDS", "").strip()
    if not raw:
        return SEMANTIC_SCHOLAR_DEFAULT_MIN_INTERVAL_SECONDS
    try:
        return max(0.0, float(raw.replace(",", ".")))
    except ValueError:
        return SEMANTIC_SCHOLAR_DEFAULT_MIN_INTERVAL_SECONDS


def _semantic_scholar_max_retries() -> int:
    raw = os.getenv("SEMANTIC_SCHOLAR_MAX_RETRIES", "").strip()
    if not raw:
        return SEMANTIC_SCHOLAR_DEFAULT_MAX_RETRIES
    try:
        return max(0, int(raw))
    except ValueError:
        return SEMANTIC_SCHOLAR_DEFAULT_MAX_RETRIES


def _parse_retry_after_seconds(value: str | None) -> float | None:
    if not value:
        return None
    value = value.strip()
    if not value:
        return None
    try:
        return max(0.0, float(value))
    except ValueError:
        return None


def _semantic_scholar_wait_before_request() -> None:
    global _SEMANTIC_SCHOLAR_LAST_REQUEST_MONOTONIC
    min_interval = _semantic_scholar_min_interval_seconds()
    if min_interval <= 0:
        _SEMANTIC_SCHOLAR_LAST_REQUEST_MONOTONIC = time.monotonic()
        return
    now = time.monotonic()
    elapsed = now - _SEMANTIC_SCHOLAR_LAST_REQUEST_MONOTONIC
    if elapsed < min_interval:
        time.sleep(min_interval - elapsed)
    _SEMANTIC_SCHOLAR_LAST_REQUEST_MONOTONIC = time.monotonic()


def semantic_scholar_get_json(
    url: str,
    *,
    params: dict[str, str],
    api_key: str | None,
    timeout: int = 60,
    endpoint_label: str = "Semantic Scholar",
) -> dict:
    """Executa GET na API do Semantic Scholar respeitando rate limit e Retry-After."""
    max_retries = _semantic_scholar_max_retries()
    last_response: requests.Response | None = None
    for attempt in range(max_retries + 1):
        _semantic_scholar_wait_before_request()
        resp = requests.get(url, params=params, headers=semantic_scholar_headers(api_key), timeout=timeout)
        last_response = resp
        if resp.status_code != 429:
            resp.raise_for_status()
            return resp.json()

        retry_after = _parse_retry_after_seconds(resp.headers.get("Retry-After"))
        if attempt >= max_retries:
            resp.raise_for_status()
        wait_seconds = retry_after if retry_after is not None else min(60.0, 5.0 * (2 ** attempt))
        logging.warning(
            "%s retornou HTTP 429; aguardando %.1fs antes de nova tentativa (%s/%s).",
            endpoint_label,
            wait_seconds,
            attempt + 1,
            max_retries,
        )
        time.sleep(wait_seconds)

    if last_response is not None:
        last_response.raise_for_status()
    raise RuntimeError(f"{endpoint_label} não retornou resposta válida.")


def is_semantic_scholar_rate_limit_error(exc: BaseException) -> bool:
    response = getattr(exc, "response", None)
    return isinstance(response, requests.Response) and response.status_code == 429


def scopus_headers(api_key: str, insttoken: str | None = None) -> dict[str, str]:
    headers = {
        "Accept": "application/json",
        "X-ELS-APIKey": api_key,
        "User-Agent": "atividade-prisma-script/3.4",
    }
    if insttoken:
        headers["X-ELS-Insttoken"] = insttoken
    return headers


def wos_headers(api_key: str) -> dict[str, str]:
    return {
        "Accept": "application/json",
        "X-ApiKey": api_key,
        "User-Agent": "atividade-prisma-script/3.4",
    }


def first_nonempty(*values):
    for value in values:
        if isinstance(value, str) and value.strip():
            return value.strip()
        if value not in (None, "", [], {}):
            return value
    return None


def nested_get(data, *keys):
    cur = data
    for key in keys:
        if isinstance(cur, list):
            if not isinstance(key, int) or key >= len(cur):
                return None
            cur = cur[key]
        elif isinstance(cur, dict):
            if key not in cur:
                return None
            cur = cur[key]
        else:
            return None
    return cur


def year_from_text(text: str | None) -> int | None:
    if not text:
        return None
    m = re.search(r"(19|20)\d{2}", str(text))
    return int(m.group(0)) if m else None


def author_list_from_semantic(item: dict) -> list[str]:
    return [a.get("name", "").strip() for a in item.get("authors", []) if a.get("name")]


def author_list_from_scopus(item: dict) -> list[str]:
    creators = []
    creator = item.get("dc:creator")
    if isinstance(creator, str) and creator.strip():
        creators.append(creator.strip())
    authors = item.get("author")
    if isinstance(authors, list):
        for a in authors:
            name = first_nonempty(a.get("authname"), a.get("ce:indexed-name"), a.get("ce:surname"))
            if isinstance(name, str) and name.strip() and name.strip() not in creators:
                creators.append(name.strip())
    return creators


def author_list_from_wos(item: dict) -> list[str]:
    names = []
    candidates = nested_get(item, "names", "authors")
    if isinstance(candidates, list):
        for a in candidates:
            name = first_nonempty(a.get("displayName"), a.get("fullName"), a.get("wosStandard"), a.get("name"))
            if isinstance(name, str) and name.strip():
                names.append(name.strip())
    elif isinstance(candidates, dict):
        for key in ("displayName", "fullName", "wosStandard", "name"):
            if candidates.get(key):
                names.append(str(candidates[key]).strip())
                break
    return names


def merge_candidate(into: CandidatePaper, other: CandidatePaper) -> CandidatePaper:
    if not into.abstract and other.abstract:
        into.abstract = other.abstract
    if not into.year and other.year:
        into.year = other.year
    if not into.venue and other.venue:
        into.venue = other.venue
    if not into.publication_date and other.publication_date:
        into.publication_date = other.publication_date
    if not into.authors and other.authors:
        into.authors = other.authors
    if not into.tldr and other.tldr:
        into.tldr = other.tldr
    if not into.url and other.url:
        into.url = other.url
    if not into.pdf_url and other.pdf_url:
        into.pdf_url = other.pdf_url
    if not into.doi and other.doi:
        into.doi = other.doi
    if not into.document_type and other.document_type:
        into.document_type = other.document_type
    if not into.full_text_verified and other.full_text_verified:
        into.full_text_verified = other.full_text_verified
        into.full_text_source = other.full_text_source
        into.full_text_note = other.full_text_note
    elif not into.full_text_note and other.full_text_note:
        into.full_text_note = other.full_text_note
    for src in other.sources:
        if src not in into.sources:
            into.sources.append(src)
    into.source_ids.update(other.source_ids)
    return into


def dedupe_candidates(raw_items: Iterable[CandidatePaper]) -> tuple[list[CandidatePaper], int]:
    seen: dict[tuple[str, str], CandidatePaper] = {}
    duplicates_removed = 0
    for item in raw_items:
        title_key = re.sub(r"\s+", " ", item.title.lower()).strip()
        doi_key = (item.doi or "").lower().strip()
        key = (doi_key, title_key)
        if key in seen:
            duplicates_removed += 1
            merge_candidate(seen[key], item)
            continue
        seen[key] = item
    return list(seen.values()), duplicates_removed


def semantic_publication_types_for_study(tipo_estudo: str) -> str | None:
    if is_review_like_type(tipo_estudo):
        return "Review"
    return None


def _semantic_year_param(periodo: str | None) -> str | None:
    years = parse_periodo_year_range(periodo)
    if not years:
        return None
    return f"{years[0]}-{years[1]}"


def _semantic_candidate_from_item(item: dict) -> CandidatePaper | None:
    tldr = item.get("tldr") or {}
    ext = item.get("externalIds") or {}
    open_pdf = item.get("openAccessPdf") or {}
    paper_id = (item.get("paperId") or "").strip()
    if not paper_id:
        return None
    publication_types = item.get("publicationTypes") or []
    document_type = ", ".join(str(x) for x in publication_types if x) or None
    return CandidatePaper(
        paper_id=f"semantic_scholar:{paper_id}",
        title=(item.get("title") or "Sem título").strip(),
        abstract=(item.get("abstract") or "").strip(),
        year=item.get("year"),
        venue=(item.get("venue") or "").strip() or None,
        publication_date=(item.get("publicationDate") or "").strip() or None,
        authors=author_list_from_semantic(item),
        tldr=(tldr.get("text") or "").strip() or None,
        url=(item.get("url") or "").strip() or None,
        pdf_url=(open_pdf.get("url") or "").strip() or None,
        doi=(ext.get("DOI") or "").strip() or None,
        document_type=document_type,
        sources=["semantic_scholar"],
        source_ids={"semantic_scholar": paper_id},
    )


def fetch_semantic_scholar_candidates(query: str, limit: int, api_key: str | None, periodo: str | None = None, tipo_estudo: str = "") -> SourceFetchResult:
    fields = ",".join([
        "paperId",
        "title",
        "abstract",
        "year",
        "venue",
        "publicationDate",
        "authors",
        "url",
        "externalIds",
        "tldr",
        "openAccessPdf",
        "publicationTypes",
        "citationCount",
    ])
    warnings: list[str] = []
    raw_payloads: list[dict] = []
    effective_query = query

    def _run_bulk(search_query: str) -> tuple[dict, list[dict]]:
        params = {"query": search_query, "limit": str(max(1, limit)), "fields": fields, "openAccessPdf": "true"}
        year_param = _semantic_year_param(periodo)
        if year_param:
            params["year"] = year_param
        publication_types = semantic_publication_types_for_study(tipo_estudo)
        if publication_types:
            params["publicationTypes"] = publication_types
        payload = semantic_scholar_get_json(
            S2_BULK_SEARCH_URL,
            params=params,
            api_key=api_key,
            timeout=60,
            endpoint_label="Semantic Scholar bulk search",
        )
        return payload, payload.get("data", []) or []

    def _run_standard(search_query: str) -> tuple[dict, list[dict]]:
        params = {"query": simplify_semantic_scholar_query(search_query), "limit": str(limit), "fields": fields}
        payload = semantic_scholar_get_json(
            S2_SEARCH_URL,
            params=params,
            api_key=api_key,
            timeout=60,
            endpoint_label="Semantic Scholar busca padrão",
        )
        return payload, payload.get("data", []) or []

    data: list[dict] = []
    skip_standard_fallback = False
    try:
        payload, data = _run_bulk(query)
        raw_payloads.append(payload)
        effective_query = query
    except requests.HTTPError as exc:
        if is_semantic_scholar_rate_limit_error(exc):
            warnings.append(
                "Semantic Scholar bulk search atingiu limite de requisições (HTTP 429) "
                "mesmo após retry/backoff; fallback padrão não será chamado imediatamente para evitar novo bloqueio."
            )
            skip_standard_fallback = True
        else:
            body = getattr(getattr(exc, "response", None), "text", "")
            detail = f" | resposta: {body[:500]}" if body else ""
            warnings.append(f"Semantic Scholar bulk search falhou ({exc}{detail}); usando busca padrão simplificada.")
    except Exception as exc:
        warnings.append(f"Semantic Scholar bulk search falhou ({exc}); usando busca padrão simplificada.")

    if not data and not skip_standard_fallback:
        # Fallback em cascata: o Semantic Scholar costuma responder melhor a consultas
        # curtas, naturais e em inglês. Mantemos o mesmo foco temático, mas tentamos
        # versões progressivamente mais enxutas antes de desistir da base.
        cascade_queries = []
        relaxed_query = simplify_semantic_scholar_query(strip_semantic_negative_terms(query))
        if relaxed_query:
            cascade_queries.append(relaxed_query)
        cascade_queries.extend(build_semantic_fallback_queries(query))

        seen_queries: set[str] = set()
        for fallback_query in cascade_queries:
            fallback_query = fallback_query.strip()
            if not fallback_query or fallback_query in seen_queries:
                continue
            seen_queries.add(fallback_query)
            try:
                payload2, data2 = _run_standard(fallback_query)
                raw_payloads.append(payload2)
                if data2:
                    data = data2
                    effective_query = fallback_query
                    break
            except requests.HTTPError as exc:
                if is_semantic_scholar_rate_limit_error(exc):
                    warnings.append(
                        "Semantic Scholar busca padrão atingiu limite de requisições (HTTP 429) "
                        "mesmo após retry/backoff; a base foi ignorada nesta execução."
                    )
                    break
                warnings.append(f"Semantic Scholar busca padrão falhou para '{fallback_query}': {exc}")
            except Exception as exc:
                warnings.append(f"Semantic Scholar busca padrão falhou para '{fallback_query}': {exc}")

    papers: list[CandidatePaper] = []
    for item in data:
        cand = _semantic_candidate_from_item(item)
        if cand:
            papers.append(cand)
    if not papers:
        warnings.append("Semantic Scholar não retornou resultados para a query informada.")
    return SourceFetchResult(source="semantic_scholar", query=effective_query, retrieved=len(papers), candidates=papers, warnings=warnings, raw_payloads=raw_payloads)



def _xml_text(elem) -> str:
    if elem is None:
        return ""
    return re.sub(r"\s+", " ", "".join(elem.itertext())).strip()


def author_list_from_pubmed(article) -> list[str]:
    authors: list[str] = []
    for author in article.findall(".//AuthorList/Author"):
        collective = _xml_text(author.find("CollectiveName"))
        if collective:
            authors.append(collective)
            continue
        last = _xml_text(author.find("LastName"))
        fore = _xml_text(author.find("ForeName")) or _xml_text(author.find("Initials"))
        name = " ".join(x for x in [fore, last] if x).strip()
        if name:
            authors.append(name)
    return authors


def _pubmed_article_id(article, id_type: str) -> str | None:
    for item in article.findall(".//PubmedData/ArticleIdList/ArticleId"):
        if (item.attrib.get("IdType") or "").lower() == id_type.lower():
            value = _xml_text(item)
            if value:
                return value
    return None


def _pubmed_publication_types(article) -> str | None:
    values = [_xml_text(x) for x in article.findall(".//PublicationTypeList/PublicationType")]
    values = [v for v in values if v]
    return "; ".join(values) if values else None


def _pubmed_pubdate(article) -> tuple[str | None, int | None]:
    pubdate = article.find(".//JournalIssue/PubDate")
    if pubdate is None:
        return None, None
    parts = [_xml_text(pubdate.find(tag)) for tag in ["Year", "Month", "Day"]]
    medline = _xml_text(pubdate.find("MedlineDate"))
    text = "-".join([p for p in parts if p]) or medline or None
    return text, year_from_text(text)


def _pubmed_abstract(article) -> str:
    chunks = []
    for abs_text in article.findall(".//Article/Abstract/AbstractText"):
        label = abs_text.attrib.get("Label") or abs_text.attrib.get("NlmCategory") or ""
        text = _xml_text(abs_text)
        if not text:
            continue
        chunks.append(f"{label}: {text}" if label else text)
    return "\n".join(chunks).strip()


def fetch_pubmed_candidates(query: str, limit: int, api_key: str | None = None, email: str | None = None) -> SourceFetchResult:
    warnings: list[str] = []
    raw_payloads: list[dict] = []
    params = {
        "db": "pubmed",
        "term": query,
        "retmode": "json",
        "retmax": str(max(1, limit)),
        "sort": "relevance",
    }
    if api_key:
        params["api_key"] = api_key
    if email:
        params["email"] = email
    resp = requests.get(PUBMED_ESEARCH_URL, params=params, timeout=60)
    resp.raise_for_status()
    payload = resp.json()
    raw_payloads.append(payload)
    ids = (payload.get("esearchresult") or {}).get("idlist") or []
    if not ids:
        warnings.append("PubMed não retornou resultados para a query informada.")
        return SourceFetchResult(source="pubmed", query=query, retrieved=0, candidates=[], warnings=warnings, raw_payloads=raw_payloads)

    fetch_params = {
        "db": "pubmed",
        "id": ",".join(ids[:limit]),
        "retmode": "xml",
    }
    if api_key:
        fetch_params["api_key"] = api_key
    if email:
        fetch_params["email"] = email
    fetch_resp = requests.get(PUBMED_EFETCH_URL, params=fetch_params, timeout=60)
    fetch_resp.raise_for_status()
    xml_text = fetch_resp.text
    raw_payloads.append({"efetch_xml_chars": len(xml_text), "ids": ids[:limit]})
    root = ET.fromstring(xml_text)
    candidates: list[CandidatePaper] = []
    for article in root.findall(".//PubmedArticle"):
        pmid = _xml_text(article.find(".//MedlineCitation/PMID"))
        if not pmid:
            continue
        title = _xml_text(article.find(".//Article/ArticleTitle")) or "Sem título"
        publication_date, year = _pubmed_pubdate(article)
        journal = _xml_text(article.find(".//Journal/Title")) or _xml_text(article.find(".//MedlineCitation/MedlineJournalInfo/MedlineTA")) or None
        doi = _pubmed_article_id(article, "doi")
        pmcid = _pubmed_article_id(article, "pmc")
        pdf_url = None
        if pmcid:
            pdf_url = f"https://pmc.ncbi.nlm.nih.gov/articles/{pmcid}/pdf/"
        candidates.append(CandidatePaper(
            paper_id=f"pubmed:{pmid}",
            title=title,
            abstract=_pubmed_abstract(article),
            year=year,
            venue=journal,
            publication_date=publication_date,
            authors=author_list_from_pubmed(article),
            tldr=None,
            url=f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/",
            pdf_url=pdf_url,
            doi=doi,
            document_type=_pubmed_publication_types(article),
            language=_xml_text(article.find(".//Article/Language")) or None,
            sources=["pubmed"],
            source_ids={"pubmed": pmid, **({"pmc": pmcid} if pmcid else {})},
        ))
    if not candidates:
        warnings.append("PubMed retornou IDs, mas nenhum registro pôde ser parseado no EFetch.")
    return SourceFetchResult(source="pubmed", query=query, retrieved=len(candidates), candidates=candidates, warnings=warnings, raw_payloads=raw_payloads)


def _openalex_abstract(inv) -> str:
    if not isinstance(inv, dict):
        return ""
    positions: list[tuple[int, str]] = []
    for word, idxs in inv.items():
        if isinstance(idxs, list):
            for idx in idxs:
                if isinstance(idx, int):
                    positions.append((idx, str(word)))
    if not positions:
        return ""
    return " ".join(word for _, word in sorted(positions))


def _openalex_authors(item: dict) -> list[str]:
    authors: list[str] = []
    for auth in item.get("authorships") or []:
        if isinstance(auth, dict):
            author = auth.get("author") or {}
            name = author.get("display_name")
            if name:
                authors.append(str(name))
    return authors


def _openalex_pdf_url(item: dict) -> str | None:
    links: list[str] = []
    oa = item.get("open_access") or {}
    if oa.get("oa_url"):
        links.append(str(oa["oa_url"]))
    for loc_key in ("best_oa_location", "primary_location"):
        loc = item.get(loc_key) or {}
        if isinstance(loc, dict):
            for key in ("pdf_url", "landing_page_url"):
                if loc.get(key):
                    links.append(str(loc[key]))
    for loc in item.get("locations") or []:
        if isinstance(loc, dict):
            for key in ("pdf_url", "landing_page_url"):
                if loc.get(key):
                    links.append(str(loc[key]))
    for link in _dedupe_links(links):
        if str(link).lower().endswith(".pdf") or "/pdf" in str(link).lower():
            return link
    return links[0] if links else None


def fetch_openalex_candidates(query: str, limit: int, periodo: str | None = None, idiomas: list[str] | None = None, api_key: str | None = None, email: str | None = None) -> SourceFetchResult:
    warnings: list[str] = []
    raw_payloads: list[dict] = []
    params = {
        "search": query,
        "per_page": str(min(max(1, limit), 100)),
        "sort": "relevance_score:desc",
        "select": "id,doi,display_name,abstract_inverted_index,publication_year,publication_date,primary_location,locations,open_access,type,language,authorships",
    }
    filters: list[str] = []
    years = parse_periodo_year_range(periodo)
    if years:
        start, end = years
        filters.extend([f"from_publication_date:{start}-01-01", f"to_publication_date:{end}-12-31"])
    if filters:
        params["filter"] = ",".join(filters)
    if email:
        params["mailto"] = email
    if api_key:
        params["api_key"] = api_key
    headers = dict(REQUEST_HEADERS)
    resp = requests.get(OPENALEX_WORKS_URL, params=params, headers=headers, timeout=60)
    resp.raise_for_status()
    payload = resp.json()
    raw_payloads.append(payload)
    results = payload.get("results") or []
    candidates: list[CandidatePaper] = []
    for item in results[:limit]:
        if not isinstance(item, dict):
            continue
        oid = str(item.get("id") or item.get("doi") or item.get("display_name") or len(candidates))
        doi = normalize_doi(item.get("doi"))
        title = str(item.get("display_name") or item.get("title") or "Sem título").strip()
        source = ((item.get("primary_location") or {}).get("source") or {}) if isinstance(item.get("primary_location"), dict) else {}
        venue = source.get("display_name") if isinstance(source, dict) else None
        pdf_url = _openalex_pdf_url(item)
        candidates.append(CandidatePaper(
            paper_id=f"openalex:{oid.rsplit('/', 1)[-1]}",
            title=title,
            abstract=_openalex_abstract(item.get("abstract_inverted_index")),
            year=item.get("publication_year"),
            venue=str(venue).strip() if venue else None,
            publication_date=str(item.get("publication_date") or "").strip() or None,
            authors=_openalex_authors(item),
            tldr=None,
            url=str(item.get("id") or "").strip() or None,
            pdf_url=pdf_url,
            doi=doi,
            document_type=str(item.get("type") or "").strip() or None,
            language=normalize_language_name(item.get("language")),
            sources=["openalex"],
            source_ids={"openalex": oid},
        ))
    if not candidates:
        warnings.append("OpenAlex não retornou resultados para a query informada.")
    return SourceFetchResult(source="openalex", query=query, retrieved=len(candidates), candidates=candidates, warnings=warnings, raw_payloads=raw_payloads)

def _crossref_authors(item: dict) -> list[str]:
    authors: list[str] = []
    for a in item.get("author") or []:
        if not isinstance(a, dict):
            continue
        name = " ".join(str(x).strip() for x in [a.get("given"), a.get("family")] if x).strip()
        if name:
            authors.append(name)
    return authors


def _crossref_year(item: dict) -> int | None:
    for key in ("published-print", "published-online", "published", "issued", "created"):
        parts = nested_get(item, key, "date-parts", 0)
        if isinstance(parts, list) and parts:
            try:
                return int(parts[0])
            except Exception:
                pass
    return None


def _crossref_date(item: dict) -> str | None:
    for key in ("published-print", "published-online", "published", "issued"):
        parts = nested_get(item, key, "date-parts", 0)
        if isinstance(parts, list) and parts:
            return "-".join(str(x) for x in parts if x)
    return None


def _crossref_pdf_url(item: dict) -> str | None:
    for link in item.get("link") or []:
        if not isinstance(link, dict):
            continue
        url = link.get("URL") or link.get("url")
        ctype = str(link.get("content-type") or "").lower()
        if url and ("pdf" in ctype or str(url).lower().endswith(".pdf") or "/pdf" in str(url).lower()):
            return str(url)
    return None


def fetch_crossref_candidates(query: str, limit: int, periodo: str | None = None, idiomas: list[str] | None = None, email: str | None = None) -> SourceFetchResult:
    warnings: list[str] = []
    raw_payloads: list[dict] = []
    params = {
        "query.bibliographic": query,
        "rows": str(min(max(1, limit), 100)),
        "sort": "relevance",
        "order": "desc",
    }
    filters: list[str] = []
    years = parse_periodo_year_range(periodo)
    if years:
        start, end = years
        filters.extend([f"from-pub-date:{start}-01-01", f"until-pub-date:{end}-12-31"])
    if filters:
        params["filter"] = ",".join(filters)
    if email:
        params["mailto"] = email
    headers = dict(REQUEST_HEADERS)
    if email:
        headers["User-Agent"] = f"atividade-prisma-script/3.8.67 (mailto:{email})"
    resp = requests.get(CROSSREF_WORKS_URL, params=params, headers=headers, timeout=60)
    resp.raise_for_status()
    payload = resp.json()
    raw_payloads.append(payload)
    items = (payload.get("message") or {}).get("items") or []
    candidates: list[CandidatePaper] = []
    for item in items[:limit]:
        if not isinstance(item, dict):
            continue
        title_list = item.get("title") or []
        title = str(title_list[0] if title_list else item.get("DOI") or "Sem título").strip()
        container = item.get("container-title") or []
        doi = normalize_doi(item.get("DOI"))
        candidates.append(CandidatePaper(
            paper_id=f"crossref:{doi or hashlib.sha1(title.encode('utf-8')).hexdigest()[:12]}",
            title=title,
            abstract=re.sub(r"<[^>]+>", " ", str(item.get("abstract") or "")).strip(),
            year=_crossref_year(item),
            venue=str(container[0]).strip() if container else None,
            publication_date=_crossref_date(item),
            authors=_crossref_authors(item),
            tldr=None,
            url=str(item.get("URL") or "").strip() or doi_to_url(doi),
            pdf_url=_crossref_pdf_url(item),
            doi=doi,
            document_type=str(item.get("type") or "").strip() or None,
            language=normalize_language_name(item.get("language")),
            sources=["crossref"],
            source_ids={"crossref": doi or title},
        ))
    if not candidates:
        warnings.append("Crossref não retornou resultados para a query informada.")
    return SourceFetchResult(source="crossref", query=query, retrieved=len(candidates), candidates=candidates, warnings=warnings, raw_payloads=raw_payloads)


def _europepmc_authors(item: dict) -> list[str]:
    author_string = item.get("authorString") or ""
    if author_string:
        return [x.strip().strip('.') for x in re.split(r",|;", author_string) if x.strip()][:20]
    return []


def _europepmc_pdf_url(item: dict) -> str | None:
    urls: list[str] = []
    ft_list = item.get("fullTextUrlList") or {}
    for entry in ft_list.get("fullTextUrl") or []:
        if isinstance(entry, dict):
            url = entry.get("url")
            doc_style = str(entry.get("documentStyle") or entry.get("availability") or "").lower()
            if url:
                if "pdf" in doc_style or str(url).lower().endswith(".pdf") or "/pdf" in str(url).lower():
                    return str(url)
                urls.append(str(url))
    return urls[0] if urls else None


def fetch_europepmc_candidates(query: str, limit: int, email: str | None = None) -> SourceFetchResult:
    warnings: list[str] = []
    raw_payloads: list[dict] = []
    params = {
        "query": query,
        "format": "json",
        "pageSize": str(min(max(1, limit), 100)),
        "resultType": "core",
    }
    headers = dict(REQUEST_HEADERS)
    if email:
        headers["User-Agent"] = f"atividade-prisma-script/3.8.67 (mailto:{email})"
    resp = requests.get(EUROPEPMC_SEARCH_URL, params=params, headers=headers, timeout=60)
    resp.raise_for_status()
    payload = resp.json()
    raw_payloads.append(payload)
    results = ((payload.get("resultList") or {}).get("result") or [])
    candidates: list[CandidatePaper] = []
    for item in results[:limit]:
        if not isinstance(item, dict):
            continue
        eid = first_nonempty(item.get("id"), item.get("pmid"), item.get("pmcid"), item.get("doi"), item.get("title"))
        doi = normalize_doi(item.get("doi"))
        pmcid = item.get("pmcid")
        pdf_url = _europepmc_pdf_url(item)
        if not pdf_url and pmcid:
            pdf_url = f"https://pmc.ncbi.nlm.nih.gov/articles/{pmcid}/pdf/"
        candidates.append(CandidatePaper(
            paper_id=f"europe_pmc:{eid}",
            title=str(item.get("title") or "Sem título").strip(),
            abstract=str(item.get("abstractText") or "").strip(),
            year=year_from_text(item.get("pubYear") or item.get("firstPublicationDate")),
            venue=str(item.get("journalTitle") or "").strip() or None,
            publication_date=str(item.get("firstPublicationDate") or item.get("firstIndexDate") or "").strip() or None,
            authors=_europepmc_authors(item),
            tldr=None,
            url=str(item.get("doiUrl") or item.get("fullTextUrl") or item.get("sourceUrl") or "").strip() or (f"https://europepmc.org/article/{item.get('source', 'MED')}/{eid}" if eid else None),
            pdf_url=pdf_url,
            doi=doi,
            document_type=str(item.get("pubType") or "").strip() or None,
            language=normalize_language_name(item.get("language")),
            sources=["europe_pmc"],
            source_ids={"europe_pmc": str(eid), **({"pmc": pmcid} if pmcid else {})},
        ))
    if not candidates:
        warnings.append("Europe PMC não retornou resultados para a query informada.")
    return SourceFetchResult(source="europe_pmc", query=query, retrieved=len(candidates), candidates=candidates, warnings=warnings, raw_payloads=raw_payloads)


def fetch_core_candidates(query: str, limit: int, periodo: str | None = None, idiomas: list[str] | None = None, api_key: str | None = None) -> SourceFetchResult:
    warnings: list[str] = []
    raw_payloads: list[dict] = []
    if not api_key:
        return SourceFetchResult(source="core", query=query, retrieved=0, candidates=[], warnings=["CORE_API_KEY não configurado."], raw_payloads=[])

    def _core_fallback_queries(original_query: str) -> list[str]:
        tokens: list[str] = []
        for part in re.findall(r'"[^"]+"|\S+', original_query or ""):
            part = part.strip()
            if not part or part.upper() in {"AND", "OR", "NOT"}:
                continue
            clean = part.strip('()')
            if clean and clean not in tokens:
                tokens.append(clean)

        english_terms = [t.strip('"') for t in tokens if not _is_portuguese_like_term(t.strip('"'))]
        portuguese_terms = [t.strip('"') for t in tokens if _is_portuguese_like_term(t.strip('"'))]
        candidates: list[str] = []

        def _add(query_text: str) -> None:
            query_text = re.sub(r"\s+", " ", (query_text or "").strip())
            if query_text and query_text not in candidates and query_text != original_query.strip():
                candidates.append(query_text)

        if english_terms:
            q = " ".join(_quoted(t) if " " in t else t for t in _unique_terms(english_terms, max_items=4))
            _add(q)

        if english_terms:
            state_like = [t for t in english_terms if "state" in t.lower() or "capacity" in t.lower()]
            policy_like = [t for t in english_terms if "policy" in t.lower() or "public" in t.lower() or "implementation" in t.lower() or "outcome" in t.lower() or "performance" in t.lower()]
            review_like = [t for t in english_terms if "review" in t.lower()]
            central_like = [t for t in english_terms if "central" in t.lower() or "decentral" in t.lower() or "coerc" in t.lower()]
            structured = _unique_terms(state_like + central_like + policy_like + review_like, max_items=4)
            if structured:
                _add(" ".join(_quoted(t) if " " in t else t for t in structured))

        # FallBacks estáticos, consistentes e preferencialmente em inglês.
        _add('"state capacity" "policy implementation" review')
        _add('"state capacity" "policy outcomes" review')
        _add('"state capacity" centralization review')
        _add('"state capacity" coercion review')

        # Último recurso: bilíngue curto e controlado.
        if portuguese_terms:
            mixed = _unique_terms([t for t in portuguese_terms if len(t.split()) <= 4], max_items=1) + _unique_terms(english_terms, max_items=2)
            if mixed:
                _add(" ".join(_quoted(t) if " " in t else t for t in mixed[:3]))

        return candidates[:5]

    def _run_core_request(query_value: str) -> tuple[requests.Response, dict]:
        params = {"q": query_value, "limit": str(min(max(1, limit), 100))}
        headers = dict(REQUEST_HEADERS)
        headers["Authorization"] = api_key
        resp = requests.get(CORE_SEARCH_URL, params=params, headers=headers, timeout=60)
        payload = {}
        try:
            payload = resp.json()
        except Exception:
            payload = {}
        return resp, payload

    active_query = query
    resp, payload = _run_core_request(active_query)
    raw_payloads.append(payload)
    results = payload.get("results") or payload.get("data") or []

    if resp.status_code >= 500 or not results:
        fallback_queries = _core_fallback_queries(query)
        if fallback_queries:
            warnings.append(
                "CORE falhou com a query principal; fallback(s) acionado(s): "
                + " | ".join(fallback_queries)
            )
        for fallback_query in fallback_queries:
            active_query = fallback_query
            resp, payload = _run_core_request(active_query)
            raw_payloads.append(payload)
            if resp.status_code >= 500:
                continue
            results = payload.get("results") or payload.get("data") or []
            if results:
                break

    resp.raise_for_status()
    results = payload.get("results") or payload.get("data") or []

    candidates: list[CandidatePaper] = []
    for item in results[:limit]:
        if not isinstance(item, dict):
            continue
        cid = first_nonempty(item.get("id"), item.get("doi"), item.get("title"), len(candidates))
        doi = normalize_doi(item.get("doi"))
        authors_raw = item.get("authors") or []
        authors: list[str] = []
        if isinstance(authors_raw, list):
            for a in authors_raw:
                if isinstance(a, dict):
                    name = a.get("name") or a.get("displayName")
                else:
                    name = str(a)
                if name:
                    authors.append(str(name))
        links: list[str] = []
        for key in ("downloadUrl", "fullTextLink", "fullTextUrl", "url", "oaiPmhUrl"):
            if item.get(key):
                links.append(str(item[key]))
        for link in item.get("links") or []:
            if isinstance(link, str):
                links.append(link)
            elif isinstance(link, dict) and link.get("url"):
                links.append(str(link["url"]))
        pdf_url = None
        for link in _dedupe_links(links):
            if link.lower().endswith(".pdf") or "/pdf" in link.lower() or "download" in link.lower():
                pdf_url = link
                break
        candidates.append(CandidatePaper(
            paper_id=f"core:{cid}",
            title=str(item.get("title") or "Sem título").strip(),
            abstract=str(item.get("abstract") or item.get("description") or "").strip(),
            year=year_from_text(str(item.get("yearPublished") or item.get("publishedDate") or item.get("createdDate") or "")),
            venue=str(item.get("publisher") or item.get("journals") or "").strip() or None,
            publication_date=str(item.get("publishedDate") or item.get("createdDate") or "").strip() or None,
            authors=authors,
            tldr=None,
            url=(links[0] if links else None),
            pdf_url=pdf_url,
            doi=doi,
            document_type=str(item.get("type") or item.get("documentType") or "").strip() or None,
            language=normalize_language_name(item.get("language")),
            sources=["core"],
            source_ids={"core": str(cid)},
        ))
    if not candidates:
        warnings.append("CORE não retornou resultados para a query informada.")
    return SourceFetchResult(source="core", query=active_query, retrieved=len(candidates), candidates=candidates, warnings=warnings, raw_payloads=raw_payloads)

def fetch_scopus_candidates(query: str, limit: int, api_key: str, insttoken: str | None) -> SourceFetchResult:
    warnings: list[str] = []
    candidates: list[CandidatePaper] = []
    raw_payloads: list[dict] = []
    start = 0
    per_page = min(max(limit, 1), 25)
    while len(candidates) < limit:
        params = {
            "query": query,
            "count": str(min(per_page, limit - len(candidates))),
            "start": str(start),
            "view": "STANDARD",
            "sort": "relevancy",
        }
        resp = requests.get(SCOPUS_SEARCH_URL, params=params, headers=scopus_headers(api_key, insttoken), timeout=60)
        resp.raise_for_status()
        payload = resp.json()
        raw_payloads.append(payload)
        results = payload.get("search-results", {})
        entries = results.get("entry", []) or []
        if not entries:
            break
        for item in entries:
            title = (item.get("dc:title") or "Sem título").strip()
            doi = (item.get("prism:doi") or "").strip() or None
            cover = item.get("prism:coverDate")
            publication_name = (item.get("prism:publicationName") or "").strip() or None
            identifier = first_nonempty(item.get("eid"), item.get("dc:identifier"), doi, title)
            url = (item.get("prism:url") or "").strip() or None
            candidates.append(
                CandidatePaper(
                    paper_id=f"scopus:{identifier}",
                    title=title,
                    abstract=(item.get("dc:description") or "").strip(),
                    year=year_from_text(cover),
                    venue=publication_name,
                    publication_date=cover.strip() if isinstance(cover, str) and cover.strip() else None,
                    authors=author_list_from_scopus(item),
                    tldr=None,
                    url=url,
                    pdf_url=None,
                    doi=doi,
                    document_type=first_nonempty(item.get("subtypeDescription"), item.get("subtype")),
                    language=first_nonempty(item.get("language"), item.get("dc:language"), item.get("prism:language")),
                    sources=["scopus"],
                    source_ids={"scopus": str(identifier)},
                )
            )
            if len(candidates) >= limit:
                break
        if len(entries) < per_page:
            break
        start += len(entries)
    if not candidates:
        warnings.append("Scopus não retornou resultados para a query informada.")
    return SourceFetchResult(source="scopus", query=query, retrieved=len(candidates), candidates=candidates, warnings=warnings, raw_payloads=raw_payloads)


def fetch_wos_candidates(query: str, limit: int, api_key: str) -> SourceFetchResult:
    warnings: list[str] = []
    candidates: list[CandidatePaper] = []
    raw_payloads: list[dict] = []
    page = 1
    per_page = min(max(limit, 1), 50)
    while len(candidates) < limit:
        params = {
            "q": query,
            "db": "WOS",
            "limit": str(min(per_page, limit - len(candidates))),
            "page": str(page),
            "sortField": "RS+D",
        }
        resp = requests.get(WOS_STARTER_URL, params=params, headers=wos_headers(api_key), timeout=60)
        resp.raise_for_status()
        payload = resp.json()
        raw_payloads.append(payload)
        hits = payload.get("hits") or payload.get("data") or payload.get("documents") or []
        if not hits:
            break
        for item in hits:
            title = first_nonempty(
                item.get("title"),
                nested_get(item, "titles", 0, "title"),
                nested_get(item, "names", "title"),
            )
            title = str(title).strip() if title else "Sem título"
            publication_date = first_nonempty(item.get("publishYear"), item.get("datePublished"), item.get("sourceDate"))
            venue = first_nonempty(
                nested_get(item, "source", "sourceTitle"),
                item.get("sourceTitle"),
                item.get("source"),
            )
            identifiers = item.get("identifiers") or {}
            doi = first_nonempty(identifiers.get("doi"), item.get("doi"))
            uid = first_nonempty(item.get("uid"), item.get("UID"), doi, title)
            links = item.get("links") or {}
            url = first_nonempty(links.get("record"), links.get("self"), item.get("url"))
            abstract = first_nonempty(item.get("abstract"), nested_get(item, "keywords", "authorKeywords"), "")
            candidates.append(
                CandidatePaper(
                    paper_id=f"web_of_science:{uid}",
                    title=title,
                    abstract=str(abstract).strip() if abstract else "",
                    year=year_from_text(str(publication_date) if publication_date is not None else None),
                    venue=str(venue).strip() if isinstance(venue, str) and venue.strip() else None,
                    publication_date=str(publication_date).strip() if publication_date is not None else None,
                    authors=author_list_from_wos(item),
                    tldr=None,
                    url=str(url).strip() if isinstance(url, str) and url.strip() else None,
                    pdf_url=None,
                    doi=str(doi).strip() if isinstance(doi, str) and doi.strip() else None,
                    language=first_nonempty(item.get("language"), item.get("lang"), item.get("sourceLanguage"), nested_get(item, "metadata", "language")),
                    sources=["web_of_science"],
                    source_ids={"web_of_science": str(uid)},
                )
            )
            if len(candidates) >= limit:
                break
        if len(hits) < per_page:
            break
        page += 1
    if not candidates:
        warnings.append("Web of Science não retornou resultados para a query informada.")
    return SourceFetchResult(source="web_of_science", query=query, retrieved=len(candidates), candidates=candidates, warnings=warnings, raw_payloads=raw_payloads)



PDF_CONTENT_TYPES = {
    "application/pdf",
    "application/x-pdf",
    "application/acrobat",
    "applications/vnd.pdf",
    "text/pdf",
    "application/octet-stream",
}
REQUEST_HEADERS = {
    "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) ActivityPrisma/3.8.67",
    "Accept": "text/html,application/pdf,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
}
PDF_LINK_PATTERNS = [
    re.compile(r'<meta[^>]+name=["\\\']citation_pdf_url["\\\'][^>]+content=["\\\']([^"\\\']+)["\\\']', re.I),
    re.compile(r'href=["\\\']([^"\\\']+\.pdf(?:\?[^"\\\']*)?)["\\\']', re.I),
    re.compile(r'href=["\\\']([^"\\\']*download[^"\\\']*)["\\\']', re.I),
]

PDF_LINK_PATTERNS.extend([
    re.compile(r'<meta[^>]+name=["\']citation_fulltext_html_url["\'][^>]+content=["\']([^"\']+)["\']', re.I),
    re.compile(r'href=["\']([^"\']*/science/article/pii/[^"\']+/pdfft[^"\']*)["\']', re.I),
    re.compile(r'href=["\']([^"\']*/science/article/pii/[^"\']+/pdf[^"\']*)["\']', re.I),
    re.compile(r'["\'](https?://pdf\.sciencedirectassets\.com/[^"\']+\.pdf[^"\']*)["\']', re.I),
    re.compile(r'["\']([^"\']*/pdfft\?[^"\']*)["\']', re.I),
])

SCIENCEDIRECT_PII_RE = re.compile(r"/science/article/pii/([A-Za-z0-9]+)", re.I)
DOI_RE = re.compile(r"10\.\d{4,9}/[^\s\"<>]+", re.I)


def normalize_doi(value: str | None) -> str | None:
    if not value:
        return None
    raw = str(value).strip()
    raw = re.sub(r"^doi:\s*", "", raw, flags=re.I).strip()
    raw = re.sub(r"^https?://(?:dx\.)?doi\.org/", "", raw, flags=re.I).strip()
    raw = raw.strip(' .;,)]}')
    m = DOI_RE.search(raw)
    if m:
        raw = m.group(0).strip(' .;,)]}')
    return raw if raw.lower().startswith("10.") else None


def doi_to_url(doi: str | None) -> str | None:
    doi = normalize_doi(doi)
    return f"https://doi.org/{doi}" if doi else None


def extract_sciencedirect_pii(text: str | None) -> str | None:
    if not text:
        return None
    m = SCIENCEDIRECT_PII_RE.search(str(text))
    if m:
        return m.group(1)
    m = re.search(r"\b(S\d{8,}[A-Z0-9]*)\b", str(text), flags=re.I)
    return m.group(1) if m else None


def build_sciencedirect_pdf_candidates(pii: str | None) -> list[str]:
    if not pii:
        return []
    base = f"https://www.sciencedirect.com/science/article/pii/{pii.strip()}"
    return [
        f"{base}/pdfft?isDTMRedir=true&download=true",
        f"{base}/pdfft?isDTMRedir=true",
        f"{base}/pdf?download=true",
        f"{base}/pdf",
    ]


def _dedupe_links(links: list[str]) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for link in links:
        link = (link or "").strip().replace("\\/", "/")
        if link and link not in seen:
            seen.add(link)
            out.append(link)
    return out


def try_resolve_pdf_from_unpaywall(doi: str | None) -> tuple[str | None, str | None]:
    doi = normalize_doi(doi)
    email = os.getenv("UNPAYWALL_EMAIL") or os.getenv("OPENALEX_EMAIL")
    if not doi:
        return None, "DOI ausente para Unpaywall"
    if not email:
        return None, "UNPAYWALL_EMAIL não configurado"
    url = f"https://api.unpaywall.org/v2/{quote(doi, safe='')}?email={quote(email, safe='')}"
    try:
        resp = requests.get(url, headers=REQUEST_HEADERS, timeout=25)
        if resp.status_code >= 400:
            return None, f"Unpaywall retornou HTTP {resp.status_code}"
        data = resp.json()
    except Exception as exc:
        return None, f"Falha ao consultar Unpaywall: {exc}"
    links = []
    best = data.get("best_oa_location") or {}
    for key in ("url_for_pdf", "url", "url_for_landing_page"):
        if best.get(key):
            links.append(str(best[key]))
    for loc in data.get("oa_locations") or []:
        if isinstance(loc, dict):
            for key in ("url_for_pdf", "url", "url_for_landing_page"):
                if loc.get(key):
                    links.append(str(loc[key]))
    for link in _dedupe_links(links):
        ok, final_url, _ = verify_pdf_download_url(link)
        if ok and final_url:
            return final_url, "PDF resolvido via Unpaywall"
        resolved, _ = try_resolve_pdf_from_landing(link)
        if resolved:
            return resolved, "PDF resolvido via landing page do Unpaywall"
    return None, "Unpaywall não retornou PDF verificável"


def try_resolve_pdf_from_openalex(doi: str | None) -> tuple[str | None, str | None]:
    doi = normalize_doi(doi)
    if not doi:
        return None, "DOI ausente para OpenAlex"
    url = f"https://api.openalex.org/works/doi:{quote(doi, safe=':/')}"
    try:
        resp = requests.get(url, headers=REQUEST_HEADERS, timeout=25)
        if resp.status_code >= 400:
            return None, f"OpenAlex retornou HTTP {resp.status_code}"
        data = resp.json()
    except Exception as exc:
        return None, f"Falha ao consultar OpenAlex: {exc}"
    links = []
    oa = data.get("open_access") or {}
    if oa.get("oa_url"):
        links.append(str(oa["oa_url"]))
    for loc_key in ("best_oa_location", "primary_location"):
        loc = data.get(loc_key) or {}
        if isinstance(loc, dict):
            for key in ("pdf_url", "landing_page_url"):
                if loc.get(key):
                    links.append(str(loc[key]))
    for loc in data.get("locations") or []:
        if isinstance(loc, dict):
            for key in ("pdf_url", "landing_page_url"):
                if loc.get(key):
                    links.append(str(loc[key]))
    for link in _dedupe_links(links):
        ok, final_url, _ = verify_pdf_download_url(link)
        if ok and final_url:
            return final_url, "PDF resolvido via OpenAlex"
        resolved, _ = try_resolve_pdf_from_landing(link)
        if resolved:
            return resolved, "PDF resolvido via landing page do OpenAlex"
    return None, "OpenAlex não retornou PDF verificável"


def is_probably_pdf_response(resp: requests.Response) -> bool:
    ctype = (resp.headers.get("Content-Type") or "").split(";")[0].strip().lower()
    final_url = str(resp.url).lower()
    if ctype in PDF_CONTENT_TYPES:
        return True
    if final_url.endswith(".pdf"):
        return True
    disposition = (resp.headers.get("Content-Disposition") or "").lower()
    if ".pdf" in disposition:
        return True
    return False

def fetch_url_best_effort(url: str, timeout: int = 25) -> requests.Response | None:
    try:
        resp = requests.get(url, headers=REQUEST_HEADERS, timeout=timeout, allow_redirects=True, stream=True)
        return resp
    except Exception:
        return None

def verify_pdf_download_url(url: str) -> tuple[bool, str | None, str | None]:
    if not url:
        return False, None, "URL ausente"
    resp = fetch_url_best_effort(url)
    if resp is None:
        return False, None, "Falha ao acessar a URL"
    try:
        if resp.status_code >= 400:
            return False, None, f"HTTP {resp.status_code}"
        if is_probably_pdf_response(resp):
            return True, str(resp.url), None
        return False, None, "A URL não retornou um PDF verificável"
    finally:
        try:
            resp.close()
        except Exception:
            pass

def extract_pdf_links_from_html(html: str, base_url: str) -> list[str]:
    found: list[str] = []
    for pattern in PDF_LINK_PATTERNS:
        for match in pattern.findall(html or ""):
            found.append(urljoin(base_url, str(match).strip()))
    pii = extract_sciencedirect_pii(base_url) or extract_sciencedirect_pii(html)
    found.extend(build_sciencedirect_pdf_candidates(pii))
    return _dedupe_links(found)[:24]


def try_resolve_pdf_from_landing(url: str) -> tuple[str | None, str | None]:
    if not url:
        return None, "URL de landing ausente"

    # ScienceDirect/Elsevier: se já temos PII na URL, gerar URLs de PDF antes
    # de depender do HTML da página, que pode variar conforme cookies/sessão.
    pii_from_url = extract_sciencedirect_pii(url)
    for sd_pdf_url in build_sciencedirect_pdf_candidates(pii_from_url):
        ok, final_url, _note = verify_pdf_download_url(sd_pdf_url)
        if ok and final_url:
            return final_url, "PDF ScienceDirect resolvido por PII da URL"

    resp = fetch_url_best_effort(url)
    if resp is None:
        return None, "Falha ao acessar a landing page"
    final_resp_url = str(resp.url)
    try:
        if resp.status_code >= 400:
            return None, f"Landing page retornou HTTP {resp.status_code}"
        if is_probably_pdf_response(resp):
            return final_resp_url, None
        ctype = (resp.headers.get("Content-Type") or "").lower()
        if "html" not in ctype and "xml" not in ctype and "text" not in ctype:
            return None, "Landing page não retornou HTML legível"
        try:
            html = resp.text[:800000]
        except Exception:
            return None, "Não foi possível ler o conteúdo HTML da landing page"
    finally:
        try:
            resp.close()
        except Exception:
            pass

    pii = extract_sciencedirect_pii(final_resp_url) or extract_sciencedirect_pii(html)
    candidate_links = build_sciencedirect_pdf_candidates(pii)
    candidate_links.extend(extract_pdf_links_from_html(html, final_resp_url or str(url)))
    for link in _dedupe_links(candidate_links):
        ok, final_url, _note = verify_pdf_download_url(link)
        if ok and final_url:
            return final_url, None
    return None, "Nenhum link de PDF verificável foi encontrado na landing page"

def resolve_full_text_for_candidate(candidate: CandidatePaper) -> CandidatePaper:
    doi = normalize_doi(candidate.doi)
    if doi:
        candidate.doi = doi

    links_to_try: list[tuple[str, str]] = []
    if candidate.pdf_url:
        links_to_try.append((candidate.pdf_url, "pdf_url informado pela base"))
    if candidate.url:
        links_to_try.append((candidate.url, "URL principal do registro"))
    if doi:
        doi_url = doi_to_url(doi)
        if doi_url:
            links_to_try.append((doi_url, "landing page do DOI"))

    # Resolvedores OA por DOI antes/depois da landing page. OpenAlex não exige chave;
    # Unpaywall é usado quando UNPAYWALL_EMAIL/OPENALEX_EMAIL estiver configurado.
    if doi:
        for resolver_name, resolver in (
            ("OpenAlex", try_resolve_pdf_from_openalex),
            ("Unpaywall", try_resolve_pdf_from_unpaywall),
        ):
            resolved_url, note = resolver(doi)
            if resolved_url:
                candidate.pdf_url = resolved_url
                candidate.full_text_verified = True
                candidate.full_text_source = f"DOI ({resolver_name})"
                candidate.full_text_note = note or "PDF resolvido por DOI."
                return candidate
            candidate.full_text_note = note or candidate.full_text_note

    seen: set[str] = set()
    cleaned: list[tuple[str, str]] = []
    for link, source in links_to_try:
        link = (link or "").strip()
        if link and link not in seen:
            seen.add(link)
            cleaned.append((link, source))

    for link, source in cleaned:
        ok, final_url, note = verify_pdf_download_url(link)
        if ok and final_url:
            candidate.pdf_url = final_url
            candidate.full_text_verified = True
            candidate.full_text_source = source
            candidate.full_text_note = "PDF verificável acessível para leitura e download."
            return candidate
        resolved_url, landing_note = try_resolve_pdf_from_landing(link)
        if resolved_url:
            candidate.pdf_url = resolved_url
            candidate.full_text_verified = True
            candidate.full_text_source = f"{source} (resolução via landing page/DOI)"
            candidate.full_text_note = "PDF identificável e acessível a partir da landing page ou do DOI."
            return candidate
        candidate.full_text_note = note or landing_note or candidate.full_text_note or "Texto completo não verificável"

    candidate.full_text_verified = False
    if not candidate.full_text_note:
        candidate.full_text_note = "Não foi possível localizar um link verificável para download do texto completo."
    return candidate

def _pdf_cache_filename(candidate: CandidatePaper) -> str:
    seed = candidate.pdf_url or candidate.url or candidate.doi or candidate.paper_id
    digest = hashlib.sha1(seed.encode("utf-8", errors="ignore")).hexdigest()[:12]
    base = slugify(candidate.title)[:80] or slugify(candidate.paper_id)
    return f"{base}_{digest}.pdf"


def download_candidate_pdf(candidate: CandidatePaper, cache_dir: Path, timeout: int = 45, max_bytes: int = 30 * 1024 * 1024) -> CandidatePaper:
    if candidate.downloaded_pdf_path and Path(candidate.downloaded_pdf_path).exists():
        candidate.downloaded_pdf_note = candidate.downloaded_pdf_note or "PDF baixado localmente com sucesso."
        return candidate
    if not candidate.pdf_url:
        # v3.8.30: nova tentativa de resolução por DOI/landing page no momento do
        # download, útil quando o candidato veio da Scopus/Semantic com DOI, mas
        # sem pdf_url no metadado inicial.
        candidate = resolve_full_text_for_candidate(candidate)
    if not candidate.pdf_url:
        candidate.full_text_verified = False
        candidate.full_text_note = "Sem URL de PDF para download local após tentativa de resolução por DOI/landing page."
        return candidate

    cache_dir.mkdir(parents=True, exist_ok=True)
    dest = cache_dir / _pdf_cache_filename(candidate)
    try:
        resp = requests.get(candidate.pdf_url, headers=REQUEST_HEADERS, timeout=timeout, allow_redirects=True, stream=True)
    except Exception as exc:
        candidate.full_text_verified = False
        candidate.full_text_note = f"Falha no download local do PDF: {exc}"
        return candidate

    try:
        if resp.status_code >= 400:
            candidate.full_text_verified = False
            candidate.full_text_note = f"Download local retornou HTTP {resp.status_code}"
            return candidate
        if not is_probably_pdf_response(resp):
            candidate.full_text_verified = False
            candidate.full_text_note = "O link não retornou um PDF válido para download local."
            return candidate

        total = 0
        with open(dest, "wb") as fh:
            for chunk in resp.iter_content(chunk_size=65536):
                if not chunk:
                    continue
                total += len(chunk)
                if total > max_bytes:
                    candidate.full_text_verified = False
                    candidate.full_text_note = "PDF excede o tamanho máximo permitido para download local."
                    try:
                        fh.close()
                    except Exception:
                        pass
                    try:
                        dest.unlink(missing_ok=True)
                    except Exception:
                        pass
                    return candidate
                fh.write(chunk)
    finally:
        try:
            resp.close()
        except Exception:
            pass

    try:
        head = dest.read_bytes()[:8]
    except Exception as exc:
        candidate.full_text_verified = False
        candidate.full_text_note = f"PDF baixado, mas não pôde ser lido localmente: {exc}"
        return candidate

    if not head.startswith(b"%PDF"):
        candidate.full_text_verified = False
        candidate.full_text_note = "Arquivo baixado não possui assinatura PDF válida."
        try:
            dest.unlink(missing_ok=True)
        except Exception:
            pass
        return candidate

    candidate.downloaded_pdf_path = str(dest)
    candidate.downloaded_pdf_note = "PDF baixado localmente com sucesso."
    candidate.full_text_verified = True
    if not candidate.full_text_note:
        candidate.full_text_note = candidate.downloaded_pdf_note
    return candidate


def ensure_candidate_readable(candidate: CandidatePaper, cache_dir: Path) -> CandidatePaper:
    candidate = resolve_full_text_for_candidate(candidate)
    if candidate.full_text_verified and candidate.pdf_url:
        candidate = download_candidate_pdf(candidate, cache_dir)
    return candidate


def enforce_downloadable_full_text(candidates: list[CandidatePaper], cache_dir: Path) -> tuple[list[CandidatePaper], int, list[str]]:
    verified: list[CandidatePaper] = []
    removed = 0
    warnings: list[str] = []
    for candidate in candidates:
        candidate = resolve_full_text_for_candidate(candidate)
        if candidate.full_text_verified and candidate.pdf_url:
            verified.append(candidate)
        else:
            removed += 1
            warnings.append(
                f"Excluído antes da triagem por falta de texto completo verificável: {candidate.title}."
            )
    return verified, removed, warnings

def maybe_filter_years(candidates: list[CandidatePaper], periodo: str) -> tuple[list[CandidatePaper], int]:
    m = re.fullmatch(r"\s*(\d{4})\s*[-–]\s*(\d{4})\s*", periodo)
    if not m:
        return candidates, 0
    start, end = int(m.group(1)), int(m.group(2))
    filtered = [c for c in candidates if c.year is None or (start <= c.year <= end)]
    removed = max(0, len(candidates) - len(filtered))
    return filtered or candidates, removed if filtered else 0


def collect_candidates(config: Config, logger: logging.Logger | None = None) -> tuple[list[CandidatePaper], SearchAudit]:
    warnings: list[str] = []
    per_source: list[SourceFetchResult] = []
    all_candidates: list[CandidatePaper] = []

    selected = set(config.bases)
    interactive = not config.nao_interativo

    s2_key = (
        prompt_secret_if_missing("SEMANTIC_SCHOLAR_API_KEY", "Chave do Semantic Scholar", required=False, interactive=interactive)
        if "semantic_scholar" in selected
        else os.getenv("SEMANTIC_SCHOLAR_API_KEY")
    )
    scopus_key = (
        prompt_secret_if_missing("SCOPUS_API_KEY", "Chave do Scopus/Elsevier", required=False, interactive=interactive)
        if "scopus" in selected
        else os.getenv("SCOPUS_API_KEY")
    )
    scopus_insttoken = (
        prompt_secret_if_missing("SCOPUS_INSTTOKEN", "Insttoken do Scopus", required=False, interactive=interactive)
        if "scopus" in selected
        else os.getenv("SCOPUS_INSTTOKEN")
    )
    wos_key = (
        prompt_secret_if_missing("WOS_API_KEY", "Chave do Web of Science", required=False, interactive=interactive)
        if "web_of_science" in selected
        else os.getenv("WOS_API_KEY")
    )
    ncbi_key = (
        prompt_secret_if_missing("NCBI_API_KEY", "Chave NCBI/PubMed", required=False, interactive=interactive)
        if "pubmed" in selected
        else os.getenv("NCBI_API_KEY")
    )
    ncbi_email = os.getenv("NCBI_EMAIL") or os.getenv("UNPAYWALL_EMAIL") or os.getenv("OPENALEX_EMAIL")
    openalex_key = os.getenv("OPENALEX_API_KEY")
    openalex_email = os.getenv("OPENALEX_EMAIL") or os.getenv("UNPAYWALL_EMAIL") or ncbi_email
    crossref_email = os.getenv("CROSSREF_EMAIL") or openalex_email or ncbi_email
    europepmc_email = os.getenv("EUROPEPMC_EMAIL") or openalex_email or ncbi_email
    core_key = (
        prompt_secret_if_missing("CORE_API_KEY", "Chave CORE", required=False, interactive=interactive)
        if "core" in selected
        else os.getenv("CORE_API_KEY")
    )

    for source in config.bases:
        log_subphase(logger, f"Consultando base {SOURCE_LABELS.get(source, source)}...")
        query = config.source_query(source)
        if source == "scopus":
            query = append_scopus_language_filter(query, config.idiomas)
        elif source == "web_of_science":
            query = append_wos_language_filter(query, config.idiomas)
        try:
            if source == "semantic_scholar":
                result = fetch_semantic_scholar_candidates(query, config.quantidade_triagem, s2_key, config.periodo, config.tipo_estudo)
            elif source == "scopus":
                if not scopus_key:
                    warnings.append("Scopus selecionado, mas SCOPUS_API_KEY não foi informado; base ignorada.")
                    continue
                result = fetch_scopus_candidates(query, config.quantidade_triagem, scopus_key, scopus_insttoken)
            elif source == "web_of_science":
                if not wos_key:
                    warnings.append("Web of Science selecionado, mas WOS_API_KEY não foi informado; base ignorada.")
                    continue
                result = fetch_wos_candidates(query, config.quantidade_triagem, wos_key)
            elif source == "pubmed":
                result = fetch_pubmed_candidates(query, config.quantidade_triagem, ncbi_key, ncbi_email)
            elif source == "openalex":
                result = fetch_openalex_candidates(query, config.quantidade_triagem, config.periodo, config.idiomas, openalex_key, openalex_email)
            elif source == "crossref":
                result = fetch_crossref_candidates(query, config.quantidade_triagem, config.periodo, config.idiomas, crossref_email)
            elif source == "europe_pmc":
                result = fetch_europepmc_candidates(query, config.quantidade_triagem, europepmc_email)
            elif source == "core":
                if not core_key:
                    warnings.append("CORE selecionado, mas CORE_API_KEY não foi informado; base ignorada.")
                    continue
                result = fetch_core_candidates(query, config.quantidade_triagem, config.periodo, config.idiomas, core_key)
            else:
                warnings.append(f"Base não suportada e ignorada: {source}")
                continue
        except requests.HTTPError as exc:
            warnings.append(f"Falha ao consultar {SOURCE_LABELS.get(source, source)}: {exc}")
            continue
        per_source.append(result)
        warnings.extend(result.warnings)
        all_candidates.extend(result.candidates)
        log_subphase(logger, f"Base {SOURCE_LABELS.get(source, source)} concluída: {len(result.candidates)} registro(s) aproveitado(s) nesta etapa.")

    if not all_candidates:
        raise RuntimeError("Nenhum candidato foi recuperado das bases configuradas.")

    identified_total = len(all_candidates)
    log_subphase(logger, f"Total bruto recuperado nas bases: {identified_total} registro(s).")
    log_subphase(logger, "Aplicando filtro temporal...")
    filtered_by_year, removed_by_year = maybe_filter_years(all_candidates, config.periodo)
    log_subphase(logger, "Aplicando filtro de idioma...")
    filtered_by_language, removed_by_language, language_warnings = filter_candidates_by_language(filtered_by_year, config.idiomas)
    warnings.extend(language_warnings)
    log_subphase(logger, "Executando deduplicação...")
    deduped, duplicates_removed = dedupe_candidates(filtered_by_language)
    if removed_by_language:
        warnings.append(f"Registros removidos por idioma fora do escopo: {removed_by_language}.")

    # v3.8.48: a verificação pesada de texto completo deixa de rodar antes da triagem.
    # O ganho principal é evitar dezenas/centenas de requisições HTTP para candidatos
    # que serão excluídos depois por título, resumo e metadados. Nesta etapa, o script
    # preserva apenas os links/metadados já vindos das bases; a resolução por DOI,
    # landing page e o download local ficam para a fase posterior, apenas para os
    # textos que sobreviverem à triagem.
    if not deduped:
        raise RuntimeError("Nenhum candidato permaneceu após filtros e deduplicação.")

    warnings.append(
        "A verificação aprofundada de texto completo foi adiada para depois da triagem temática. "
        "Candidatos foram ranqueados por metadados, resumo e links já informados pelas bases; "
        "a recuperação/download do texto completo será testada apenas para os selecionados."
    )
    audit = SearchAudit(
        per_source=per_source,
        identified_total=identified_total,
        duplicates_removed=duplicates_removed,
        other_removed=removed_by_year + removed_by_language,
        screened_total=len(deduped),
        warnings=warnings,
    )
    return deduped, audit


TRIAGE_STOPWORDS = {
    "a", "an", "and", "the", "of", "for", "to", "in", "on", "by", "with", "without", "from", "into", "through",
    "de", "da", "do", "das", "dos", "e", "em", "na", "no", "nas", "nos", "para", "por", "com", "sem",
    "uma", "um", "uns", "umas", "o", "os", "as", "ao", "aos", "que", "como", "entre", "sobre", "sob",
    "their", "this", "that", "these", "those", "its", "it", "is", "are", "was", "were", "be", "being",
    "ser", "sao", "são", "foi", "sendo", "estar", "esta", "está", "estao", "estão", "dos", "das",
    "policy", "policies", "public", "state", "government", "governamental", "governo", "estado", "estatal",
}


def _triage_normalize_text(text: str | None) -> str:
    text = _ascii_fold(str(text or ""))
    text = text.casefold()
    text = re.sub(r"[^a-z0-9\s-]", " ", text)
    text = re.sub(r"[\s_-]+", " ", text)
    return text.strip()


def _triage_tokenize(text: str | None) -> list[str]:
    raw_tokens = re.findall(r"[a-z0-9]+", _triage_normalize_text(text))
    tokens: list[str] = []
    seen: set[str] = set()
    for token in raw_tokens:
        if token in TRIAGE_STOPWORDS:
            continue
        if token.isdigit():
            continue
        if len(token) <= 2 and token not in {"ia", "ai", "uk", "eu", "us"}:
            continue
        if token not in seen:
            seen.add(token)
            tokens.append(token)
    return tokens


def _triage_phrase_features(text: str | None, *, max_items: int = 14, exclude_norms: set[str] | None = None) -> list[str]:
    exclude_norms = exclude_norms or set()
    seed_terms = expand_seed_items_for_query([text or ""])
    tokens = _triage_tokenize(text)
    candidates: list[str] = []
    candidates.extend(seed_terms)
    for n in (3, 2):
        for idx in range(0, max(0, len(tokens) - n + 1)):
            candidates.append(" ".join(tokens[idx:idx + n]))
    candidates.extend(tokens)

    features: list[str] = []
    seen: set[str] = set()
    for item in candidates:
        norm = _triage_normalize_text(item)
        if not norm or norm in exclude_norms or norm in seen:
            continue
        seen.add(norm)
        features.append(item.strip())
        if len(features) >= max_items:
            break
    return features


def _triage_feature_match(features: list[str], normalized_text: str, token_set: set[str]) -> tuple[int, list[str]]:
    if not features:
        return 0, []
    matched: list[str] = []
    total_weight = 0.0
    matched_weight = 0.0
    for feature in features:
        norm = _triage_normalize_text(feature)
        if not norm:
            continue
        tokens = norm.split()
        weight = 2.8 if len(tokens) >= 3 else 2.0 if len(tokens) == 2 else 1.0
        total_weight += weight
        is_match = norm in normalized_text if len(tokens) >= 2 else tokens[0] in token_set
        if is_match:
            matched_weight += weight
            matched.append(feature)
    score = int(round((matched_weight / total_weight) * 100)) if total_weight else 0
    return max(0, min(100, score)), matched[:8]


def _triage_access_score(candidate: CandidatePaper) -> int:
    if candidate.downloaded_pdf_path or candidate.full_text_verified:
        return 100
    if candidate.pdf_url:
        return 95
    if candidate.doi and candidate.url:
        return 80
    if candidate.doi or candidate.url:
        return 60
    return 0


def get_triage_weight_profile(config: Config, relaxed_recovery: bool = False) -> dict[str, float]:
    if relaxed_recovery:
        return {"tema": 0.55, "recorte": 0.15, "objetivo": 0.15, "tipo_estudo": 0.05, "acesso": 0.10}
    rigor = normalize_triagem_rigor(getattr(config, "triagem_rigor", "moderado"))
    if rigor == "estrito":
        return {"tema": 0.45, "recorte": 0.25, "objetivo": 0.20, "tipo_estudo": 0.08, "acesso": 0.02}
    if rigor == "exploratorio":
        return {"tema": 0.48, "recorte": 0.16, "objetivo": 0.16, "tipo_estudo": 0.10, "acesso": 0.10}
    return {"tema": 0.40, "recorte": 0.22, "objetivo": 0.18, "tipo_estudo": 0.12, "acesso": 0.08}


def get_triage_alignment_thresholds(config: Config, relaxed_recovery: bool = False) -> dict[str, int]:
    if relaxed_recovery:
        return {"total": 35, "tema": 30, "recorte": 0, "objetivo": 0}
    rigor = normalize_triagem_rigor(getattr(config, "triagem_rigor", "moderado"))
    if rigor == "estrito":
        return {"total": 60, "tema": 50, "recorte": 35, "objetivo": 30}
    if rigor == "exploratorio":
        return {"total": 38, "tema": 35, "recorte": 0, "objetivo": 0}
    return {"total": 48, "tema": 42, "recorte": 0, "objetivo": 0}


def build_triage_focus_profile(config: Config, relaxed_recovery: bool = False) -> dict[str, Any]:
    theme_seed = " ".join([config.tema] + list(config.palavras_chave[:12]))
    tema = _triage_phrase_features(theme_seed, max_items=16)
    tema_norms = {_triage_normalize_text(item) for item in tema}
    recorte = _triage_phrase_features(config.recorte, max_items=14, exclude_norms=tema_norms)
    objetivo = _triage_phrase_features(config.objetivo, max_items=14, exclude_norms=tema_norms)
    tipo_estudo = _unique_terms(study_type_terms(config.tipo_estudo) + [config.tipo_estudo], max_items=8)
    return {
        "tema": tema,
        "recorte": recorte,
        "objetivo": objetivo,
        "tipo_estudo": tipo_estudo,
        "pesos": get_triage_weight_profile(config, relaxed_recovery=relaxed_recovery),
        "thresholds": get_triage_alignment_thresholds(config, relaxed_recovery=relaxed_recovery),
    }


def evaluate_candidate_triage_seed(candidate: CandidatePaper, profile: dict[str, Any]) -> dict[str, Any]:
    candidate_text = " | ".join(
        part for part in [
            candidate.title,
            candidate.abstract,
            candidate.extracted_abstract,
            candidate.tldr,
            candidate.venue,
            candidate.document_type,
        ]
        if part
    )
    normalized_text = _triage_normalize_text(candidate_text)
    token_set = set(_triage_tokenize(candidate_text))

    tema_score, tema_hits = _triage_feature_match(profile.get("tema", []), normalized_text, token_set)
    recorte_score, recorte_hits = _triage_feature_match(profile.get("recorte", []), normalized_text, token_set)
    objetivo_score, objetivo_hits = _triage_feature_match(profile.get("objetivo", []), normalized_text, token_set)
    tipo_score, tipo_hits = _triage_feature_match(profile.get("tipo_estudo", []), normalized_text, token_set)
    acesso_score = _triage_access_score(candidate)

    pesos = profile.get("pesos", {})
    total = int(round(
        tema_score * pesos.get("tema", 0.0)
        + recorte_score * pesos.get("recorte", 0.0)
        + objetivo_score * pesos.get("objetivo", 0.0)
        + tipo_score * pesos.get("tipo_estudo", 0.0)
        + acesso_score * pesos.get("acesso", 0.0)
    ))
    thresholds = profile.get("thresholds", {})
    aligned = (
        total >= thresholds.get("total", 0)
        and tema_score >= thresholds.get("tema", 0)
        and recorte_score >= thresholds.get("recorte", 0)
        and objetivo_score >= thresholds.get("objetivo", 0)
    )
    return {
        "total": max(0, min(100, total)),
        "components": {
            "tema": tema_score,
            "recorte": recorte_score,
            "objetivo": objetivo_score,
            "tipo_estudo": tipo_score,
            "acesso": acesso_score,
        },
        "matches": {
            "tema": tema_hits,
            "recorte": recorte_hits,
            "objetivo": objetivo_hits,
            "tipo_estudo": tipo_hits,
        },
        "aligned": bool(aligned),
    }


def build_candidate_triage_payload(candidate: CandidatePaper, seed_eval: dict[str, Any]) -> dict[str, Any]:
    payload = candidate.short_dict()
    payload["triagem_seed_score"] = seed_eval.get("total", 0)
    payload["triagem_seed_components"] = seed_eval.get("components", {})
    payload["triagem_seed_matches"] = seed_eval.get("matches", {})
    payload["triagem_seed_alinhamento_sugerido"] = seed_eval.get("aligned", False)
    return payload


def get_candidate_seed_evaluations(candidates: list[CandidatePaper], config: Config, *, relaxed_recovery: bool = False) -> tuple[dict[str, dict[str, Any]], dict[str, Any]]:
    profile = build_triage_focus_profile(config, relaxed_recovery=relaxed_recovery)
    evaluations = {c.paper_id: evaluate_candidate_triage_seed(c, profile) for c in candidates}
    return evaluations, profile


def sort_candidates_for_triage(candidates: list[CandidatePaper], config: Config, *, relaxed_recovery: bool = False) -> list[CandidatePaper]:
    if not getattr(config, "triagem_score_hibrido", True):
        return list(candidates)
    evaluations, _profile = get_candidate_seed_evaluations(candidates, config, relaxed_recovery=relaxed_recovery)
    return sorted(
        candidates,
        key=lambda c: (
            -evaluations.get(c.paper_id, {}).get("total", 0),
            -evaluations.get(c.paper_id, {}).get("components", {}).get("tema", 0),
            -evaluations.get(c.paper_id, {}).get("components", {}).get("recorte", 0),
            -evaluations.get(c.paper_id, {}).get("components", {}).get("objetivo", 0),
            (c.year or 0) * -1,
            c.title.casefold(),
        ),
    )


def build_triage_directives_text(config: Config) -> str:
    extra = (getattr(config, "triagem_diretivas_extras", None) or "").strip()
    if not extra:
        return ""
    return textwrap.dedent(f"""
    Diretivas extras de triagem/ranking definidas pelo usuário:
    {extra[:12000]}
    """).strip()


def apply_hybrid_triage_ranking(parsed: TriageOutput, candidates: list[CandidatePaper], config: Config, *, relaxed_recovery: bool = False) -> tuple[TriageOutput, str | None]:
    if not getattr(config, "triagem_score_hibrido", True):
        return parsed, None
    evaluations, _profile = get_candidate_seed_evaluations(candidates, config, relaxed_recovery=relaxed_recovery)
    original = list(sorted(parsed.decisions, key=lambda x: (x.ranking, -x.aderencia_score, x.paper_id)))
    if not original:
        return parsed, None

    def combined_score(decision: CandidateDecision) -> tuple[float, int, int]:
        seed_eval = evaluations.get(decision.paper_id, {})
        seed_total = int(seed_eval.get("total", 0))
        combo = (decision.aderencia_score * 0.68) + (seed_total * 0.32)
        return combo, seed_total, int(seed_eval.get("components", {}).get("tema", 0))

    included = [d for d in original if d.stage == "incluido"]
    others = [d for d in original if d.stage != "incluido"]
    included_sorted = sorted(included, key=lambda d: (-combined_score(d)[0], -combined_score(d)[1], -combined_score(d)[2], d.ranking, d.paper_id))
    others_sorted = sorted(others, key=lambda d: (-combined_score(d)[0], -combined_score(d)[1], -combined_score(d)[2], d.ranking, d.paper_id))
    rebuilt = included_sorted + others_sorted
    if [d.paper_id for d in rebuilt] == [d.paper_id for d in original]:
        return parsed, None

    rebuilt_decisions: list[CandidateDecision] = []
    for idx, decision in enumerate(rebuilt, start=1):
        rebuilt_decisions.append(CandidateDecision(
            paper_id=decision.paper_id,
            stage=decision.stage,
            tipo_estudo=decision.tipo_estudo,
            motivo=decision.motivo,
            ranking=idx,
            aderencia_score=decision.aderencia_score,
            alinhado_triada=decision.alinhado_triada,
        ))
    updated = TriageOutput(
        pergunta_orientadora=parsed.pergunta_orientadora,
        introducao=parsed.introducao,
        base_logica_busca=parsed.base_logica_busca,
        criterios_inclusao=parsed.criterios_inclusao,
        criterios_exclusao=parsed.criterios_exclusao,
        observacao_metodologica=parsed.observacao_metodologica,
        selected_paper_ids=[d.paper_id for d in rebuilt_decisions if d.stage == "incluido"],
        selected_papers_justification=parsed.selected_papers_justification,
        selection_warning=parsed.selection_warning,
        decisions=rebuilt_decisions,
    )
    return updated, "Ranking final recalibrado pelo score híbrido local (tema/recorte/objetivo/tipo de estudo/acesso)."


def build_triage_rigor_instruction(config: Config, relaxed_recovery: bool = False) -> str:
    pesos = get_triage_weight_profile(config, relaxed_recovery=relaxed_recovery)
    pesos_pct = {k: int(round(v * 100)) for k, v in pesos.items()}
    rigor = normalize_triagem_rigor(getattr(config, "triagem_rigor", "moderado"))
    if relaxed_recovery:
        return textwrap.dedent(f"""
        Critério de aderência nesta rodada de recuperação:
        - Selecione o melhor texto disponível com aderência substantiva mínima ao tema central.
        - O recorte e o objetivo orientam a preferência, mas não podem eliminar automaticamente o melhor candidato quando a literatura recuperada for escassa.
        - O tipo de estudo tem peso residual; a conexão analítica com o tema central é o ponto principal.
        - Registre explicitamente as limitações em selection_warning.
        - Ponderação local de referência: tema {pesos_pct['tema']}%, recorte {pesos_pct['recorte']}%, objetivo {pesos_pct['objetivo']}%, tipo de estudo {pesos_pct['tipo_estudo']}%, acesso {pesos_pct['acesso']}%.
        """).strip()
    if rigor == "estrito":
        return textwrap.dedent(f"""
        Critério de aderência estrito:
        - Tema central, recorte, objetivo e tipo de estudo funcionam como critérios fortes de inclusão.
        - Exclua textos tangenciais, excessivamente amplos ou que só toquem o campo de fundo sem responder ao foco substantivo da atividade.
        - Dê preferência clara a textos que apresentem convergência simultânea entre tema, recorte, objetivo e desenho do estudo.
        - Ponderação local de referência: tema {pesos_pct['tema']}%, recorte {pesos_pct['recorte']}%, objetivo {pesos_pct['objetivo']}%, tipo de estudo {pesos_pct['tipo_estudo']}%, acesso {pesos_pct['acesso']}%.
        """).strip()
    if rigor == "exploratorio":
        return textwrap.dedent(f"""
        Critério de aderência exploratório:
        - O tema central é obrigatório.
        - O recorte e o objetivo funcionam como lentes de priorização, não como filtros rígidos.
        - Inclua textos de aderência alta ou média quando eles puderem sustentar uma análise acadêmica útil do objetivo.
        - Evite zerar a seleção quando houver ao menos um texto substantivamente relacionado ao tema central.
        - Ponderação local de referência: tema {pesos_pct['tema']}%, recorte {pesos_pct['recorte']}%, objetivo {pesos_pct['objetivo']}%, tipo de estudo {pesos_pct['tipo_estudo']}%, acesso {pesos_pct['acesso']}%.
        """).strip()
    return textwrap.dedent(f"""
    Critério de aderência moderado:
    - O tema central é obrigatório.
    - O recorte e o objetivo devem calibrar o ranking final, evitando que textos muito amplos do campo predominem automaticamente sobre textos mais aderentes ao foco específico.
    - O tipo de estudo é priorizado, mas pode ser flexibilizado quando a literatura do recorte for escassa, desde que o texto permaneça substantivamente útil para a análise.
    - Não exclua automaticamente um texto apenas por não cobrir todos os elementos do recorte; porém, quando houver disputa entre um texto amplo e outro mais focal, priorize o mais focal.
    - Ponderação local de referência: tema {pesos_pct['tema']}%, recorte {pesos_pct['recorte']}%, objetivo {pesos_pct['objetivo']}%, tipo de estudo {pesos_pct['tipo_estudo']}%, acesso {pesos_pct['acesso']}%.
    """).strip()


def triage_with_openai(client: OpenAI, config: Config, candidates: list[CandidatePaper], model_org_text: str, *, allow_zero_included: bool = False, relaxed_recovery: bool = False) -> TriageOutput:
    class _TriageOutput(TriageOutput):
        pass

    seed_evaluations, seed_profile = get_candidate_seed_evaluations(candidates, config, relaxed_recovery=relaxed_recovery)
    candidate_payload = [
        build_candidate_triage_payload(c, seed_evaluations.get(c.paper_id, {}))
        for c in candidates
    ]
    triagem_diretivas_text = build_triage_directives_text(config)
    orientacao_extra = f"\n\nOrientações complementares para o arquivo final:\n{config.texto_orientacao_extra[:12000]}" if config.texto_orientacao_extra else ""
    recovery_instruction = ""
    if relaxed_recovery:
        recovery_instruction = textwrap.dedent(f"""
        Modo de recuperação metodológica:
        - A triagem anterior não encontrou texto incluído sob o rigor selecionado.
        - Nesta rodada, selecione exatamente 1 texto com stage='incluido': o candidato de maior aderência relativa ao tema central e ao objetivo.
        - A seleção pode ser exploratória quando não houver aderência perfeita, mas deve estar minimamente conectada ao tema.
        - Preencha selection_warning explicando explicitamente que a seleção foi relaxada por insuficiência de candidatos perfeitamente aderentes.
        - O texto incluído deve ocupar o ranking 1 e ter alinhado_triada=true no sentido de aderência relativa mínima.
        """).strip()
    rigor_instruction = build_triage_rigor_instruction(config, relaxed_recovery=relaxed_recovery)

    system_prompt = textwrap.dedent(
        f"""
        Você é um assistente acadêmico especializado em metodologia de revisão e redação em português.
        Sua tarefa é organizar a triagem de resultados de busca para uma atividade acadêmica.

        Regras obrigatórias:
        - Trabalhe apenas com os candidatos fornecidos.
        - Os candidatos foram recuperados por busca bibliográfica; antes da triagem, considere principalmente metadados, resumo e links já fornecidos pelas bases.
        - Selecione no máximo {config.quantidade_selecionados} textos com stage='incluido'.
        - Ordene os textos selecionados do mais aderente ao menos aderente conforme o rigor de triagem indicado abaixo.
        - Caso a quantidade solicitada comece a exigir textos sem relação substantiva com o tema central, pare a seleção antes desse ponto, selecione menos textos e preencha selection_warning explicando a interrupção.
        - Todos os textos com stage='incluido' devem ter alinhado_triada=true no sentido compatível com o rigor de triagem.
        - Os demais devem ser classificados como 'excluido_triagem' ou 'excluido_elegibilidade'.
        - Para todos os candidatos, preencha ranking e aderencia_score. Ranking 1 = texto mais aderente.
        - TODOS os candidatos recebidos DEVEM aparecer em decisions com paper_id válido, exatamente uma vez, sem omissões e sem IDs extras.
        - Não invente dados que não estejam sustentados pelos dados fornecidos.
        - Se houver candidatos com pdf_url, doi ou url já informados pelas bases, considere isso como vantagem metodológica quando a aderência for comparável, mas não descarte automaticamente um texto substantivamente aderente apenas por ausência inicial de PDF; a recuperação/download será testada após a triagem.
        - Cada candidato traz um triagem_seed_score e componentes locais calculados pelo script (tema, recorte, objetivo, tipo de estudo e acesso). Use isso como calibragem inicial do ranking, mas corrija quando os metadados mostrarem algo mais convincente.
        - Em caso de disputa entre textos amplos do campo e textos mais focais, preserve o equilíbrio entre tema central, recorte e objetivo conforme o rigor selecionado.
        - Faça a redação em português acadêmico claro.
        - Use como referência de tom e organização o modelo Org abaixo.
        - O tema central é: {config.tema}.
        - O recorte é: {config.recorte}.
        - O objetivo da atividade é: {config.objetivo}.
        - O tipo priorizado é: {config.tipo_estudo}.
        - As bases consultadas foram: {config.bases_label}.

        {rigor_instruction}
        {recovery_instruction}

        Resumo da calibragem híbrida local:
        - Pesos: {json.dumps(seed_profile.get("pesos", {}), ensure_ascii=False)}
        - Focos do tema: {json.dumps(seed_profile.get("tema", []), ensure_ascii=False)}
        - Focos do recorte: {json.dumps(seed_profile.get("recorte", []), ensure_ascii=False)}
        - Focos do objetivo: {json.dumps(seed_profile.get("objetivo", []), ensure_ascii=False)}
        - Focos do tipo de estudo: {json.dumps(seed_profile.get("tipo_estudo", []), ensure_ascii=False)}

        Modelo Org de referência:
        {model_org_text[:14000]}
        {orientacao_extra}
        {triagem_diretivas_text}
        """
    ).strip()

    user_prompt = textwrap.dedent(
        f"""
        Dados da atividade:
        - Modo da atividade: {"revisão sistemática/PRISMA" if config.modo == "revisao_sistematica" else "pesquisa empírica"}
        - Disciplina: {config.disciplina}
        - Professor(a): {config.professor}
        - Curso: {config.curso}
        - Tema: {config.tema}
        - Recorte: {config.recorte}
        - Objetivo: {config.objetivo}
        - Bases: {config.bases_label}
        - Tipo de estudo priorizado: {config.tipo_estudo}
        - Rigor da triagem: {config.triagem_rigor}
        - Período desejado: {config.periodo}
        - Idiomas aceitáveis: {', '.join(config.idiomas)}
        - Palavras-chave: {', '.join(config.palavras_chave)}
        - Queries por base:
          {json.dumps({src: config.source_query(src) for src in config.bases}, ensure_ascii=False, indent=2)}

        Candidatos recuperados (já ordenados pelo script por aderência híbrida inicial, do mais promissor ao menos promissor):
        {json.dumps(candidate_payload, ensure_ascii=False, indent=2)}

        Gere:
        1. pergunta_orientadora
        2. introducao
        3. base_logica_busca
        4. criterios_inclusao
        5. criterios_exclusao
        6. observacao_metodologica
        7. decisions (uma por paper_id, cobrindo TODOS os candidatos recebidos, sem faltar nenhum), sempre com ranking, aderencia_score e alinhado_triada
        8. selected_paper_ids (lista ordenada do mais semelhante ao menos semelhante)
        9. selected_papers_justification
        10. selection_warning (null quando não houver interrupção antecipada; texto explicativo quando a seleção parar antes do solicitado)
        11. Considere a disponibilidade de texto completo como critério metodológico relevante, mas priorize a aderência acadêmica na triagem; a etapa posterior tentará baixar os textos selecionados e removerá automaticamente os que falharem.
        {"12. Esta é uma rodada de recuperação: se nenhum texto for perfeito, selecione o melhor candidato relativo e registre a limitação em selection_warning." if relaxed_recovery else ""}
        """
    ).strip()

    response = client.responses.parse(
        model=config.model,
        input=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        text_format=_TriageOutput,
    )
    parsed = response.output_parsed
    if parsed is None:
        raise RuntimeError("A OpenAI não retornou triagem estruturada.")

    parsed, repair_warnings, missing_ids = repair_triage_output(parsed, candidates, auto_fill_missing=False)
    for warning in repair_warnings:
        logging.warning(warning)

    completion_attempt = 0
    while missing_ids and completion_attempt < 2:
        completion_attempt += 1
        logging.warning(
            "Triagem inicial ainda não cobriu todos os candidatos; solicitando complementação à IA (%sª tentativa) para %s item(ns).",
            completion_attempt,
            len(missing_ids),
        )
        missing_candidates = [c for c in candidates if c.paper_id in set(missing_ids)]
        completed_decisions, completion_warnings = complete_missing_triage_decisions(
            client,
            config,
            parsed,
            missing_candidates,
            model_org_text,
            relaxed_recovery=relaxed_recovery,
        )
        for warning in completion_warnings:
            logging.warning(warning)
        if completed_decisions:
            parsed.decisions.extend(completed_decisions)
        parsed, repair_warnings, missing_ids = repair_triage_output(parsed, candidates, auto_fill_missing=False)
        for warning in repair_warnings:
            logging.warning(warning)

    parsed, repair_warnings, missing_ids = repair_triage_output(parsed, candidates, auto_fill_missing=True)
    for warning in repair_warnings:
        logging.warning(warning)

    parsed, ranking_warning = enforce_included_top_ranking(parsed)
    if ranking_warning:
        logging.warning(ranking_warning)
    parsed, hybrid_warning = apply_hybrid_triage_ranking(parsed, candidates, config, relaxed_recovery=relaxed_recovery)
    if hybrid_warning:
        logging.info(hybrid_warning)

    decisions_by_id = {d.paper_id: d for d in parsed.decisions}
    rankings = [d.ranking for d in parsed.decisions]
    if sorted(rankings) != list(range(1, len(parsed.decisions) + 1)):
        raise RuntimeError("A triagem precisa atribuir rankings únicos e consecutivos a todos os candidatos.")

    included = [d for d in sorted(parsed.decisions, key=lambda x: x.ranking) if d.stage == "incluido"]
    if not included:
        if allow_zero_included:
            parsed.selected_paper_ids = []
            if not parsed.selection_warning:
                parsed.selection_warning = (
                    "A triagem não incluiu textos porque os candidatos recuperados não apresentaram aderência suficiente "
                    "ao tema central e ao rigor metodológico selecionado."
                )
            return parsed
        raise RuntimeError("A triagem precisa marcar pelo menos 1 texto como incluído.")
    if len(included) > config.quantidade_selecionados:
        raise RuntimeError("A triagem marcou mais textos incluídos do que o solicitado.")
    if any(not d.alinhado_triada for d in included):
        raise RuntimeError("Todos os textos incluídos precisam permanecer alinhados à tríade tema-recorte-objetivo.")
    if len(included) < config.quantidade_selecionados and not parsed.selection_warning:
        parsed.selection_warning = (
            "A seleção foi interrompida antes da quantidade solicitada porque, a partir desse ponto, "
            "os textos remanescentes deixariam de manter aderência suficiente à tríade tema-recorte-objetivo."
        )

    selected_ids = parsed.selected_paper_ids
    included_ids = [d.paper_id for d in included]
    if selected_ids != included_ids:
        raise RuntimeError("selected_paper_ids precisa corresponder aos textos incluídos, na mesma ordem do ranking.")

    for idx, d in enumerate(included, start=1):
        if d.ranking != idx:
            break
    # A seleção deve ocupar o topo do ranking.
    if [d.ranking for d in included] != list(range(1, len(included) + 1)):
        raise RuntimeError("Os textos incluídos precisam ocupar as primeiras posições do ranking de aderência.")
    return parsed


def triage_has_included(triage: TriageOutput | None) -> bool:
    return bool(triage and triage.selected_paper_ids)



def triage_with_openai_batched(
    client: OpenAI,
    config: Config,
    candidates: list[CandidatePaper],
    model_org_text: str,
    *,
    allow_zero_included: bool = False,
    relaxed_recovery: bool = False,
    batch_size: int = 80,
    shortlist_target: int | None = None,
    max_batch_retries: int = 2,
) -> TriageOutput:
    """
    Executa a triagem principal em lotes menores e, ao final, consolida os candidatos
    promissores em uma rodada global de desempate/ordenação.

    Objetivo:
    - reduzir o tamanho do prompt por chamada;
    - diminuir omissões de paper_id na resposta estruturada;
    - estabilizar tempo e cobertura da triagem em conjuntos muito grandes.
    """
    candidates = sort_candidates_for_triage(candidates, config, relaxed_recovery=relaxed_recovery)

    if len(candidates) <= batch_size:
        return triage_with_openai(
            client,
            config,
            candidates,
            model_org_text,
            allow_zero_included=allow_zero_included,
            relaxed_recovery=relaxed_recovery,
        )

    if shortlist_target is None:
        shortlist_target = max(config.quantidade_selecionados * 3, config.quantidade_selecionados + 3, 8)

    batch_shortlist_quota = max(config.quantidade_selecionados, min(shortlist_target, batch_size))
    batch_shortlist_quota = max(1, batch_shortlist_quota)

    reduced_pool: list[CandidatePaper] = []
    seen_ids: set[str] = set()
    batches = _chunked(candidates, batch_size)
    total_batches = len(batches)
    checkpoint_path = config.output_dir / f"{config.prefixo}_triagem_lotes_checkpoint.json"
    checkpoint_payload: dict[str, Any] = {
        "status": "running",
        "timestamp": datetime.now().isoformat(),
        "total_candidates": len(candidates),
        "batch_size": batch_size,
        "total_batches": total_batches,
        "shortlist_target": shortlist_target,
        "batch_shortlist_quota": batch_shortlist_quota,
        "completed_batches": 0,
        "reduced_pool_size": 0,
        "reduced_pool_ids": [],
        "batches": [],
    }

    emit_progress(
        "[ANDAMENTO] Triagem principal será dividida em %s lote(s) de até %s candidatos; até %s candidato(s) por lote seguirão para consolidação global.",
        total_batches,
        batch_size,
        batch_shortlist_quota,
    )
    emit_progress("[ANDAMENTO] Checkpoint da triagem em lotes: %s", checkpoint_path)
    save_triage_batch_checkpoint(checkpoint_path, checkpoint_payload)

    for batch_idx, batch in enumerate(batches, start=1):
        batch_started_at = time.perf_counter()
        batch_config = replace(config, quantidade_selecionados=min(batch_shortlist_quota, len(batch)))
        batch_record: dict[str, Any] = {
            "batch_index": batch_idx,
            "total_batches": total_batches,
            "candidate_count": len(batch),
            "status": "running",
            "attempts": [],
        }
        checkpoint_payload["batches"].append(batch_record)
        save_triage_batch_checkpoint(checkpoint_path, checkpoint_payload)

        batch_triage: TriageOutput | None = None
        last_error: Exception | None = None
        for attempt in range(1, max_batch_retries + 1):
            attempt_started_at = time.perf_counter()
            emit_progress(
                "[ANDAMENTO] Lote %s/%s iniciado (%s candidato(s)) | tentativa %s/%s.",
                batch_idx,
                total_batches,
                len(batch),
                attempt,
                max_batch_retries,
            )
            try:
                batch_triage = triage_with_openai(
                    client,
                    batch_config,
                    batch,
                    model_org_text,
                    allow_zero_included=True,
                    relaxed_recovery=relaxed_recovery,
                )
                if not triage_has_included(batch_triage):
                    logging.warning(
                        "Lote %s/%s não incluiu candidatos na primeira passagem; aplicando recuperação metodológica local do lote.",
                        batch_idx,
                        total_batches,
                    )
                    batch_triage = triage_with_openai(
                        client,
                        batch_config,
                        batch,
                        model_org_text,
                        allow_zero_included=True,
                        relaxed_recovery=True,
                    )
                attempt_elapsed = round(time.perf_counter() - attempt_started_at, 3)
                batch_record["attempts"].append({
                    "attempt": attempt,
                    "status": "success",
                    "elapsed_seconds": attempt_elapsed,
                })
                emit_progress(
                    "[ANDAMENTO] Lote %s/%s concluído em %.1fs | tentativa %s/%s.",
                    batch_idx,
                    total_batches,
                    attempt_elapsed,
                    attempt,
                    max_batch_retries,
                )
                last_error = None
                break
            except Exception as exc:
                last_error = exc
                attempt_elapsed = round(time.perf_counter() - attempt_started_at, 3)
                batch_record["attempts"].append({
                    "attempt": attempt,
                    "status": "error",
                    "elapsed_seconds": attempt_elapsed,
                    "error": str(exc),
                })
                logging.warning(
                    "[ANDAMENTO] Lote %s/%s falhou após %.1fs | tentativa %s/%s | erro: %s",
                    batch_idx,
                    total_batches,
                    attempt_elapsed,
                    attempt,
                    max_batch_retries,
                    exc,
                )
                save_triage_batch_checkpoint(checkpoint_path, checkpoint_payload)
                if attempt < max_batch_retries:
                    retry_wait = min(5.0 * attempt, 15.0)
                    logging.info(
                        "[ANDAMENTO] Retry do lote %s/%s agendado após %.1fs.",
                        batch_idx,
                        total_batches,
                        retry_wait,
                    )
                    time.sleep(retry_wait)
        if batch_triage is None:
            batch_record["status"] = "failed"
            batch_record["elapsed_seconds"] = round(time.perf_counter() - batch_started_at, 3)
            checkpoint_payload["status"] = "failed"
            checkpoint_payload["failed_batch"] = batch_idx
            checkpoint_payload["error"] = str(last_error) if last_error else "Erro desconhecido no lote."
            save_triage_batch_checkpoint(checkpoint_path, checkpoint_payload)
            raise RuntimeError(
                f"Lote {batch_idx}/{total_batches} falhou após {max_batch_retries} tentativa(s): {last_error}"
            )

        batch_seed_evaluations, _batch_seed_profile = get_candidate_seed_evaluations(batch, config, relaxed_recovery=relaxed_recovery)
        ordered_batch_decisions = sorted(
            batch_triage.decisions,
            key=lambda x: (
                0 if x.stage == "incluido" else 1,
                -((x.aderencia_score * 0.68) + (batch_seed_evaluations.get(x.paper_id, {}).get("total", 0) * 0.32)),
                -(batch_seed_evaluations.get(x.paper_id, {}).get("components", {}).get("tema", 0)),
                x.ranking,
                x.paper_id,
            ),
        )
        batch_by_id = {c.paper_id: c for c in batch}

        preferred_ids: list[str] = []
        for decision in ordered_batch_decisions:
            if len(preferred_ids) >= batch_shortlist_quota:
                break
            if decision.paper_id not in batch_by_id:
                continue
            if decision.stage == "incluido" or decision.alinhado_triada:
                preferred_ids.append(decision.paper_id)

        if len(preferred_ids) < batch_shortlist_quota:
            for decision in ordered_batch_decisions:
                if len(preferred_ids) >= batch_shortlist_quota:
                    break
                if decision.paper_id not in batch_by_id or decision.paper_id in preferred_ids:
                    continue
                preferred_ids.append(decision.paper_id)

        forwarded_count = 0
        for pid in preferred_ids:
            if pid in seen_ids:
                continue
            cand = batch_by_id.get(pid)
            if cand is None:
                continue
            reduced_pool.append(cand)
            seen_ids.add(pid)
            forwarded_count += 1

        batch_elapsed = round(time.perf_counter() - batch_started_at, 3)
        batch_record["status"] = "completed"
        batch_record["elapsed_seconds"] = batch_elapsed
        batch_record["forwarded_ids"] = preferred_ids
        batch_record["forwarded_count"] = forwarded_count
        checkpoint_payload["completed_batches"] = batch_idx
        checkpoint_payload["reduced_pool_size"] = len(reduced_pool)
        checkpoint_payload["reduced_pool_ids"] = [c.paper_id for c in reduced_pool]
        checkpoint_payload["last_completed_batch"] = batch_idx
        checkpoint_payload["timestamp"] = datetime.now().isoformat()
        save_triage_batch_checkpoint(checkpoint_path, checkpoint_payload)
        emit_progress(
            "[ANDAMENTO] Checkpoint salvo após lote %s/%s | pool reduzido acumulado=%s.",
            batch_idx,
            total_batches,
            len(reduced_pool),
        )

    if not reduced_pool:
        logging.warning(
            "A consolidação em lotes não produziu pool reduzido; voltando para triagem direta do conjunto completo."
        )
        checkpoint_payload["status"] = "fallback_full_direct"
        checkpoint_payload["timestamp"] = datetime.now().isoformat()
        save_triage_batch_checkpoint(checkpoint_path, checkpoint_payload)
        return triage_with_openai(
            client,
            config,
            candidates,
            model_org_text,
            allow_zero_included=allow_zero_included,
            relaxed_recovery=relaxed_recovery,
        )

    logging.info(
        "Pool reduzido após triagem em lotes: %s candidato(s) (de %s originais). Rodando consolidação global final.",
        len(reduced_pool),
        len(candidates),
    )
    checkpoint_payload["status"] = "global_consolidation"
    checkpoint_payload["timestamp"] = datetime.now().isoformat()
    save_triage_batch_checkpoint(checkpoint_path, checkpoint_payload)
    final_triage = triage_with_openai(
        client,
        config,
        reduced_pool,
        model_org_text,
        allow_zero_included=allow_zero_included,
        relaxed_recovery=relaxed_recovery,
    )
    checkpoint_payload["status"] = "completed"
    checkpoint_payload["timestamp"] = datetime.now().isoformat()
    checkpoint_payload["final_pool_size"] = len(reduced_pool)
    checkpoint_payload["final_selected_ids"] = [d.paper_id for d in final_triage.decisions if d.stage == "incluido"]
    save_triage_batch_checkpoint(checkpoint_path, checkpoint_payload)
    emit_progress("[ANDAMENTO] Consolidação global concluída. Checkpoint final atualizado em %s.", checkpoint_path)
    return final_triage


def _chunked(items: list[Any], size: int) -> list[list[Any]]:
    return [items[i:i + size] for i in range(0, len(items), size)]


def save_triage_batch_checkpoint(path: Path, payload: dict[str, Any]) -> None:
    write_text(path, json.dumps(payload, ensure_ascii=False, indent=2))


def emit_progress(message: str, *args: Any) -> None:
    if args:
        try:
            formatted = message % args
        except Exception:
            formatted = message.format(*args)
    else:
        formatted = message
    logging.info(formatted)
    print(formatted, flush=True)


def complete_missing_triage_decisions(
    client: OpenAI,
    config: Config,
    parsed: TriageOutput,
    missing_candidates: list[CandidatePaper],
    model_org_text: str,
    *,
    relaxed_recovery: bool = False,
) -> tuple[list[CandidateDecision], list[str]]:
    class _MissingDecisionBatchOutput(MissingDecisionBatchOutput):
        pass

    warnings: list[str] = []
    completed: list[CandidateDecision] = []
    current_included_count = sum(1 for d in parsed.decisions if d.stage == "incluido")
    remaining_slots = max(0, config.quantidade_selecionados - current_included_count)
    included_context = [
        {
            "paper_id": d.paper_id,
            "ranking": d.ranking,
            "aderencia_score": d.aderencia_score,
            "motivo": d.motivo,
        }
        for d in sorted(parsed.decisions, key=lambda x: (x.ranking, -x.aderencia_score, x.paper_id))
        if d.stage == "incluido"
    ]
    orientacao_extra = f"\n\nOrientações complementares para o arquivo final:\n{config.texto_orientacao_extra[:8000]}" if config.texto_orientacao_extra else ""
    rigor_instruction = build_triage_rigor_instruction(config, relaxed_recovery=relaxed_recovery)

    system_prompt = textwrap.dedent(
        f"""
        Você é um assistente acadêmico especializado em triagem bibliográfica.
        Sua única tarefa aqui é complementar decisões faltantes de triagem para candidatos específicos.

        Regras obrigatórias:
        - Trabalhe apenas com os candidatos fornecidos neste lote.
        - Você DEVE devolver exatamente 1 decision para cada paper_id recebido, sem omissões e sem extras.
        - Preserve cada paper_id exatamente como fornecido.
        - Todos os candidatos devem receber stage, tipo_estudo, motivo, ranking, aderencia_score e alinhado_triada.
        - Se não houver vaga restante entre os textos incluídos, não marque novos candidatos como 'incluido'; classifique-os como 'excluido_triagem' ou 'excluido_elegibilidade'.
        - Só use stage='incluido' se ainda houver vaga restante e se o texto for claramente aderente à tríade tema-recorte-objetivo.
        - Não invente dados.
        - Faça a redação em português acadêmico claro.
        - O tema central é: {config.tema}.
        - O recorte é: {config.recorte}.
        - O objetivo da atividade é: {config.objetivo}.
        - O tipo priorizado é: {config.tipo_estudo}.

        {rigor_instruction}

        Modelo Org de referência:
        {model_org_text[:8000]}
        {orientacao_extra}
        """
    ).strip()

    base_rank = max((d.ranking for d in parsed.decisions), default=0)
    for chunk_idx, chunk in enumerate(_chunked(missing_candidates, 60), start=1):
        payload = [c.short_dict() for c in chunk]
        user_prompt = textwrap.dedent(
            f"""
            Complementar decisões de triagem para o lote {chunk_idx}.

            Contexto da triagem já produzida:
            - Quantidade desejada de textos finais: {config.quantidade_selecionados}
            - Textos já incluídos até aqui: {current_included_count}
            - Vagas restantes para novos incluídos: {remaining_slots}
            - Incluídos já existentes: {json.dumps(included_context, ensure_ascii=False, indent=2)}

            Candidatos deste lote:
            {json.dumps(payload, ensure_ascii=False, indent=2)}

            Gere apenas:
            - decisions (uma por paper_id deste lote, sem faltar nenhuma e sem adicionar IDs inexistentes)

            Regras adicionais:
            - Use ranking local consecutivo começando em {base_rank + 1}.
            - Se remaining_slots = 0, nenhum candidate deste lote pode receber stage='incluido'.
            - Se remaining_slots > 0, marque no máximo {remaining_slots} candidatos deste lote como 'incluido'.
            """
        ).strip()

        response = client.responses.parse(
            model=config.model,
            input=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            text_format=_MissingDecisionBatchOutput,
        )
        parsed_chunk = response.output_parsed
        if parsed_chunk is None:
            warnings.append(f"A IA não retornou complementação estruturada para o lote {chunk_idx}; será usado fallback documental.")
            continue
        seen_ids = set()
        chunk_ids = {c.paper_id for c in chunk}
        local_rank = base_rank
        for decision in parsed_chunk.decisions:
            if decision.paper_id not in chunk_ids or decision.paper_id in seen_ids:
                continue
            seen_ids.add(decision.paper_id)
            local_rank += 1
            stage = decision.stage
            if remaining_slots <= 0 and stage == "incluido":
                stage = "excluido_triagem"
            elif stage == "incluido":
                remaining_slots -= 1
            completed.append(CandidateDecision(
                paper_id=decision.paper_id,
                stage=stage,
                tipo_estudo=decision.tipo_estudo,
                motivo=decision.motivo,
                ranking=local_rank,
                aderencia_score=decision.aderencia_score,
                alinhado_triada=decision.alinhado_triada if stage == "incluido" else False if decision.stage == "incluido" else decision.alinhado_triada,
            ))
        base_rank = local_rank
        missing_chunk_ids = [c.paper_id for c in chunk if c.paper_id not in seen_ids]
        if missing_chunk_ids:
            warnings.append(
                "A IA ainda omitiu decisões em lote de complementação; será aplicado fallback documental aos IDs: "
                + ", ".join(missing_chunk_ids)
            )

    return completed, warnings

def save_zero_inclusion_diagnostic(output_dir: Path, prefixo: str, triage: TriageOutput, candidates: list[CandidatePaper], stage: str, logger: logging.Logger) -> Path:
    path = output_dir / f"{prefixo}_triagem_zero_incluidos_{stage}.json"
    payload = {
        "stage": stage,
        "saved_at": datetime.now().isoformat(),
        "selection_warning": triage.selection_warning,
        "selected_paper_ids": triage.selected_paper_ids,
        "decisions": [d.model_dump() for d in triage.decisions],
        "candidates": [c.short_dict() for c in candidates],
    }
    write_text(path, json.dumps(payload, ensure_ascii=False, indent=2))
    logger.warning("Triagem sem textos incluídos; diagnóstico salvo em %s", path)
    return path


def force_exploratory_selection(triage: TriageOutput, candidates: list[CandidatePaper], config: Config) -> TriageOutput:
    """Converte o candidato de maior aderência relativa em seleção exploratória."""
    candidate_ids = {c.paper_id for c in candidates}
    decisions = [d for d in triage.decisions if d.paper_id in candidate_ids]
    if not decisions:
        c = candidates[0]
        decisions = [CandidateDecision(
            paper_id=c.paper_id,
            stage="excluido_triagem",
            tipo_estudo=c.document_type or "não identificado",
            motivo="Candidato disponível para seleção exploratória por ausência de decisão válida na triagem.",
            ranking=1,
            aderencia_score=1,
            alinhado_triada=False,
        )]
    top = sorted(decisions, key=lambda d: (d.ranking, -d.aderencia_score, d.paper_id))[0]
    warning = (
        "Seleção exploratória aplicada: as rodadas de triagem estrita e relaxada não encontraram texto plenamente aderente. "
        "Para não interromper a atividade, foi selecionado o candidato de maior aderência relativa entre os textos recuperados, "
        "com registro explícito desta limitação metodológica. Recomenda-se revisar/ampliar a estratégia de busca caso a atividade exija aderência plena."
    )
    new_decisions: list[CandidateDecision] = []
    for d in sorted(triage.decisions, key=lambda x: (x.ranking, -x.aderencia_score, x.paper_id)):
        if d.paper_id == top.paper_id:
            new_decisions.append(CandidateDecision(
                paper_id=d.paper_id,
                stage="incluido",
                tipo_estudo=d.tipo_estudo,
                motivo="Incluído como melhor candidato relativo em seleção exploratória. " + d.motivo,
                ranking=1,
                aderencia_score=max(d.aderencia_score, 1),
                alinhado_triada=True,
            ))
        else:
            new_decisions.append(CandidateDecision(
                paper_id=d.paper_id,
                stage=d.stage if d.stage != "incluido" else "excluido_triagem",
                tipo_estudo=d.tipo_estudo,
                motivo=d.motivo,
                ranking=d.ranking + (1 if d.ranking == 1 else 0),
                aderencia_score=d.aderencia_score,
                alinhado_triada=False if d.stage == "incluido" else d.alinhado_triada,
            ))
    ordered = sorted(new_decisions, key=lambda d: (0 if d.paper_id == top.paper_id else 1, d.ranking, -d.aderencia_score, d.paper_id))
    reranked = [CandidateDecision(
        paper_id=d.paper_id,
        stage=d.stage,
        tipo_estudo=d.tipo_estudo,
        motivo=d.motivo,
        ranking=i,
        aderencia_score=d.aderencia_score,
        alinhado_triada=d.alinhado_triada,
    ) for i, d in enumerate(ordered, start=1)]
    return TriageOutput(
        pergunta_orientadora=triage.pergunta_orientadora,
        introducao=triage.introducao,
        base_logica_busca=triage.base_logica_busca,
        criterios_inclusao=triage.criterios_inclusao,
        criterios_exclusao=triage.criterios_exclusao,
        observacao_metodologica=(triage.observacao_metodologica + "\n\n" + warning).strip(),
        selected_paper_ids=[top.paper_id],
        selected_papers_justification=warning,
        selection_warning=warning,
        decisions=reranked,
    )


def analyze_selected_paper(client: OpenAI, config: Config, selected: CandidatePaper, model_org_text: str) -> PaperAnalysisOutput:
    class _PaperAnalysisOutput(PaperAnalysisOutput):
        pass

    orientacao_extra = f"\n\nOrientações complementares para o arquivo final:\n{config.texto_orientacao_extra[:12000]}" if config.texto_orientacao_extra else ""

    if not selected.pdf_url and not (config.permitir_textos_nao_publicos and candidate_has_non_public_access_reference(selected)):
        raise RuntimeError("O artigo selecionado não possui link verificável para download do texto completo nem referência não pública utilizável.")

    local_pdf_path = Path(selected.downloaded_pdf_path) if selected.downloaded_pdf_path else None
    if local_pdf_path is None or not local_pdf_path.exists():
        cache_dir = config.output_dir / f"{config.prefixo}_fulltext_cache"
        selected = download_candidate_pdf(selected, cache_dir)
        local_pdf_path = Path(selected.downloaded_pdf_path) if selected.downloaded_pdf_path else None
    if local_pdf_path is None or not local_pdf_path.exists():
        if config.permitir_textos_nao_publicos and candidate_has_non_public_access_reference(selected):
            return fallback_paper_analysis(selected)
        raise RuntimeError(selected.full_text_note or "O artigo selecionado não pôde ser baixado localmente para leitura.")

    try:
        selected = enrich_candidate_from_local_pdf(selected, max_chars=120000)
        extracted_pdf_text = selected.extracted_pdf_text or read_orientation_file(local_pdf_path, max_chars=120000)
    except Exception as exc:
        raise RuntimeError(f"O artigo selecionado foi baixado, mas não pôde ser lido localmente: {exc}") from exc

    content: list[dict] = [
        {
            "type": "input_text",
            "text": textwrap.dedent(
                f"""
                Analise o artigo selecionado para compor uma atividade acadêmica em português.
                Tema central: {config.tema}
                Recorte: {config.recorte}
                Objetivo: {config.objetivo}
                Bases consultadas: {config.bases_label}
                Estilo de citações e referências bibliográficas: {config.estilo_citacao}

                Metadados do artigo:
                {json.dumps(selected.short_dict(), ensure_ascii=False, indent=2)}

                Use como referência de tom e organização este modelo Org:
                {model_org_text[:14000]}
                {orientacao_extra}

                Gere os campos estruturados solicitados, mantendo rigor metodológico.
                O campo referencia_completa deve vir formatado estritamente no estilo {config.estilo_citacao}.
                O campo resumo_abstract deve trazer o abstract/resumo do texto; se houver abstract explícito no PDF, priorize-o.
                O artigo selecionado só pode chegar a esta etapa se houver link verificável para download do texto completo.

                Abstract/resumo previamente extraído do PDF (se disponível):
                {selected.extracted_abstract or selected.abstract or 'não disponível'}

                Texto extraído do PDF baixado localmente (trecho):
                {extracted_pdf_text[:100000]}
                """
            ).strip(),
        }
    ]

    response = client.responses.parse(
        model=config.model,
        input=[{"role": "user", "content": content}],
        text_format=_PaperAnalysisOutput,
    )
    parsed = response.output_parsed
    if parsed is None:
        raise RuntimeError("A OpenAI não retornou análise estruturada do artigo.")
    return parsed


def synthesize_selected_papers(client: OpenAI, config: Config, selected_candidates: list[CandidatePaper], analyses_by_id: dict[str, PaperAnalysisOutput], model_org_text: str) -> str:
    class _MultiPaperSynthesisOutput(MultiPaperSynthesisOutput):
        pass

    orientacao_extra = f"\n\nOrientações complementares para o arquivo final:\n{config.texto_orientacao_extra[:12000]}" if config.texto_orientacao_extra else ""
    payload = []
    for idx, cand in enumerate(selected_candidates, start=1):
        analysis = analyses_by_id.get(cand.paper_id)
        payload.append({
            "ordem": idx,
            "titulo": cand.title,
            "ano": cand.year,
            "autores": cand.authors,
            "resumo": get_candidate_abstract(cand, analysis),
            "problema_objetivo": analysis.problema_objetivo if analysis else "",
            "argumento_central": analysis.argumento_central if analysis else "",
            "desenho_pesquisa": analysis.desenho_pesquisa if analysis else "",
            "principais_achados": analysis.principais_achados if analysis else "",
            "contribuicao": analysis.contribuicao_estudo if analysis else "",
        })

    prompt = textwrap.dedent(f"""
    Você é um assistente acadêmico especializado em revisão de literatura em administração pública.

    Sua tarefa é redigir um texto sintético e integrador, em português acadêmico, que articule TODOS os textos selecionados na revisão.

    Regras obrigatórias:
    - sintetize conjuntamente todos os estudos selecionados, e não apenas o primeiro;
    - destaque convergências, diferenças de foco, complementaridades e lacunas;
    - conecte os estudos à tríade tema-recorte-objetivo desta atividade;
    - produza um texto corrido coeso, adequado para a seção final de síntese;
    - não invente resultados; baseie-se apenas nas informações fornecidas.

    Dados da atividade:
    - Tema: {config.tema}
    - Recorte: {config.recorte}
    - Objetivo: {config.objetivo}
    - Estilo bibliográfico: {config.estilo_citacao}
    {orientacao_extra}

    Textos selecionados (ordem final):
    {json.dumps(payload, ensure_ascii=False, indent=2)}

    Modelo Org de referência:
    {model_org_text[:12000]}
    """).strip()

    response = client.responses.parse(
        model=config.model,
        input=[{"role": "user", "content": prompt}],
        text_format=_MultiPaperSynthesisOutput,
    )
    parsed = response.output_parsed
    if parsed is None:
        raise RuntimeError("A OpenAI não retornou a síntese integrada dos textos selecionados.")
    return parsed.texto_sintese_integrada.strip()


def generate_empirical_project_with_openai(client: OpenAI, config: Config, model_org_text: str) -> EmpiricalProjectOutput:
    class _EmpiricalProjectOutput(EmpiricalProjectOutput):
        pass

    orientacao_extra = f"\n\nOrientações complementares para o arquivo final:\n{config.texto_orientacao_extra[:12000]}" if config.texto_orientacao_extra else ""

    prompt = textwrap.dedent(
        f"""
        Você é um assistente acadêmico especializado em metodologia de pesquisa em administração pública.

        Sua tarefa é construir uma proposta de pesquisa empírica completa, em português acadêmico, a partir dos dados fornecidos.

        Regras obrigatórias:
        - trate a atividade como proposta de pesquisa empírica, não como revisão sistemática;
        - formule o problema de pesquisa na forma de uma pergunta;
        - apresente contextualização breve que justifique a relevância do problema;
        - proponha formas plausíveis de condução da pesquisa;
        - sugira possibilidades de coleta e análise de dados compatíveis com o tipo de estudo priorizado;
        - apresente hipótese ou resposta teórica ao problema;
        - elabore um modelo teórico conectando conceitos e variáveis envolvidas;
        - escreva em português acadêmico claro;
        - use o modelo Org apenas como referência de tom e organização formal.

        Dados da atividade:
        - Disciplina: {config.disciplina}
        - Professor(a): {config.professor}
        - Curso: {config.curso}
        - Tema: {config.tema}
        - Recorte: {config.recorte}
        - Objetivo da atividade: {config.objetivo}
        - Tipo de estudo empírico priorizado: {config.tipo_estudo}
        - Idiomas aceitáveis: {', '.join(config.idiomas)}
        - Palavras-chave e conceitos centrais: {', '.join(config.palavras_chave)}
        {orientacao_extra}

        Modelo Org de referência:
        {model_org_text[:14000]}
        """
    ).strip()

    response = client.responses.parse(
        model=config.model,
        input=[{"role": "user", "content": prompt}],
        text_format=_EmpiricalProjectOutput,
    )
    parsed = response.output_parsed
    if parsed is None:
        raise RuntimeError("A OpenAI não retornou a proposta empírica estruturada.")
    return parsed


def compute_prisma_counts(audit: SearchAudit, triage: TriageOutput) -> PrismaCounts:
    excluded_screening = sum(1 for d in triage.decisions if d.stage == "excluido_triagem")
    included = sum(1 for d in triage.decisions if d.stage == "incluido")
    excluded_full = sum(1 for d in triage.decisions if d.stage == "excluido_elegibilidade")
    full_text_assessed = included + excluded_full
    full_text_sought = full_text_assessed
    not_retrieved = 0
    return PrismaCounts(
        identified=audit.identified_total,
        removed_pre=audit.duplicates_removed + audit.other_removed,
        duplicates_removed=audit.duplicates_removed,
        other_removed=audit.other_removed,
        screened=audit.screened_total,
        excluded_screening=excluded_screening,
        full_text_sought=full_text_sought,
        not_retrieved=not_retrieved,
        full_text_assessed=full_text_assessed,
        excluded_full_text=excluded_full,
        included_qualitative=included,
    )


def author_list(authors: list[str]) -> str:
    return "; ".join(authors) if authors else "Autor(es) não informado(s)"


def latex_escape(s: str) -> str:
    replacements = {
        "\\": r"\\textbackslash{}",
        "&": r"\\&",
        "%": r"\\%",
        "$": r"\\$",
        "#": r"\\#",
        "_": r"\\_",
        "{": r"\\{",
        "}": r"\\}",
        "~": r"\\textasciitilde{}",
        "^": r"\\textasciicircum{}",
    }
    return "".join(replacements.get(c, c) for c in s)


def build_source_summary(audit: SearchAudit) -> str:
    lines = []
    for item in audit.per_source:
        lines.append(f"- {SOURCE_LABELS.get(item.source, item.source)}: *n = {item.retrieved}* registros recuperados")
        lines.append(f"  - Query usada: ={item.query}=")
    return "\n".join(lines)


def extract_download_exclusion_entries(warnings: list[str]) -> list[tuple[str, str]]:
    entries: list[tuple[str, str]] = []
    prefix = "Excluído após falha no download local do PDF:"
    for item in warnings or []:
        if not item.startswith(prefix):
            continue
        payload = item[len(prefix):].strip()
        if ". Motivo: " in payload:
            title, reason = payload.rsplit(". Motivo: ", 1)
        else:
            title, reason = payload, "Falha no download local do PDF."
        entries.append((title.strip(), reason.strip()))
    return entries


def build_download_exclusion_block(download_entries: list[tuple[str, str]]) -> str:
    if not download_entries:
        return (
            "Não houve exclusões adicionais por impossibilidade de download local do PDF após a triagem ranqueada."
        )
    lines = [
        f"Foram excluídos por impossibilidade de download local do PDF *n = {len(download_entries)}* textos inicialmente aderentes à tríade tema–recorte–objetivo."
    ]
    for title, reason in download_entries:
        lines.append(f"- *{title}*: {reason}")
    return "\n".join(lines)


def build_prisma_flow_text(config: Config, audit: SearchAudit, triage: TriageOutput, counts: PrismaCounts, download_entries: list[tuple[str, str]] | None = None) -> str:
    excl_triagem = [d for d in triage.decisions if d.stage == "excluido_triagem"]
    excl_eleg = [d for d in triage.decisions if d.stage == "excluido_elegibilidade"]
    lines = []
    lines.append("*** Identificação")
    lines.append(f"- Registros identificados nas bases consultadas ({config.bases_label}): *n = {counts.identified}*")
    lines.append(build_source_summary(audit))
    download_entries = download_entries or []
    lines.append(f"- Registros removidos antes da triagem: *n = {counts.removed_pre}*")
    lines.append(f"  - Duplicatas removidas: *n = {counts.duplicates_removed}*")
    lines.append(f"  - Removidos por outros motivos: *n = {counts.other_removed}*")
    if download_entries:
        lines.append(f"  - Desses, excluídos por impossibilidade de download local do PDF: *n = {len(download_entries)}*")
        for title, reason in download_entries:
            lines.append(f"    - {title}: {reason}")
    lines.append("")
    lines.append("*** Triagem")
    lines.append(f"- Registros triados por título, resumo e metadados: *n = {counts.screened}*")
    lines.append(f"- Registros excluídos na triagem: *n = {counts.excluded_screening}*")
    for d in excl_triagem:
        lines.append(f"  - {d.motivo}: *n = 1*")
    lines.append("")
    lines.append("*** Elegibilidade")
    lines.append(f"- Relatórios buscados para recuperação em texto completo: *n = {counts.full_text_sought}*")
    lines.append(f"- Relatórios não recuperados: *n = {counts.not_retrieved}*")
    lines.append(f"- Relatórios avaliados para elegibilidade: *n = {counts.full_text_assessed}*")
    lines.append(f"- Relatórios excluídos após leitura do texto completo: *n = {counts.excluded_full_text}*")
    for d in excl_eleg:
        lines.append(f"  - {d.motivo}: *n = 1*")
    lines.append("")
    lines.append("*** Inclusão")
    lines.append(f"- Estudos incluídos na síntese qualitativa final: *n = {counts.included_qualitative}*")
    return "\n".join(lines)


def build_prisma_table_latex(counts: PrismaCounts, download_failure_count: int = 0) -> str:
    rows = [
        ("Registros identificados", counts.identified),
        ("Registros removidos antes da triagem", counts.removed_pre),
        ("Exclusões por impossibilidade de download local", download_failure_count),
        ("Registros triados", counts.screened),
        ("Registros excluídos na triagem", counts.excluded_screening),
        ("Relatórios buscados para recuperação", counts.full_text_sought),
        ("Relatórios não recuperados", counts.not_retrieved),
        ("Relatórios avaliados para elegibilidade", counts.full_text_assessed),
        ("Relatórios excluídos após leitura completa", counts.excluded_full_text),
        ("Estudos incluídos na síntese qualitativa", counts.included_qualitative),
    ]
    body = "\n".join(f"#+LATEX: {latex_escape(label)} & {value} \\\\" for label, value in rows)
    return textwrap.dedent(
        fr"""
        #+NAME: tab:prisma2020
        #+CAPTION: Síntese do fluxo PRISMA 2020 aplicado à seleção do artigo.
        #+ATTR_LATEX: :center nil :float nil
        #+LATEX: \begingroup
        #+LATEX: \centering
        #+LATEX: \scriptsize
        #+LATEX: \setlength{{\tabcolsep}}{{4pt}}
        #+LATEX: \renewcommand{{\arraystretch}}{{1.15}}
        #+LATEX: \captionof{{table}}{{Síntese do fluxo PRISMA 2020 aplicado à seleção do artigo.}}
        #+LATEX: \label{{tab:prisma2020}}
        #+LATEX: \begin{{tabularx}}{{\textwidth}}{{>{{\raggedright\arraybackslash}}X >{{\raggedleft\arraybackslash}}m{{0.18\textwidth}}}}
        #+LATEX: \toprule
        #+LATEX: Etapa PRISMA 2020 & n \\
        #+LATEX: \midrule
        {body}
        #+LATEX: \bottomrule
        #+LATEX: \end{{tabularx}}
        #+LATEX: \normalsize
        #+LATEX: \endgroup
        """
    ).strip()


def condense_reason(texto: str, max_chars: int = 140) -> str:
    texto = re.sub(r"\s+", " ", (texto or "").strip())
    if not texto:
        return "—"
    primeira_frase = texto.split('. ')[0].strip()
    if primeira_frase and len(primeira_frase) <= max_chars:
        return primeira_frase.rstrip('.') + '.'
    if len(texto) <= max_chars:
        return texto
    return textwrap.shorten(texto, width=max_chars, placeholder="…")


def resolve_final_selected_candidates(triage: TriageOutput, candidates: list[CandidatePaper], analyses_by_id: dict[str, PaperAnalysisOutput] | None = None) -> tuple[list[CandidatePaper], list[str]]:
    """Resolve selected_paper_ids de forma tolerante.

    A triagem final pode referenciar IDs ausentes da lista final de candidatos
    quando houve rodadas intermediárias com remoções por falha de download,
    síntese ou análise. Esta função tenta:
      1. usar selected_paper_ids existentes em candidates;
      2. complementar com IDs presentes em analyses_by_id;
      3. complementar com candidatos marcados como incluídos nas decisões;
      4. retornar avisos em vez de quebrar com KeyError/RuntimeError.
    """
    candidate_by_id = {c.paper_id: c for c in candidates}
    analyses_by_id = analyses_by_id or {}
    selected: list[CandidatePaper] = []
    warnings: list[str] = []
    seen: set[str] = set()

    for pid in (triage.selected_paper_ids or []):
        cand = candidate_by_id.get(pid)
        if cand is None:
            warnings.append(f"selected_paper_id ausente da lista final de candidatos: {pid}")
            continue
        if pid not in seen:
            seen.add(pid)
            selected.append(cand)

    if analyses_by_id:
        for pid in analyses_by_id.keys():
            cand = candidate_by_id.get(pid)
            if cand is not None and pid not in seen:
                seen.add(pid)
                selected.append(cand)
                warnings.append(f"Candidato incluído a partir de analyses_by_id após ausência em selected_paper_ids: {pid}")

    decision_map = {d.paper_id: d for d in (triage.decisions or [])}
    included_from_decisions = [pid for pid, d in decision_map.items() if d.stage == 'incluido']
    for pid in included_from_decisions:
        cand = candidate_by_id.get(pid)
        if cand is not None and pid not in seen:
            seen.add(pid)
            selected.append(cand)
            warnings.append(f"Candidato incluído a partir das decisões finais da triagem: {pid}")

    if not selected and candidates:
        fallback = None
        for pid in (included_from_decisions + list(analyses_by_id.keys())):
            cand = candidate_by_id.get(pid)
            if cand is not None:
                fallback = cand
                break
        if fallback is None:
            fallback = candidates[0]
        selected = [fallback]
        warnings.append(
            "Nenhum selected_paper_id válido permaneceu após as rodadas intermediárias; "
            f"usando fallback documental: {fallback.paper_id}"
        )

    return selected, warnings


def build_studies_table(candidates: list[CandidatePaper], triage: TriageOutput) -> str:
    """Monta tabela final robusta mesmo quando houve rodadas intermediárias.

    A triagem final pode não conter decisões para todos os candidatos originais,
    porque o fluxo remove candidatos por falha de download, falha de análise,
    falha de síntese ou por substituição em nova rodada. Esta função nunca deve
    quebrar com KeyError por causa disso: candidatos ausentes da triagem final
    são classificados como excluídos em rodada intermediária.

    A tabela é emitida em um único bloco ``#+begin_export latex`` e usa
    o ambiente ``xltabular``, que combina quebra multipágina e colunas ``X``
    adaptativas de forma compatível. Assim, a tabela pode quebrar entre páginas
    e ainda respeitar ``\textwidth`` com colunas largas para títulos, links e
    motivos de exclusão sem misturar sintaxes incompatíveis.
    """
    decisions = {d.paper_id: d for d in (triage.decisions or [])}
    order_map = {
        "incluido": 0,
        "excluido_elegibilidade": 1,
        "excluido_triagem": 2,
        "ausente_triagem_final": 3,
    }

    def row_sort_key(c: CandidatePaper):
        d = decisions.get(c.paper_id)
        if d is None:
            return (order_map["ausente_triagem_final"], 999999, -(c.year or 0), c.title or "")
        return (order_map.get(d.stage, 4), d.ranking or 999999, -(c.year or 0), c.title or "")

    rows: list[str] = []
    for c in sorted(candidates, key=row_sort_key):
        d = decisions.get(c.paper_id)
        if d is None:
            situacao = "Excluído em rodada intermediária"
            tipo_raw = c.document_type or "não identificado"
            motivo_raw = (
                "Candidato recuperado na busca inicial, mas ausente da triagem final "
                "por remoção em rodada intermediária, normalmente por falha de download, "
                "falha de análise/síntese ou substituição por nova rodada de seleção."
            )
        else:
            situacao = {
                "incluido": "Incluído",
                "excluido_elegibilidade": "Excluído na elegibilidade",
                "excluido_triagem": "Excluído na triagem",
            }.get(d.stage, "Excluído/Não classificado")
            tipo_raw = d.tipo_estudo or c.document_type or "não identificado"
            motivo_raw = d.motivo or "Sem justificativa registrada pela triagem."

        title = latex_escape(c.title)
        authors = latex_escape(author_list(c.authors))
        year = c.year or "s.d."
        tipo = latex_escape(tipo_raw)
        motivo = latex_escape(condense_reason(motivo_raw, max_chars=150))
        bases = latex_escape(", ".join(SOURCE_LABELS.get(src, src) for src in c.sources))
        estudo = f"{authors} ({year}), {title}. " + rf"\emph{{Base(s): {bases}}}"
        row = f"{estudo} & {latex_escape(situacao)} & {tipo} & {motivo} " + "\\\\"
        row = row.replace("\n", " ").strip()
        row = re.sub(r"\s+", " ", row)
        rows.append(row)

    lines = [
        "#+NAME: tab:estudos_fluxo",
        "#+CAPTION: Classificação sintética dos estudos identificados no fluxo PRISMA 2020.",
        "#+ATTR_LATEX: :center nil :float nil",
        "#+begin_export latex",
        r"\begingroup",
        r"\scriptsize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\renewcommand{\arraystretch}{1.15}",
        r"\begin{xltabular}{\textwidth}{>{\raggedright\arraybackslash}X >{\raggedright\arraybackslash}p{0.17\textwidth} >{\raggedright\arraybackslash}p{0.16\textwidth} >{\raggedright\arraybackslash}X}",
        r"\caption{Classificação sintética dos estudos identificados no fluxo PRISMA 2020.}\label{tab:estudos_fluxo}" + "\\\\",
        r"\toprule",
        r"Estudo & Situação no fluxo & Tipo & Motivo " + "\\\\",
        r"\midrule",
        r"\endfirsthead",
        r"\toprule",
        r"Estudo & Situação no fluxo & Tipo & Motivo " + "\\\\",
        r"\midrule",
        r"\endhead",
        r"\midrule",
        r"\multicolumn{4}{r}{Continua na próxima página} " + "\\\\",
        r"\endfoot",
        r"\bottomrule",
        r"\endlastfoot",
    ]
    lines.extend(rows)
    lines.extend([
        r"\end{xltabular}",
        r"\normalsize",
        r"\endgroup",
        "#+end_export",
    ])
    return "\n".join(lines)
def build_ficha_tecnica(config: Config, titulo_trabalho: str) -> str:
    data_documento = today_pt_br()
    linhas = [
        "\\textbf{Curso}                   & " + latex_escape(config.curso) + r" \\",
        "\\textbf{Turma}                   & " + latex_escape(config.turma) + r" \\",
        "\\textbf{Pólo}                    & " + latex_escape(config.polo) + r" \\",
        "\\textbf{Disciplina}              & " + latex_escape(config.disciplina) + r" \\",
        "\\textbf{Professor}               & " + latex_escape(config.professor) + r" \\",
        "\\textbf{Aluno(s)}                & " + latex_escape(config.aluno) + r" \\",
        "\\textbf{Data}                    & " + latex_escape(data_documento) + r" \\",
        "\\textbf{Título do trabalho}      & " + latex_escape(titulo_trabalho) + r" \\",
    ]
    tabela = "\n".join(linhas)
    bloco = [
        "#+begin_export latex",
        r"\begingroup",
        r"\linespread{1}\selectfont",
        r"\begin{tcolorbox}[title=Ficha Técnica,",
        r"  colback=gray!5,colframe=gray!40,boxrule=0.4pt,sharp corners]",
        r"\begin{tblr}{rowsep=1pt,stretch=1, rows={t}, colspec={Q[l,2.8cm] X[l]}}",
        tabela,
        r"\end{tblr}",
        r"\end{tcolorbox}",
        r"\endgroup",
        "#+end_export",
    ]
    return "\n".join(bloco)


def extract_org_header_from_model(model_text: str) -> str:
    lines = []
    for line in model_text.splitlines():
        if line.startswith("* Introdução"):
            break
        if line.startswith("#+"):
            lines.append(line)

    if not lines:
        lines = [
            "#+OPTIONS: toc:nil num:t H:3 ^:nil",
            "#+STARTUP: overview",
            "#+LATEX_HEADER: \\usepackage{fgv-header}",
            "#+LATEX_HEADER: \\usepackage{float}",
            "#+LATEX_HEADER: \\usepackage{graphicx}",
            "#+LATEX_HEADER: \\usepackage{caption}",
        ]

    required_headers = [
        "#+LATEX_HEADER: \\usepackage{graphicx}",
        "#+LATEX_HEADER: \\usepackage{float}",
        "#+LATEX_HEADER: \\usepackage{caption}",
        "#+LATEX_HEADER: \\usepackage{booktabs}",
        "#+LATEX_HEADER: \\usepackage{tabularx}",
        "#+LATEX_HEADER: \\usepackage{array}",
        "#+LATEX_HEADER: \\usepackage{longtable}",
        "#+LATEX_HEADER: \\usepackage{xltabular}",
        "#+LATEX_HEADER: \\usepackage{xurl}",
        "#+LATEX_HEADER: \\setlength{\\emergencystretch}{3em}",
        "#+LATEX_HEADER: \\Urlmuskip=0mu plus 2mu",
        "#+LATEX_HEADER: \\sloppy",
    ]
    existing = set(lines)
    for header in required_headers:
        if header not in existing:
            lines.append(header)
    return "\n".join(lines).strip()


def citation_style_to_cite_export(style: str) -> str:
    style = normalize_citation_style(style)
    mapping = {
        "ABNT": "#+CITE_EXPORT: biblatex backend=biber,style=abnt,sortcites=true,sorting=nyt",
        "APA": "#+CITE_EXPORT: biblatex backend=biber,style=apa,sortcites=true,sorting=nyt,giveninits=true,maxcitenames=2,maxbibnames=20,uniquelist=minyear",
        "Chicago": "#+CITE_EXPORT: biblatex backend=biber,style=chicago-authordate,sortcites=true,sorting=nyt",
        "MLA": "#+CITE_EXPORT: biblatex backend=biber,style=mla,sortcites=true,sorting=nyt",
        "Vancouver": "#+CITE_EXPORT: biblatex backend=biber,style=vancouver,sortcites=true,sorting=none",
    }
    return mapping.get(style, mapping["ABNT"])


def extract_bibliography_line(model_text: str) -> str:
    for line in model_text.splitlines():
        if line.strip().lower().startswith("#+bibliography:"):
            return line.strip()
    return "#+BIBLIOGRAPHY: referencias.bib"


def sanitize_model_header(header: str) -> str:
    cleaned: list[str] = []
    blocked_substrings = [
        r"\usepapercover",
        r"\usepackage{fgv-header}",
        r"\usepackage{svg}",
        r"\institution{",
        r"\programname{",
        r"\coursename{",
        r"\disciplinename{",
        r"\professorname{",
        r"\cityname{",
        r"\papertype{",
        r"\covernote{",
    ]
    for line in header.splitlines():
        stripped = line.strip()
        lowered = stripped.lower()
        if lowered.startswith("#+title:") or lowered.startswith("#+author:") or lowered.startswith("#+date:"):
            continue
        if any(item in stripped for item in blocked_substrings):
            continue
        cleaned.append(line)
    return "\n".join(cleaned).strip()


def build_fgv_report_header_lines(logo_path: Path | str) -> list[str]:
    logo_file = Path(logo_path).expanduser() if str(logo_path).strip() else Path(DEFAULT_FGV_LOGO_PATH).expanduser()
    logo_exists = logo_file.exists()
    logo_str = logo_file.as_posix()
    logo_include = rf"\includegraphics[height=0.95cm]{{{logo_str}}}" if logo_exists else r"\rule{0pt}{0.95cm}"
    return [
        r"#+LATEX_HEADER: \definecolor{FGVHeaderBlueDark}{HTML}{003A70}",
        r"#+LATEX_HEADER: \definecolor{FGVHeaderBlueMid}{HTML}{005AA9}",
        r"#+LATEX_HEADER: \definecolor{FGVHeaderBlueLight}{HTML}{66A9E0}",
        r"#+LATEX_HEADER: \setlength{\headheight}{48pt}",
        r"#+LATEX_HEADER: \setlength{\headsep}{12pt}",
        rf"#+LATEX_HEADER: \newcommand{{\FGVHeaderLogoInclude}}{{{logo_include}}}",
        r"#+LATEX_HEADER: \newcommand{\FGVHeaderGradientRule}{\begin{tikzpicture}[baseline=(current bounding box.center)]\shade[left color=FGVHeaderBlueDark,middle color=FGVHeaderBlueMid,right color=FGVHeaderBlueLight] (0,0) rectangle (\headwidth,1.2pt);\end{tikzpicture}}",
        r"#+LATEX_HEADER: \newcommand{\FGVHeaderBlock}{\begin{minipage}[b]{\headwidth}\raggedright \FGVHeaderLogoInclude\par\vspace{0.18em}\noindent\FGVHeaderGradientRule\end{minipage}}",
        r"#+LATEX_HEADER: \fancypagestyle{fgvreportstyle}{%",
        r"#+LATEX_HEADER: \fancyhf{}%",
        r"#+LATEX_HEADER: \fancyhead[L]{\makebox[\headwidth][l]{\FGVHeaderBlock}}%",
        r"#+LATEX_HEADER: \fancyhead[C]{}%",
        r"#+LATEX_HEADER: \fancyhead[R]{}%",
        r"#+LATEX_HEADER: \renewcommand{\headrulewidth}{0pt}%",
        r"#+LATEX_HEADER: \fancyfoot[C]{\thepage}%",
        r"#+LATEX_HEADER: }",
        r"#+LATEX_HEADER: \fancypagestyle{plain}{%",
        r"#+LATEX_HEADER: \fancyhf{}%",
        r"#+LATEX_HEADER: \fancyhead[L]{\makebox[\headwidth][l]{\FGVHeaderBlock}}%",
        r"#+LATEX_HEADER: \fancyhead[C]{}%",
        r"#+LATEX_HEADER: \fancyhead[R]{}%",
        r"#+LATEX_HEADER: \renewcommand{\headrulewidth}{0pt}%",
        r"#+LATEX_HEADER: \fancyfoot[C]{\thepage}%",
        r"#+LATEX_HEADER: }",
        r"#+LATEX_HEADER: \AtBeginDocument{\pagestyle{fgvreportstyle}\thispagestyle{fgvreportstyle}}",
    ]


def prepare_model_header(model_org_text: str, estilo_citacao: str, bib_filename: str, fgv_logo_path: Path | str, include_bibliography: bool = True) -> str:
    header = sanitize_model_header(extract_org_header_from_model(model_org_text))
    parts: list[str] = []
    for p in header.splitlines():
        lowered = p.strip().lower()
        if lowered.startswith("#+cite_export:") or lowered.startswith("#+bibliography:") or lowered.startswith("#+print_bibliography:"):
            continue
        if p.strip():
            parts.append(p)
    parts.extend(build_fgv_report_header_lines(fgv_logo_path))
    if include_bibliography:
        parts.append(citation_style_to_cite_export(estilo_citacao))
        parts.append(f"#+BIBLIOGRAPHY: {bib_filename}")
    return "\n".join(parts).strip()


def bibtex_escape(value: str | None) -> str:
    if not value:
        return ""
    value = value.replace('\\', r'\textbackslash{}')
    for old, new in [("{", r"\{"), ("}", r"\}"), ("&", r"\&"), ("%", r"\%"), ("#", r"\#")]:
        value = value.replace(old, new)
    return value


def make_bibtex_key(candidate: CandidatePaper) -> str:
    surname = "anon"
    if candidate.authors:
        first = candidate.authors[0].strip()
        if first:
            surname = slugify(first.split()[-1]) or "anon"
    year = str(candidate.year or "nodate")
    first_word = slugify((candidate.title or "paper").split()[0]) or "paper"
    return f"{surname}{year}{first_word}"


def build_bibtex_for_candidate(candidate: CandidatePaper) -> tuple[str, str]:
    key = make_bibtex_key(candidate)
    authors = " and ".join(a.strip() for a in candidate.authors if a and a.strip()) or "Autor desconhecido"
    entry_type = "article" if candidate.venue else "misc"
    fields: list[tuple[str, str]] = [
        ("author", authors),
        ("title", candidate.title or "Sem título"),
    ]
    if candidate.venue:
        fields.append(("journaltitle", candidate.venue))
    if candidate.year:
        fields.append(("year", str(candidate.year)))
    if candidate.publication_date:
        fields.append(("date", candidate.publication_date))
    if candidate.doi:
        fields.append(("doi", candidate.doi))
    if candidate.url:
        fields.append(("url", candidate.url))
    if candidate.pdf_url and candidate.pdf_url != candidate.url:
        fields.append(("url", candidate.pdf_url))
    body = "\n".join(f"  {name} = {{{bibtex_escape(value)}}}," for name, value in fields if value)
    return key, f"@{entry_type}{{{key},\n{body}\n}}"


def build_static_prisma_bibtex() -> tuple[str, str]:
    key = "prisma2020statement"
    entry = """@online{prisma2020statement,
  author = {Page, Matthew J. and McKenzie, Joanne E. and Bossuyt, Patrick M. and Boutron, Isabelle and Hoffmann, Tammy C. and Mulrow, Cynthia D. and Shamseer, Larissa and Tetzlaff, Jennifer M. and Akl, Elie A. and Brennan, Sue E. and Chou, Roger and Glanville, Julie and Grimshaw, Jeremy M. and Hróbjartsson, Asbjørn and Lalu, Manoj M. and Li, Tianjing and Loder, Elizabeth W. and Mayo-Wilson, Evan and McDonald, Steve and McGuinness, Luke A. and Stewart, Lesley A. and Thomas, James and Tricco, Andrea C. and Welch, Vivian A. and Whiting, Penny and Moher, David},
  title = {The PRISMA 2020 statement: An updated guideline for reporting systematic reviews},
  year = {2021},
  url = {https://www.prisma-statement.org/prisma-2020},
  note = {Acesso em: %s}
}""" % bibtex_escape(today_pt_br())
    return key, entry


def save_bib_file(output_dir: Path, prefixo: str, selected_candidates: list[CandidatePaper]) -> tuple[Path, dict[str, str], str]:
    bib_path = output_dir / f"{prefixo}.bib"
    entries: list[str] = []
    selected_keys: dict[str, str] = {}
    seen_keys: set[str] = set()
    unique_selected_candidates: list[CandidatePaper] = []
    seen_candidate_ids: set[str] = set()
    for cand in selected_candidates:
        if cand.paper_id in seen_candidate_ids:
            continue
        seen_candidate_ids.add(cand.paper_id)
        unique_selected_candidates.append(cand)
    for cand in unique_selected_candidates:
        key, entry = build_bibtex_for_candidate(cand)
        base_key = key
        i = 2
        while key in seen_keys:
            key = f"{base_key}{i}"
            i += 1
        seen_keys.add(key)
        if key != base_key:
            entry = re.sub(rf"^@([A-Za-z]+)\{{{re.escape(base_key)},", rf"@\1{{{key},", entry, count=1)
        selected_keys[cand.paper_id] = key
        entries.append(entry.strip())
    prisma_key, prisma_entry = build_static_prisma_bibtex()
    entries.append(prisma_entry.strip())
    write_text(bib_path, "\n\n".join(entries) + "\n")
    return bib_path, selected_keys, prisma_key


def normalize_org_text(text: str) -> str:
    fixed_lines: list[str] = []
    for raw in text.splitlines():
        stripped = raw.lstrip()
        if stripped.startswith("#+") or stripped.startswith("*"):
            fixed_lines.append(stripped)
        else:
            fixed_lines.append(raw.rstrip())
    fixed = "\n".join(fixed_lines)
    fixed = fixed.replace("#+begin_export latex\n#+end_export\n", "")
    return fixed.strip() + "\n"


def build_org_document(config: Config, model_org_text: str, triage: TriageOutput, analyses_by_id: dict[str, PaperAnalysisOutput],
                       synthesis_text: str, candidates: list[CandidatePaper], audit: SearchAudit, counts: PrismaCounts,
                       figure_pdf_filename: str, bib_filename: str, selected_bib_keys: dict[str, str], prisma_bib_key: str) -> str:
    selected_candidates, selected_resolution_warnings = resolve_final_selected_candidates(triage, candidates, analyses_by_id)
    titulo_trabalho = (config.titulo_trabalho or fallback_work_title(config)).strip()
    header = prepare_model_header(model_org_text, config.estilo_citacao, bib_filename, config.fgv_logo_path)
    ficha = build_ficha_tecnica(config, titulo_trabalho)
    download_exclusion_entries = extract_download_exclusion_entries(audit.warnings)
    prisma_text = build_prisma_flow_text(config, audit, triage, counts, download_exclusion_entries)
    prisma_table = build_prisma_table_latex(counts, len(download_exclusion_entries))
    studies_table = build_studies_table(candidates, triage)

    resumo_section = ["* Textos selecionados"]
    if triage.selection_warning:
        resumo_section.extend(["** Aviso sobre o limite de seleção", triage.selection_warning.strip()])
    for idx, cand in enumerate(selected_candidates, start=1):
        bib_key = selected_bib_keys.get(cand.paper_id, "")
        label = f"Texto selecionado {idx}"
        analysis = analyses_by_id.get(cand.paper_id)
        resumo_section.extend([
            f"** {label}",
            f"*** Referência do estudo",
            (f"A referência do estudo selecionado corresponde a [cite:@{bib_key}]." if bib_key else "Referência bibliográfica registrada no arquivo .bib do trabalho."),
            ((analysis.referencia_completa.strip() if analysis else f"{author_list(cand.authors)} ({cand.year or 's.d.'}). {cand.title}.")),
            "*** Link para o texto completo ou registro",
            (f"[[{cand.pdf_url}][Download do PDF]]" if cand.pdf_url else (f"[[{cand.url}][Abrir registro/landing page]]" if cand.url else "Link de acesso não disponível.")),
            "*** Resumo/abstract do texto",
            get_candidate_abstract(cand, analysis),
        ])
        if analysis and config.incluir_analise_detalhada_ia:
            resumo_section.extend([
                "*** Problema e objetivo de pesquisa",
                analysis.problema_objetivo.strip(),
                "*** Argumento central",
                analysis.argumento_central.strip(),
                "*** Desenho de pesquisa",
                analysis.desenho_pesquisa.strip(),
                "*** Principais achados",
                analysis.principais_achados.strip(),
                "*** Justificativa da seleção final",
                analysis.justificativa_selecao_final.strip(),
                "*** Contribuição do estudo para o tema",
                analysis.contribuicao_estudo.strip(),
            ])

    warnings_block = ""
    if audit.warnings:
        warnings_block = "\n".join(f"- {item}" for item in audit.warnings)
        warnings_block = f"** Observações de execução\n\n{warnings_block}"

    selected_titles_sentence = ", ".join([f'*"{c.title}"*' for c in selected_candidates])
    sections = [
        header,
        ficha,
        r"#+LATEX: \clearpage",
        "* Contextualização e problema de pesquisa",
        triage.introducao.strip(),
        "Os textos selecionados ao final do processo foram " + selected_titles_sentence + ". A seleção final se justifica porque " + triage.selected_papers_justification.strip(),
        (
            f"Também é importante registrar uma distinção metodológica. Neste trabalho, o *PRISMA 2020* foi utilizado para organizar o *fluxo da busca e da seleção* nas bases consultadas [cite:@{prisma_bib_key}]. Os textos selecionados foram analisados a partir de seus metadados e, obrigatoriamente, de *texto completo com link verificável para download*."
            if not config.permitir_textos_nao_publicos
            else
            f"Também é importante registrar uma distinção metodológica. Neste trabalho, o *PRISMA 2020* foi utilizado para organizar o *fluxo da busca e da seleção* nas bases consultadas [cite:@{prisma_bib_key}]. Os textos selecionados foram analisados prioritariamente a partir de *texto completo com link verificável para download*; quando isso não foi possível e a configuração permitiu, admitiu-se o uso de textos não públicos com *link verificável do registro ou landing page*, com análise limitada a metadados e resumo disponível."
        ),
        "** Pergunta de pesquisa da revisão",
        "#+begin_quote\n" + triage.pergunta_orientadora.strip() + "\n#+end_quote",
        "* Estratégia de busca",
        "** Bases consultadas",
        "** Critérios de inclusão",
        "\n".join(f"- {item}" for item in triage.criterios_inclusao),
        "** Critérios de exclusão",
        "\n".join(f"- {item}" for item in triage.criterios_exclusao),
    ]
    if warnings_block:
        sections.append(warnings_block)
    sections.extend([
        "* PRISMA 2020",
        "** Observação metodológica",
        triage.observacao_metodologica.strip() + (
            ("\n\nAlém das exclusões por triagem de aderência e por elegibilidade, este relatório registra explicitamente as exclusões por *impossibilidade de download local do PDF*. Sempre que um texto inicialmente selecionado não pôde ser baixado localmente, ele foi removido da seleção final e contabilizado no fluxo metodológico do PRISMA.")
            if (download_exclusion_entries and not config.permitir_textos_nao_publicos) else
            ("\n\nNesta execução, a configuração permitiu manter textos não públicos quando havia *link verificável do registro ou landing page*, mesmo sem download local do PDF. Nesses casos, a análise ficou limitada aos metadados e ao resumo disponível."
             if config.permitir_textos_nao_publicos else
             "\n\nNão houve exclusões adicionais por impossibilidade de download local do PDF nesta execução.")
        ),
        "** Exclusões adicionais por impossibilidade de download local",
        build_download_exclusion_block(download_exclusion_entries),
        "** Fluxo textual dos estudos",
        prisma_text,
        "** Tabela-resumo do fluxo PRISMA 2020",
        prisma_table,
        "** Estudos classificados no fluxo",
        studies_table,
        "#+LATEX: \\clearpage",
        "** Representação esquemática do fluxo PRISMA 2020",
        "O fluxograma PRISMA 2020 é gerado como *SVG externo* em layout compacto, exibindo apenas as contagens de cada etapa. Os motivos detalhados de exclusão permanecem no fluxo textual e nas tabelas, para evitar sobrecarga visual na figura.",
        "\n".join([
            "#+begin_export latex",
            "\\begin{center}",
            f"\\includegraphics[width=0.78\\textwidth]{{{figure_pdf_filename}}}",
            f"\\captionof{{figure}}{{Fluxograma PRISMA 2020 da seleção do artigo de revisão sobre {config.tema}.}}",
            "\\label{fig:prisma2020_fluxo}",
            "\\end{center}",
            "#+end_export",
        ]),
        *resumo_section,
    ])
    if config.incluir_sintese_integradora_ia:
        sections.extend([
            "* Síntese integradora dos textos selecionados",
            synthesis_text.strip(),
        ])
    sections.extend([
        "#+PRINT_BIBLIOGRAPHY:",
    ])
    doc = "\n\n".join(s for s in sections if s and s.strip())
    return normalize_org_text(doc)


def build_empirical_org_document(config: Config, model_org_text: str, proposal: EmpiricalProjectOutput) -> str:
    titulo_trabalho = (config.titulo_trabalho or fallback_work_title(config)).strip()
    header = prepare_model_header(model_org_text, config.estilo_citacao, "", config.fgv_logo_path, include_bibliography=False)
    ficha = build_ficha_tecnica(config, titulo_trabalho)

    objetivos_especificos = "\n".join(f"- {item}" for item in proposal.objetivos_especificos if item and item.strip()) or "- Não especificado."
    coleta = "\n".join(f"- {item}" for item in proposal.possibilidades_coleta_dados if item and item.strip()) or "- Não especificado."
    analise = "\n".join(f"- {item}" for item in proposal.possibilidades_analise_dados if item and item.strip()) or "- Não especificado."

    sections = [
        header,
        ficha,
        r"#+LATEX: \clearpage",
        "* Introdução e contextualização",
        proposal.contextualizacao.strip(),
        "* Problema de pesquisa",
        "#+begin_quote\n" + proposal.problema_pesquisa.strip() + "\n#+end_quote",
        "* Justificativa e relevância",
        proposal.justificativa_relevancia.strip(),
        "* Objetivos",
        "** Objetivo geral",
        proposal.objetivo_geral.strip(),
        "** Objetivos específicos",
        objetivos_especificos,
        "* Hipótese ou resposta teórica",
        proposal.hipotese_ou_resposta_teorica.strip(),
        "* Modelo teórico",
        proposal.modelo_teorico.strip(),
        "* Proposta de condução da pesquisa",
        proposal.proposta_conducao.strip(),
        "* Possibilidades de coleta de dados",
        coleta,
        "* Possibilidades de análise de dados",
        analise,
        "* Conclusão",
        sanitize_empirical_conclusion_text(proposal.texto_corrido_entrega),
    ]
    if config.texto_orientacao_extra:
        sections.extend(["* Observações de execução", "- O documento foi gerado no modo de pesquisa empírica.\n- Arquivo de orientação complementar aplicado na geração do texto final."])
    doc = "\n\n".join(s for s in sections if s and s.strip())
    doc = strip_org_cite_directives(doc)
    return normalize_org_text(doc)




# =========================
# SVG PRISMA
# =========================

def wrap_lines(text: str, max_chars: int) -> list[str]:
    text = re.sub(r"\s+", " ", text.strip())
    if not text:
        return []
    return textwrap.wrap(text, width=max_chars, break_long_words=False, break_on_hyphens=False)


@dataclass
class BoxSpec:
    x: int
    y: int
    width: int
    title_lines: list[str]
    body_lines: list[str]
    font_size: int = 24
    line_height: int = 30
    pad_x: int = 22
    pad_top: int = 22
    pad_bottom: int = 22

    @property
    def height(self) -> int:
        total_lines = len(self.title_lines) + len(self.body_lines)
        return self.pad_top + self.pad_bottom + total_lines * self.line_height

    @property
    def bottom(self) -> int:
        return self.y + self.height


def tspan_block(lines: list[str], x_center: float, line_height: int, bold_count: int) -> str:
    out = []
    for idx, line in enumerate(lines):
        weight = " font-weight='700'" if idx < bold_count else ""
        dy = 0 if idx == 0 else line_height
        out.append(f"<tspan x='{x_center:.1f}' dy='{dy}'{weight}>{escape(line)}</tspan>")
    return "".join(out)


def render_box(spec: BoxSpec) -> str:
    x_center = spec.x + spec.width / 2
    start_y = spec.y + spec.pad_top + spec.font_size
    lines = spec.title_lines + spec.body_lines
    text_block = tspan_block(lines, x_center, spec.line_height, len(spec.title_lines))
    return (
        f"<rect x='{spec.x}' y='{spec.y}' width='{spec.width}' height='{spec.height}' "
        f"rx='6' ry='6' fill='white' stroke='#1f1f1f' stroke-width='2.2'/>"
        f"<text x='{x_center:.1f}' y='{start_y:.1f}' text-anchor='middle' "
        f"font-family='Arial, Helvetica, sans-serif' font-size='{spec.font_size}' fill='#111'>{text_block}</text>"
    )


def arrow(x1: float, y1: float, x2: float, y2: float) -> str:
    return (
        f"<line x1='{x1:.1f}' y1='{y1:.1f}' x2='{x2:.1f}' y2='{y2:.1f}' "
        f"stroke='#1f1f1f' stroke-width='2.4' marker-end='url(#arrowhead)'/>"
    )


def build_side_reason_box(title: str, items: list[str], x: int, y: int, width: int) -> BoxSpec:
    title_lines = wrap_lines(title, 32)
    body_lines: list[str] = []
    for item in items:
        wrapped = wrap_lines(item, 34)
        body_lines.extend(wrapped)
    return BoxSpec(x=x, y=y, width=width, title_lines=title_lines, body_lines=body_lines)


def build_main_box(title: str, n: int, x: int, y: int, width: int) -> BoxSpec:
    lines = wrap_lines(title, 34)
    body = [f"(n = {n})"]
    return BoxSpec(x=x, y=y, width=width, title_lines=lines, body_lines=body)


def build_svg_prisma(config: Config, audit: SearchAudit, triage: TriageOutput, counts: PrismaCounts, output_svg: Path) -> None:
    del config, audit, triage

    left_x = 120
    right_x = 760
    box_w = 420
    gap_y = 44
    start_y = 88

    def compact_box(title: str, n: int, x: int, y: int) -> BoxSpec:
        title_lines = wrap_lines(title, 28)
        return BoxSpec(
            x=x,
            y=y,
            width=box_w,
            title_lines=title_lines,
            body_lines=[f"(n = {n})"],
            font_size=22,
            line_height=28,
            pad_x=18,
            pad_top=18,
            pad_bottom=18,
        )

    identified = compact_box("Registros identificados nas bases de dados", counts.identified, left_x, start_y)
    removed = compact_box("Registros removidos antes da triagem", counts.removed_pre, right_x, start_y)

    y2 = max(identified.bottom, removed.bottom) + gap_y
    screened = compact_box("Registros triados", counts.screened, left_x, y2)
    excluded_screen = compact_box("Registros excluídos na triagem", counts.excluded_screening, right_x, y2)

    y3 = max(screened.bottom, excluded_screen.bottom) + gap_y
    sought = compact_box("Relatórios buscados para recuperação", counts.full_text_sought, left_x, y3)
    not_retrieved = compact_box("Relatórios não recuperados", counts.not_retrieved, right_x, y3)

    y4 = max(sought.bottom, not_retrieved.bottom) + gap_y
    assessed = compact_box("Relatórios avaliados para elegibilidade", counts.full_text_assessed, left_x, y4)
    excluded_full = compact_box("Relatórios excluídos após leitura completa", counts.excluded_full_text, right_x, y4)

    y5 = max(assessed.bottom, excluded_full.bottom) + gap_y
    included = compact_box("Estudos incluídos na síntese qualitativa", counts.included_qualitative, left_x, y5)

    boxes = [identified, removed, screened, excluded_screen, sought, not_retrieved, assessed, excluded_full, included]

    svg_width = 1320
    svg_height = included.bottom + 90

    svg_parts = [
        f"<svg xmlns='http://www.w3.org/2000/svg' width='{svg_width}' height='{svg_height}' viewBox='0 0 {svg_width} {svg_height}'>",
        "<defs><marker id='arrowhead' markerWidth='10' markerHeight='8' refX='9' refY='4' orient='auto'><polygon points='0 0, 10 4, 0 8' fill='#1f1f1f'/></marker></defs>",
        "<rect x='0' y='0' width='100%' height='100%' fill='white'/>",
        "<text x='120' y='42' font-family='Arial, Helvetica, sans-serif' font-size='28' font-weight='700' fill='#111'>Fluxograma PRISMA 2020</text>",
    ]

    for spec in boxes:
        svg_parts.append(render_box(spec))

    svg_parts.append(arrow(identified.x + identified.width, identified.y + identified.height / 2, removed.x, removed.y + removed.height / 2))
    svg_parts.append(arrow(identified.x + identified.width / 2, identified.bottom, screened.x + screened.width / 2, screened.y))
    svg_parts.append(arrow(screened.x + screened.width, screened.y + screened.height / 2, excluded_screen.x, excluded_screen.y + excluded_screen.height / 2))
    svg_parts.append(arrow(screened.x + screened.width / 2, screened.bottom, sought.x + sought.width / 2, sought.y))
    svg_parts.append(arrow(sought.x + sought.width, sought.y + sought.height / 2, not_retrieved.x, not_retrieved.y + not_retrieved.height / 2))
    svg_parts.append(arrow(sought.x + sought.width / 2, sought.bottom, assessed.x + assessed.width / 2, assessed.y))
    svg_parts.append(arrow(assessed.x + assessed.width, assessed.y + assessed.height / 2, excluded_full.x, excluded_full.y + excluded_full.height / 2))
    svg_parts.append(arrow(assessed.x + assessed.width / 2, assessed.bottom, included.x + included.width / 2, included.y))

    svg_parts.append("</svg>")
    write_text(output_svg, "\n".join(svg_parts))


def save_debug_json(output_dir: Path, prefixo: str, data: dict) -> Path:
    path = output_dir / f"{prefixo}_debug.json"
    write_text(path, json.dumps(data, ensure_ascii=False, indent=2))
    return path


def main() -> int:
    env_path = load_local_env_file()
    args = parse_args()
    config = build_config(args)
    config.output_dir.mkdir(parents=True, exist_ok=True)
    logger, log_path = setup_logging(config.output_dir, config.prefixo)
    log_phase(logger, 1, "Inicialização e carregamento da configuração")
    logger.info("Diretório efetivo de saída: %s", config.output_dir)
    if env_path:
        logger.info("Arquivo .env carregado com prioridade: %s", env_path)
    else:
        logger.info("Nenhum .env encontrado ao lado do script; usando ambiente atual.")
    logger.info("Iniciando geração da atividade.")
    logger.info("Modo da atividade: %s", "revisão sistemática/PRISMA" if config.modo == "revisao_sistematica" else "pesquisa empírica")
    logger.info("Tema: %s", config.tema)
    logger.info("Recorte: %s", config.recorte)
    logger.info("Objetivo: %s", config.objetivo)
    if config.config_path:
        logger.info("Arquivo de configuração carregado: %s", config.config_path)
    if config.modo == "revisao_sistematica":
        logger.info("Bases selecionadas: %s", config.bases_label)
        logger.info("Queries bilíngues: %s", "sim" if config.query_bilingue else "não")
        logger.info("Rigor da triagem: %s", config.triagem_rigor)
        logger.info("Permitir textos não públicos sem download local: %s", "sim" if config.permitir_textos_nao_publicos else "não")
    if config.saida_orientacoes_paths:
        logger.info("Arquivos de orientação geral aplicados: %s", ", ".join(str(p) for p in config.saida_orientacoes_paths))

    if config.gerar_env_example:
        env_example_path = config.output_dir / ".env.example"
        write_env_example(env_example_path)
        logger.info("Arquivo .env.example gerado em %s", env_example_path)
    else:
        env_example_path = None

    log_phase(logger, 2, "Preparação do modelo Org e inicialização do cliente OpenAI")
    model_org_text = load_model_org_text(config.org_modelo)
    client = make_openai_client()
    log_phase(logger, 3, "Definição do título do trabalho")
    config.titulo_trabalho = suggest_and_confirm_work_title(client, config, model_org_text, interactive=not config.nao_interativo)
    logger.info("Título do trabalho: %s", config.titulo_trabalho)
    saved_config_path = None
    if config.salvar_config and config.config_output_path:
        try:
            saved_config_path = save_config_toml(config, config.config_output_path)
            logger.info("Arquivo de configuração salvo em %s", saved_config_path)
        except Exception as exc:
            logger.warning("Não foi possível salvar o arquivo de configuração: %s", exc)

    removed_paths: list[Path] = []

    if config.modo == "pesquisa_empirica":
        log_phase(logger, 4, "Geração da proposta empírica via IA")
        proposal = generate_empirical_project_with_openai(client, config, model_org_text)
        org_filename = f"{config.prefixo}.org"
        org_path = config.output_dir / org_filename
        org_content = build_empirical_org_document(config, model_org_text, proposal)
        log_phase(logger, 9, "Geração do arquivo Org")
        write_text(org_path, org_content)
        logger.info("Arquivo Org gerado em %s", org_path)
        if config.exportar_pdf:
            log_phase(logger, 10, "Conversão do Org para PDF")
        pdf_path = export_org_to_pdf(org_path, None, logger, config.org_latex_class_init, config.latex_extra_path, config.comando_exportacao_pdf) if config.exportar_pdf else None
        debug_payload = {
            "config": {
                "modo": config.modo,
                "disciplina": config.disciplina,
                "professor": config.professor,
                "curso": config.curso,
                "tema": config.tema,
                "recorte": config.recorte,
                "objetivo": config.objetivo,
                "tipo_estudo": config.tipo_estudo,
                "estilo_citacao": config.estilo_citacao,
                "idiomas": config.idiomas,
                "palavras_chave": config.palavras_chave,
                "saida_orientacoes_paths": [str(p) for p in config.saida_orientacoes_paths],
                "saida_orientacao_inline": config.saida_orientacao_inline,
                "model": config.model,
                "titulo_trabalho": config.titulo_trabalho,
                "comando_exportacao_pdf": config.comando_exportacao_pdf,
            },
            "proposal": proposal.model_dump(),
        }
        log_phase(logger, 11, "Finalização e gravação dos artefatos auxiliares")
        debug_path = save_debug_json(config.output_dir, config.prefixo, debug_payload)
        if config.remover_auxiliares:
            removed_paths = cleanup_generated_files(config.output_dir, config.prefixo, logger)
            if removed_paths:
                logger.info("Arquivos auxiliares removidos: %s", ", ".join(p.name for p in removed_paths))
        print("\nArquivos gerados com sucesso:")
        print(f"- TÍTULO: {config.titulo_trabalho}")
        print(f"- ORG:   {org_path}")
        print(f"- DEBUG: {debug_path}")
        if saved_config_path:
            print(f"- CONFIG:{saved_config_path}")
        if pdf_path:
            print(f"- PDF:   {pdf_path}")
        print("\nObservações:")
        print("- O documento foi gerado no modo de pesquisa empírica, com problema de pesquisa, hipótese e modelo teórico.")
        if config.saida_orientacoes_paths:
            print(f"- Arquivos de orientação geral aplicados: {", ".join(str(p) for p in config.saida_orientacoes_paths)}")
        return 0

    log_phase(logger, 4, "Consulta às bases, filtros iniciais e deduplicação")
    candidates, audit = collect_candidates(config, logger=logger)
    logger.info("Registros identificados: %s | Após filtros/deduplicação: %s", audit.identified_total, audit.screened_total)
    logger.info(
        "A verificação pesada de texto completo foi adiada para depois da triagem; os candidatos seguirão com base em metadados, resumo e links já fornecidos pelas bases."
    )
    for item in audit.per_source:
        logger.info("Fonte %s | query=%s | recuperados=%s | warnings=%s", SOURCE_LABELS.get(item.source, item.source), item.query, item.retrieved, '; '.join(item.warnings) if item.warnings else 'nenhum')
    if not candidates:
        raise RuntimeError("Nenhum candidato permaneceu após filtros e deduplicação.")

    source_log_paths = save_source_logs(config.output_dir, config.prefixo, audit)
    raw_json_paths = save_raw_search_jsons(config.output_dir, config.prefixo, audit) if config.salvar_busca_bruta_json else []
    if raw_json_paths:
        logger.info("Busca bruta salva em JSON por fonte.")

    log_phase(logger, 5, "Triagem inicial dos candidatos")
    working_candidates = list(candidates)
    triage = None
    selected = None
    selected_candidates: list[CandidatePaper] = []
    analysis = None
    fulltext_cache_dir = config.output_dir / f"{config.prefixo}_fulltext_cache"
    while working_candidates:
        rodada_msg = f"Rodada de triagem com {len(working_candidates)} candidato(s) elegíveis até aqui."
        log_subphase(logger, rodada_msg)
        triage = triage_with_openai_batched(client, config, working_candidates, model_org_text, allow_zero_included=True)
        if not triage_has_included(triage):
            save_zero_inclusion_diagnostic(config.output_dir, config.prefixo, triage, working_candidates, "estrita", logger)
            logger.warning("Triagem estrita não incluiu textos; iniciando triagem relaxada de recuperação metodológica.")
            triage = triage_with_openai_batched(client, config, working_candidates, model_org_text, allow_zero_included=True, relaxed_recovery=True)
            if not triage_has_included(triage):
                save_zero_inclusion_diagnostic(config.output_dir, config.prefixo, triage, working_candidates, "relaxada", logger)
                logger.warning("Triagem relaxada também não incluiu textos; aplicando seleção exploratória do melhor candidato relativo.")
                triage = force_exploratory_selection(triage, working_candidates, config)
                audit.warnings.append(triage.selection_warning or "Seleção exploratória aplicada por ausência de textos plenamente aderentes.")

        working_by_id = {c.paper_id: c for c in working_candidates}
        missing_selected_ids = [pid for pid in triage.selected_paper_ids if pid not in working_by_id]
        if missing_selected_ids:
            logger.warning(
                "Triagem retornou IDs selecionados ausentes da rodada atual; eles serão ignorados: %s",
                ", ".join(missing_selected_ids),
            )
            triage.selected_paper_ids = [pid for pid in triage.selected_paper_ids if pid in working_by_id]
        proposed_selected = [working_by_id[pid] for pid in triage.selected_paper_ids]
        if not proposed_selected:
            logger.warning("Triagem não retornou selecionados válidos na rodada atual; encerrando esta rodada e removendo o candidato de menor prioridade.")
            working_candidates = working_candidates[1:]
            continue
        logger.info("Textos selecionados pela triagem: %s", "; ".join(c.title for c in proposed_selected))
        ordered_decisions = [d for d in sorted(triage.decisions, key=lambda x: (x.ranking, -x.aderencia_score, x.paper_id)) if d.paper_id in working_by_id]
        reserve_ids = [d.paper_id for d in ordered_decisions if d.paper_id not in triage.selected_paper_ids and (d.alinhado_triada or d.stage != "incluido")]

        log_phase(logger, 6, "Recuperação e download local do texto completo")
        log_subphase(logger, "Verificando DOI, landing pages e tentando baixar localmente apenas os textos selecionados nesta rodada...")
        failed_downloads: list[tuple[CandidatePaper, str]] = []
        downloaded_selected: list[CandidatePaper] = []
        for cand in proposed_selected:
            logger.info("Tentando baixar localmente o texto selecionado: %s | link: %s", cand.title, cand.pdf_url)
            cand = download_candidate_pdf(cand, fulltext_cache_dir)
            local_pdf_path = Path(cand.downloaded_pdf_path) if cand.downloaded_pdf_path else None
            if local_pdf_path is None or not local_pdf_path.exists():
                reason = cand.full_text_note or cand.downloaded_pdf_note or "Falha no download local do PDF."
                failed_downloads.append((cand, reason))
            else:
                cand.downloaded_pdf_note = cand.downloaded_pdf_note or "PDF baixado localmente com sucesso."
                downloaded_selected.append(cand)

        if failed_downloads:
            kept_non_public: list[CandidatePaper] = []
            removed_candidates: list[CandidatePaper] = []
            if config.permitir_textos_nao_publicos:
                for cand, reason in failed_downloads:
                    if candidate_has_non_public_access_reference(cand):
                        logger.warning("O texto selecionado não pôde ser baixado localmente, mas será mantido por configuração como texto não público: %s | motivo: %s", cand.title, reason)
                        cand.full_text_note = cand.full_text_note or reason
                        audit.warnings.append(f"Texto mantido sem download local do PDF por configuração: {cand.title}. Motivo: {reason}")
                        kept_non_public.append(cand)
                    else:
                        logger.warning("O texto selecionado falhou no download local e será removido da seleção final: %s | motivo: %s", cand.title, reason)
                        audit.warnings.append(f"Excluído após falha no download local do PDF: {cand.title}. Motivo: {reason}")
                        removed_candidates.append(cand)
            else:
                for cand, reason in failed_downloads:
                    logger.warning("O texto selecionado falhou no download local e será removido da seleção final: %s | motivo: %s", cand.title, reason)
                    audit.warnings.append(f"Excluído após falha no download local do PDF: {cand.title}. Motivo: {reason}")
                    removed_candidates.append(cand)

            if removed_candidates:
                audit.screened_total = max(0, audit.screened_total - len(removed_candidates))
                audit.other_removed += len(removed_candidates)
                failed_ids = {cand.paper_id for cand in removed_candidates}
                working_candidates = [c for c in working_candidates if c.paper_id not in failed_ids]
                if not downloaded_selected and not kept_non_public:
                    continue

            downloaded_selected.extend(kept_non_public)

        if len(downloaded_selected) < config.quantidade_selecionados and reserve_ids:
            logger.info(
                "Seleção ficou abaixo da quantidade desejada após falhas de download; tentando reposição automática com candidatos de reserva do mesmo ranking."
            )
            already_attempted_ids = {c.paper_id for c in proposed_selected} | {c.paper_id for c, _ in failed_downloads}
            for reserve_id in reserve_ids:
                if len(downloaded_selected) >= config.quantidade_selecionados:
                    break
                if reserve_id in already_attempted_ids:
                    continue
                reserve_cand = working_by_id.get(reserve_id)
                if reserve_cand is None:
                    continue
                logger.info("Tentando candidato de reposição: %s | link: %s", reserve_cand.title, reserve_cand.pdf_url)
                reserve_cand = download_candidate_pdf(reserve_cand, fulltext_cache_dir)
                local_pdf_path = Path(reserve_cand.downloaded_pdf_path) if reserve_cand.downloaded_pdf_path else None
                if local_pdf_path is not None and local_pdf_path.exists():
                    reserve_cand.downloaded_pdf_note = reserve_cand.downloaded_pdf_note or "PDF baixado localmente com sucesso em reposição automática."
                    downloaded_selected.append(reserve_cand)
                    already_attempted_ids.add(reserve_id)
                    logger.info("Candidato de reposição aprovado: %s", reserve_cand.title)
                    continue
                reason = reserve_cand.full_text_note or reserve_cand.downloaded_pdf_note or "Falha no download local do PDF em reposição automática."
                if config.permitir_textos_nao_publicos and candidate_has_non_public_access_reference(reserve_cand):
                    logger.warning(
                        "Candidato de reposição sem download local será mantido por configuração como texto não público: %s | motivo: %s",
                        reserve_cand.title,
                        reason,
                    )
                    reserve_cand.full_text_note = reserve_cand.full_text_note or reason
                    downloaded_selected.append(reserve_cand)
                    audit.warnings.append(f"Texto de reposição mantido sem download local do PDF por configuração: {reserve_cand.title}. Motivo: {reason}")
                else:
                    logger.warning(
                        "Candidato de reposição falhou no download local e será descartado: %s | motivo: %s",
                        reserve_cand.title,
                        reason,
                    )
                    audit.warnings.append(f"Excluído após falha no download local do PDF em reposição automática: {reserve_cand.title}. Motivo: {reason}")
                    working_candidates = [c for c in working_candidates if c.paper_id != reserve_id]
                already_attempted_ids.add(reserve_id)

        selected_candidates = [enrich_candidate_from_local_pdf(c, max_chars=120000) for c in downloaded_selected]
        selected = selected_candidates[0]
        logger.info("Textos selecionados aprovados após a recuperação de texto completo: %s", "; ".join(c.title for c in selected_candidates))
        logger.info("Texto primário para análise aprofundada: %s", selected.title)
        logger.info("Link verificável para download do texto completo: %s", selected.pdf_url)
        try:
            log_phase(logger, 7, "Análise estruturada dos textos selecionados")
            analyses_by_id: dict[str, PaperAnalysisOutput] = {}
            for cand in selected_candidates:
                logger.info("Gerando análise estruturada do texto selecionado: %s", cand.title)
                try:
                    analyses_by_id[cand.paper_id] = analyze_selected_paper(client, config, cand, model_org_text)
                except Exception as exc:
                    logger.warning("Falha na análise estruturada do texto selecionado; será usado fallback local: %s | motivo: %s", cand.title, exc)
                    analyses_by_id[cand.paper_id] = fallback_paper_analysis(cand)
            log_phase(logger, 8, "Síntese integradora final")
            synthesis_text = synthesize_selected_papers(client, config, selected_candidates, analyses_by_id, model_org_text)
            break
        except Exception as exc:
            msg = str(exc)
            logger.warning("O conjunto selecionado falhou na síntese integrada e será reavaliado a partir do texto primário: %s | motivo: %s", selected.title, msg)
            audit.warnings.append(f"Falha na síntese integrada dos textos selecionados; o texto primário será removido da seleção final para nova tentativa. Motivo: {msg}")
            audit.screened_total = max(0, audit.screened_total - 1)
            audit.other_removed += 1
            working_candidates = [c for c in working_candidates if c.paper_id != selected.paper_id]
    if triage is None or selected is None or not selected_candidates or 'analyses_by_id' not in locals() or 'synthesis_text' not in locals():
        raise RuntimeError(
            "Nenhum conjunto de textos com download local bem-sucedido, análise estruturada e síntese integrada permaneceu após as tentativas de seleção. "
            "A busca recuperou candidatos, mas os textos selecionados não puderam ser baixados ou analisados. Tente ampliar bases, aumentar quantidade_triagem, relaxar tipo_estudo ou desativar filtros muito restritivos de acesso aberto."
        )
    counts = compute_prisma_counts(audit, triage)

    bib_path, selected_bib_keys, prisma_bib_key = save_bib_file(config.output_dir, config.prefixo, selected_candidates)
    logger.info("Arquivo BibTeX gerado em %s", bib_path)

    svg_filename = f"{config.prefixo}_prisma.svg"
    figure_pdf_filename = f"{config.prefixo}_prisma.pdf"
    org_filename = f"{config.prefixo}.org"
    svg_path = config.output_dir / svg_filename
    figure_pdf_path = config.output_dir / figure_pdf_filename
    org_path = config.output_dir / org_filename

    log_phase(logger, 9, "Geração do fluxograma PRISMA e do arquivo Org")
    build_svg_prisma(config, audit, triage, counts, svg_path)
    logger.info("SVG PRISMA gerado em %s", svg_path)
    convert_svg_to_pdf(svg_path, logger)
    org_content = build_org_document(
        config=config,
        model_org_text=model_org_text,
        triage=triage,
        analyses_by_id=analyses_by_id,
        synthesis_text=synthesis_text,
        candidates=candidates,
        audit=audit,
        counts=counts,
        figure_pdf_filename=figure_pdf_filename,
        bib_filename=bib_path.name,
        selected_bib_keys=selected_bib_keys,
        prisma_bib_key=prisma_bib_key,
    )
    write_text(org_path, org_content)
    logger.info("Arquivo Org gerado em %s", org_path)

    if config.exportar_pdf:
        log_phase(logger, 10, "Conversão do Org para PDF")
    pdf_path = export_org_to_pdf(org_path, bib_path, logger, config.org_latex_class_init, config.latex_extra_path, config.comando_exportacao_pdf) if config.exportar_pdf else None

    debug_payload = {
        "bib_file": str(bib_path),
        "config": {
            "modo": config.modo,
            "disciplina": config.disciplina,
            "professor": config.professor,
            "curso": config.curso,
            "tema": config.tema,
            "recorte": config.recorte,
            "objetivo": config.objetivo,
            "bases": config.bases,
            "bases_label": config.bases_label,
            "tipo_estudo": config.tipo_estudo,
            "estilo_citacao": config.estilo_citacao,
            "periodo": config.periodo,
            "idiomas": config.idiomas,
            "palavras_chave": config.palavras_chave,
            "query_bilingue": config.query_bilingue,
            "triagem_rigor": config.triagem_rigor,
            "triagem_score_hibrido": config.triagem_score_hibrido,
            "triagem_orientacoes_paths": [str(p) for p in config.triagem_orientacoes_paths],
            "triagem_orientacao_inline": config.triagem_orientacao_inline,
            "triagem_diretivas_extras": config.triagem_diretivas_extras,
            "queries": {src: config.source_query(src) for src in config.bases},
            "saida_orientacoes_paths": [str(p) for p in config.saida_orientacoes_paths],
                "saida_orientacao_inline": config.saida_orientacao_inline,
            "model": config.model,
            "titulo_trabalho": config.titulo_trabalho,
            "incluir_analise_detalhada_ia": config.incluir_analise_detalhada_ia,
            "incluir_sintese_integradora_ia": config.incluir_sintese_integradora_ia,
            "comando_exportacao_pdf": config.comando_exportacao_pdf,
        },
        "audit": {
            "identified_total": audit.identified_total,
            "duplicates_removed": audit.duplicates_removed,
            "other_removed": audit.other_removed,
            "screened_total": audit.screened_total,
            "per_source": [
                {
                    "source": item.source,
                    "label": SOURCE_LABELS.get(item.source, item.source),
                    "query": item.query,
                    "retrieved": item.retrieved,
                    "warnings": item.warnings,
                }
                for item in audit.per_source
            ],
            "warnings": audit.warnings,
        },
        "counts": counts.__dict__,
        "selected_primary": selected.short_dict(),
        "selected_all": [c.short_dict() for c in selected_candidates],
        "triage": triage.model_dump(),
        "analysis_primary": analyses_by_id[selected.paper_id].model_dump() if selected and selected.paper_id in analyses_by_id else None,
        "analyses_by_id": {pid: item.model_dump() for pid, item in analyses_by_id.items()},
        "synthesis_text": synthesis_text,
        "candidates": [c.short_dict() for c in candidates],
    }
    log_phase(logger, 11, "Finalização e gravação dos artefatos auxiliares")
    debug_path = save_debug_json(config.output_dir, config.prefixo, debug_payload)

    if config.remover_auxiliares:
        removed_paths = cleanup_generated_files(config.output_dir, config.prefixo, logger)
        if removed_paths:
            logger.info("Arquivos auxiliares removidos: %s", ", ".join(p.name for p in removed_paths))

    print("\nArquivos gerados com sucesso:")
    print(f"- TÍTULO: {config.titulo_trabalho}")
    print(f"- ORG:   {org_path}")
    print(f"- SVG:   {svg_path}")
    print(f"- FIGPDF:{figure_pdf_path}")
    print(f"- BIB:   {bib_path}")
    print(f"- DEBUG: {debug_path}")
    if saved_config_path:
        print(f"- CONFIG:{saved_config_path}")
    if pdf_path:
        print(f"- PDF:   {pdf_path}")
    if audit.warnings:
        print("\nAvisos:")
        for item in audit.warnings:
            print(f"- {item}")
    print("\nObservações:")
    print("- O fluxograma é gerado em SVG e convertido automaticamente para PDF antes da inserção no documento final.")
    print(r"- A inserção da figura no .org final é feita com \includegraphics, evitando a reinterpretação do texto do SVG pelo LaTeX.")
    print("- Se você selecionar Scopus ou Web of Science, as respectivas chaves precisam estar no ambiente ou serem informadas no terminal.")
    if config.query_bilingue:
        print("- As queries foram montadas/sugeridas em lógica bilíngue (português + inglês) quando possível.")
    if config.saida_orientacoes_paths:
        print(f"- Arquivos de orientação geral aplicados: {", ".join(str(p) for p in config.saida_orientacoes_paths)}")
    if config.remover_auxiliares:
        if removed_paths:
            print(f"- Arquivos auxiliares removidos: {len(removed_paths)}")
        else:
            print("- Nenhum arquivo auxiliar precisou ser removido.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("\nExecução interrompida pelo usuário.", file=sys.stderr)
        raise SystemExit(130)
    except (requests.HTTPError, requests.RequestException) as exc:
        print(f"Erro de rede/API externa: {exc}", file=sys.stderr)
        raise SystemExit(1)
    except ValidationError as exc:
        print(f"Erro de validação do retorno estruturado: {exc}", file=sys.stderr)
        raise SystemExit(1)
    except Exception as exc:
        print(f"Erro: {exc}", file=sys.stderr)
        raise SystemExit(1)
