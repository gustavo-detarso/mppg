# Mapa de uso das referências

- Citações únicas no documento: 19
- Chaves de artigos selecionados: 12
- Chaves de selecionados efetivamente citadas: 12
- Chaves de artigos extras: 0
- Chaves de extras efetivamente citadas: 0
- Entradas do .bib não citadas: 7

## Selecionados citados
- `madan2022ai`
- `criado2024artificial`
- `alhosani2024opportunities`
- `serra2024a`
- `sigfrids2022how`
- `criado2024inteligencia`
- `mariano2026inteligencia`
- `goulart2025processos`
- `melo2026competencias`
- `lemes2020o`
- `souza2025uso`
- `lyrio2025emerging`

## Extras citados
- Nenhum

## Outras chaves citadas
- `minkkinen2022continuous`
- `mkander2023auditing`
- `brkan2020legal`
- `cho2023human`
- `batool2025ai`
- `sharma2021implementing`
- `prisma2020statement`

## Entradas do .bib não citadas
- `parycek2023artificial`
- `pi2021machine`
- `chilunjika2022artificial`
- `yiitcanlar2022artificial`
- `barros2025inteligencia`
- `krtner2021predictive`
- `david2023understanding`
